<?php
/* 16Shop V1.9 */
include 'load.php';
valid_file("v1/index.php");
?>