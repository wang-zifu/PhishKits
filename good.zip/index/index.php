<?
include "bots.php"; 
$src="index";
header("location:$src");
?>
