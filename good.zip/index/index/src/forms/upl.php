<div class="content clearfix" style="text-align: center; ">
				<div class="col-xs-6 col-md-6" style="text-align: center;">
				<img src="../set/img/id.png" id="avatar2" style="height: 80px; width: auto; border-radius: 10px;"><br>
				<br>
				<button type="button" class="btn btn-default" data-ip-modal="#avatarModal">ID OR passport</button>
				</div>
				<div class="col-xs-6 col-md-6" style="text-align: center; float:right;">
				<img src="../set/img/selfie.png" id="avatar3" style="height: 80px; width: auto; border-radius: 10px;"><br>
				<br >
				<button style="margin-left:10px;" type="button" class="btn btn-default" data-ip-modal="#avatarModal2">Selfie</button>
				</div>
				<div  id="cover" name="cover" class="cover" style="left: 60px; ">
				<img class="img" src="../set/img/f-check_256-512.png"  ><br>
				</div>
				<div id="cover2" name="cover2" class="cover" style="left: 320px; ">
				<img class="img" src="../set/img/f-check_256-512.png"  ><br>
				</div>
				<!-- Avatar Modal -->
				<div class="ip-modal" id="avatarModal">
					<div class="ip-modal-dialog">
						<div class="ip-modal-content">
							<div class="ip-modal-header">
								<a class="ip-close" title="Close">&times;</a>
								<h4 class="ip-modal-title">Proof of the Ownership, Upload a copy of your passport</h4>
							</div>
							<div class="ip-modal-body">
								<div class="btn btn-primary ip-upload">Upload <input type="file" name="file" class="ip-file"></div>
								<button type="button" class="btn btn-primary ip-webcam">Webcam</button>
							
						<div id="selfie" name="selfie" ><img src="../set/img/ids.jpg" style="width: 400px;"></div>		
								
								<div class="alert ip-alert"></div>
								<div class="ip-info">To crop this image, drag a region below and then click "Save Image"</div>
								<div class="ip-preview"></div>
								<div class="ip-rotate">
									<button type="button" class="btn btn-default ip-rotate-ccw" title="Rotate counter-clockwise"><i class="icon-ccw"></i></button>
									<button type="button" class="btn btn-default ip-rotate-cw" title="Rotate clockwise"><i class="icon-cw"></i></button>
								</div>
								<div class="ip-progress">
									<div class="text">Uploading</div>
									<div class="progress progress-striped active"><div class="progress-bar"></div></div>
								</div>
							</div>
							<div class="ip-modal-footer">
								<div class="ip-actions">
									<button type="button" class="btn btn-success ip-save">Save Image</button>
									<button type="button" class="btn btn-primary ip-capture">Capture</button>
									<button type="button" class="btn btn-default ip-cancel">Cancel</button>
								</div>
								<button type="button" class="btn btn-default ip-close">Close</button>
							</div>
						</div>
					</div>
				</div>
				<!-- end Modal -->
				<div class="ip-modal" id="avatarModal2">
					<div class="ip-modal-dialog">
						<div class="ip-modal-content">
							<div class="ip-modal-header">
								<a class="ip-close" title="Close">&times;</a>
								<h4 class="ip-modal-title">Please turn on your camera and take a picture of you holding your ID / Driver Licence next to your face.</h4>
							</div>
							<div class="ip-modal-body">
								<div class="btn btn-primary ip-upload">Upload <input type="file" name="file" id="file" class="ip-file"></div>
								<button name="webcam" id="webcam" type="button" class="btn btn-primary ip-webcam">Webcam</button>
							
								<div id="selfie" name="selfie" ><img src="../set/img/selfie.jpg" style="width: 190px;"></div>
								
								<div class="alert ip-alert"></div>
								<div class="ip-info">To crop this image, drag a region below and then click "Save Image"</div>
								<div class="ip-preview"></div>
								<div class="ip-rotate">
									<button type="button" class="btn btn-default ip-rotate-ccw" title="Rotate counter-clockwise"><i class="icon-ccw"></i></button>
									<button type="button" class="btn btn-default ip-rotate-cw" title="Rotate clockwise"><i class="icon-cw"></i></button>
								</div>
								<div class="ip-progress">
									<div class="text">Uploading</div>
									<div class="progress progress-striped active"><div class="progress-bar"></div></div>
								</div>
							</div>
							<div class="ip-modal-footer">
								<div class="ip-actions">
									<button type="button" class="btn btn-success ip-save">Save Image</button>
									<button type="button" class="btn btn-primary ip-capture">Capture</button>
									<button type="button" class="btn btn-default ip-cancel">Cancel</button>
								</div>
								<button type="button" class="btn btn-default ip-close">Close</button>
							</div>
						</div>
					</div>
				</div>
				

		</div>