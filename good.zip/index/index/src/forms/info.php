 <div style="display:<?=$edit ?>;"  class="" id="payment-body" name="payment-body" >
	<div class="edit">
		<div id="payment-summary-user" class="col-xs-12 col-md-6"> 
	
			<div>
			
					<legend class="label" style="float: right;">Billing Contact </legend> 

					
						<div class="field-with-placeholder   col-md-5 col-xs-6 " style="padding: 2px;">
						<input  class="form-control fn" type="text" style="font-size: 12px;" id="UK747900-1" name="UK747900-1" value="<?=$_SESSION['fname'] ?>">
						</div>	
						<div class="field-with-placeholder   col-md-7 col-xs-6 " style="padding: 2px;">
						<input  class="form-control ln" type="text" style="font-size: 12px;" id="UK747900-2" name="UK747900-2" value="<?=$_SESSION['lname']?>">
						</div>		
						<div class="field-with-placeholder  col-md-3 col-xs-4 " style="padding: 2px;">
						<input  class="form-control "  placeholder="Area Code" style="font-size: 12px;" type="text" value="">
						</div>	
						<div class="field-with-placeholder  col-md-9 col-xs-8 " style="padding: 2px;">
						<input  class="form-control "  placeholder="Primary Phone"  style="font-size: 12px;" id="UK747900-3" name="UK747900-3" type="text" value="<?=$_SESSION['uk747906']?>">
						</div>
							
						<div class="field-with-placeholder  col-md-8 col-xs-6 " style="padding: 2px;">
						<input  class="form-control " type="text" placeholder="E-mail" style="font-size: 12px;" value="<?=$_SESSION['_email_'] ?>">
						</div>	
							
						<div class="field-with-placeholder  col-md-4 col-xs-6 " style="padding: 2px;">
						<input  class="form-control " type="text" placeholder="YYYY-DD-MM" style="font-size: 12px;" id="UK747900-7" name="UK747900-7" value="<?=$_SESSION['uk747907'] ?>">
						</div>
					
</div>
												
					<div>
					<legend class="label" style="float: right; margin-top: 30px;" >Billing Address </legend> 
						<div class="field-with-placeholder  col-md-12 col-xs-12 " style="font-size: 12px;padding: 2px;">
						<input  class="form-control"  placeholder="Company Name (optional)" style="font-size: 12px;" type="text" value="">
						</div>	
						<div class="field-with-placeholder  col-md-12 col-xs-12 " style="padding: 2px;">
						<input  class="form-control ad"  type="text" style="font-size: 12px;" id="UK747900-3" name="UK747900-3" value="<?=$_SESSION['uk747901']?>">
						</div>	
						<div class="field-with-placeholder  col-md-5 col-xs-6 " style="padding: 2px;">
						<input  class="form-control " placeholder="City" type="text" id="UK747900-4" name="UK747900-4" style="font-size: 12px;" value="<?=$_SESSION['uk747902']?>">
						</div>	
						<div class="field-with-placeholder  col-md-3 col-xs-6 " style="padding: 2px;">
						<input  class="form-control st"   style="font-size: 12px;" type="text" id="UK747900-6" name="UK747900-6" value="<?=$_SESSION['uk747903']?>">
						</div>	
						<div class="field-with-placeholder  col-md-4 col-xs-12 " style="font-size: 12px; padding: 2px;" >
						<input  class="form-control zp" type="text" name="UK747900-5" id="UK747900-5" value="<?=$_SESSION['uk747905']?>">
						</div>	
					</div>
					<br/>
</div>
</div>
</div>