﻿
<nav style="text-align:center;" id="Anonisma-free-tools" class="col-xs-12" role="navigation" aria-label="Global Navigation" data-hires="false" data-analytics-region="global nav" lang="en-US">
			<div id="gh-content" class="col-xs-12">
				<div class="col-xs-12">
					<ul class="Anonisma-nav-lista">
						<li class="isma tabl-tfa7a-ma3douda"><a class="Anonisma-link" href="../index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-maaak"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-iphone"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-lkhra"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-ipaaad"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-hhhhhh"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-morocco"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-Espaï¿½a"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li id="Anonisma-buscar" class="isma Anonisma-buscar">
							<div id="takhwar" class="takhwar" role="search">
							</div>
							
						</li>
					</ul>
				</div>
			</div>
</nav>