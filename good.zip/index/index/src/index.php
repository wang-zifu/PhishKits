<?php
header("location: index/index.php?api=_login-detail&session=".md5(microtime())."&wait=".sha1(microtime()));
?>