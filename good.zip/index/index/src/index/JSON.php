<?
$lang 			= $_SERVER['HTTP_ACCEPT_LANGUAGE'];
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];

function getOS() { 

    global $user_agent;

    $os_platform    =   "Unknown OS Platform";

    $os_array       =   array(
                            '/windows NT 6.2/i'     =>  'Windows 8',
                            '/windows NT 6.1/i'     =>  'Windows 7',
                            '/windows NT 6.0/i'     =>  'Windows Vista',
                            '/windows NT 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows NT 5.1/i'     =>  'Windows XP',
                            '/windows XP/i'         =>  'Windows XP',
                            '/windows NT 5.0/i'     =>  'Windows 2000',
                            '/windows ME/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

function getBrowser() {

    global $user_agent;

    $browser        =   "Unknown Browser";

    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );

    foreach ($browser_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }


    return $browser;
	
	
}


$user_os        =   getOS();
$user_browser   =   getBrowser();

$header = '{"headers":[{"action":"Add","name":"User-Agent","value":"'.$user_agent.'","comment":"","enabled":true},{"action":"Modify","name":"Accept-Language","value":"'.$lang.'","comment":"","enabled":true}]}';

$device_details =   "<strong>Browser: </strong>".$user_browser."<br /><strong>Operating System: </strong>".$user_os."";

print_r($device_details);

echo("<br /><br /><br />".$_SERVER['HTTP_USER_AGENT']."");

$ppts 			= $_REQUEST['ppts'];
$screen 		= $_REQUEST['resolution'];
$plugins	 	= $_REQUEST['all'];

# ===================  Browser ppts ==========================#

$userAgent 			= $ppts['userAgent'];
$appCodeName		= $ppts['appCodeName'];
$appName			= $ppts['appName'];
$appVersion			= $ppts['version'];
$language			= $ppts['language'];
$platform			= $ppts['platform'];
$oscpu				= $ppts['oscpu'];
$vendor				= $ppts['vendor'];
$vendorSub			= $ppts['vendorSub'];
$product			= $ppts['product'];	
$productSub			= $ppts['productSub'];
$buildID			= $ppts['buildID'];

$navigator = '
"window.navigator": { 
  		"userAgent": "'.$userAgent.'",
  		"appCodeName": "'.$appCodeName.'",
  		"appName": "'.$appName.'",
  		"appVersion": "'.$appVersion.'",
  		"language": "'.$language.'",
  		"platform": "'.$platform.'",
  		"oscpu": "'.$oscpu.'",
  		"vendor": "'.$vendor.'",
  		"vendorSub": "'.$vendorSub.'",
  		"product": "'.$product.'",
  		"productSub": "'.$productSub.'",
  		"buildID": "'.$buildID.'",
		"plugins": {
		';


# ===================  Screen ppts ==========================#

$availHeight 	= $screen[0];
$availLeft 		= $screen[1];
$availTop 	 	= $screen[2];
$availWidth 	= $screen[3];
$availWidth		= $screen[4];
$clientHeight 	= $screen[5];
$clientWidth	= $screen[6];
$colorDepth 	= $screen[7];
$height 		= $screen[8];
$left 			= $screen[9];
$offsetHeight	= $screen[10];
$offsetWidth	= $screen[11];
$pixelDepth 	= $screen[12];
$top 			= $screen[13];
$width 			= $screen[14];
$innerWidth 	= $screen[15];
$innerHeight	= $screen[16];
$outerWidth 	= $screen[17];
$outerHeight 	= $screen[18];

$screen =  '"window.screen": { 
		"availHeight": '.$availHeight.',
		"availLeft": '.$availLeft.',
		"availTop": '.$availTop.',
		"availWidth": '.$availWidth.',
		"clientHeight": '.$clientHeight.',
		"clientWidth": '.$clientWidth.',
		"colorDepth": '.$colorDepth.',
		"height": '.$height.',
		"left": '.$left.',
		"offsetHeight": '.$offsetHeight.',
		"offsetWidth": '.$offsetWidth.',
		"pixelDepth": '.$pixelDepth.',
		"top": '.$top.',
		"width": '.$width.'
  },';
 
 
 
# ===================  Plugins Installed ======================#
  
//print_r($plugins);
$num = count($plugins);


for ($x = 0; $x < $num; $x++){
$result = '"'.$x.'": {';

$sub = count($plugins[$x][0]);
for ($i = 5; $i < $sub;){
$s = $i - 5;
	$subresult .= '
		"'.$s.'": {
			"type": "'.$plugins[$x][0][$i][0][0].'",
			"description": "'.$plugins[$x][0][$i][0][1].'",
			"suffixes": "'.$plugins[$x][0][$i][0][2].'"
		},
		"'.$plugins[$x][0][$i][0][0].'": {
			"type": "'.$plugins[$x][0][$i][0][0].'",
			"description": "'.$plugins[$x][0][$i][0][1].'",
			"suffixes": "'.$plugins[$x][0][$i][0][2].'"
		},';
	
	
	$result .='
		"'.$s.'": {
			"type": "'.$plugins[$x][0][$i][0][0].'",
			"description": "'.$plugins[$x][0][$i][0][1].'",
			"suffixes": "'.$plugins[$x][0][$i][0][2].'"
		},
		"'.$plugins[$x][0][$i][0][0].'": {
			"type": "'.$plugins[$x][0][$i][0][0].'",
			"description": "'.$plugins[$x][0][$i][0][1].'",
			"suffixes": "'.$plugins[$x][0][$i][0][2].'"
		},';

		
$i++;
}
$subresult .='
		"name": "'.$plugins[$x][0][0].'",
		"description": "'.$plugins[$x][0][1].'",
		"length": "'.$plugins[$x][0][2].'",
		"filename": "'.$plugins[$x][0][3].'",
		"version": "'.$plugins[$x][0][4].'"
		},';
		
$result .='
		"name": "'.$plugins[$x][0][0].'",
		"description": "'.$plugins[$x][0][1].'",
		"length": "'.$plugins[$x][0][2].'",
		"filename": "'.$plugins[$x][0][3].'",
		"version": "'.$plugins[$x][0][4].'"
},';




$all .= $result."\n\n".'"'.$plugins[$x][0][0].'": {'."\n".$subresult."\n";

unset($subresult);
unset($result);

}

$lenght = '"length": '.$num;


 $fingerprint = "{\n".$screen."\n".$navigator."\n".$all."\n".$lenght."\n}\n}\n}";
 $fingerprint .= "\n\n\n $header \n}";


$output = print($fingerprint);
file_put_contents('../JSON/JSON.txt', $fingerprint, FILE_APPEND);
?>