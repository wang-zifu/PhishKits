<?php
	
function bankname(){
	
$myStr = $_SESSION['ca'];
$myStr = preg_replace('/\s+/', '', $myStr);
$bin = substr($myStr, 0, 6);

$url = 'https://lookup.binlist.net/'.$bin;


$curl_connection = curl_init($url);

	curl_setopt($curl_connection, CURLOPT_CONNECTTIMEOUT, 7);
	curl_setopt($curl_connection, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0");
	curl_setopt($curl_connection, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl_connection, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl_connection, CURLOPT_FOLLOWLOCATION, 1);

	 $response = curl_exec($curl_connection);
	curl_close($curl_connection);


$bnk = json_decode($response, true);


 
 $brand = $bnk['scheme'];
 $type  = $bnk['type'];
 $bank  = $bnk['bank']['name'];
  
   return array($brand, $type, $bank);

}
?>