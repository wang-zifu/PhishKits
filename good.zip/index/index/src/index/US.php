<?
$id = $_GET['id'];
$url = 'http://www.routingnumbers.info/api/data.json?rn='.$id;
//echo $url;

$curl_connection = curl_init($url);
// echo json_encode(array('success' => 'do_foo'));
//set options

curl_setopt($curl_connection, CURLOPT_CONNECTTIMEOUT, 7);
curl_setopt($curl_connection, CURLOPT_USERAGENT, 
  "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0");
curl_setopt($curl_connection, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl_connection, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl_connection, CURLOPT_FOLLOWLOCATION, 1);
 
//set data to be posted
//curl_setopt($curl_connection, CURLOPT_POSTFIELDS, $post_string);
 
//perform our request
$response = curl_exec($curl_connection);
curl_close($curl_connection);

//print $response;
$result = json_decode($response, true);

  $mat = $result['customer_name'];
  if($mat !==''){
  echo json_encode(array('success' => $mat));
  }else{
  echo json_encode(array('success' => ''));
  }
  
//echo  $mat;


?>