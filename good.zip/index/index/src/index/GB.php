<?
include 'simple_html_dom.php';
$dom = new simple_html_dom();

$str = $_GET['id'];
//$str ="56-00-29";
$str = str_replace("-", "", $str);

//print_r ($str);


$url = 'http://findsortcodes.co.uk/results.php?post=Submit+your+choices&countrybankcitysearch=no&sortsearch=no&searchstring='.$str;
//echo $url;

$curl_connection = curl_init($url);
// echo json_encode(array('success' => 'do_foo'));
//set options

curl_setopt($curl_connection, CURLOPT_CONNECTTIMEOUT, 7);
curl_setopt($curl_connection, CURLOPT_USERAGENT, 
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0");
curl_setopt($curl_connection, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl_connection, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl_connection, CURLOPT_FOLLOWLOCATION, 1);

//perform our request
$response = curl_exec($curl_connection);
curl_close($curl_connection);

//print $response;
preg_match("'<tr class=\"odd\"><td>(.*?)</td>'", $response, $match);





  echo json_encode(array('success' => $match[1]));


?>


