$( document ).ready(function() {
	
var availLeft 	= screen.availLeft;
var availTop 	= screen.availTop;
var left 		= screen.left;
var Top 		= screen.top;

if(left =='' || left == undefined ) left ='0';
if(Top =='' || Top == undefined ) Top ='0';

	
	
	resolution = [screen.availHeight,availLeft,availTop,window.screen.availWidth,screen.availWidth,
			document.body.clientHeight,document.body.clientWidth,screen.colorDepth,screen.height,
			left,document.documentElement.offsetHeight,document.documentElement.offsetWidth,
			screen.pixelDepth,Top,screen.width,window.innerWidth,window.innerHeight,window.outerWidth,
			window.outerHeight];
			
	//ppts =[];	
	//var ppts = new Array();
	//ppts = GetVisitorInfo ();
	var ppts = {}; 
	
  

			ppts["appName"]		=  	window.navigator.appName;
			ppts["vendor"]		= 	window.navigator.vendor;
			ppts["appCodeName"]	=	window.navigator.appCodeName;
            ppts["product"]		= 	window.navigator.product;
            ppts["productSub"]	= 	window.navigator.productSub;
			
            if (window.opera) {
					ppts["buildID"]		= window.opera.buildNumber ();
					ppts["version"]		= window.opera.version ();
            }
			  ppts["version"]			=	window.navigator.appVersion;
			  ppts["vendorSub"]			=   window.navigator.vendorSub;
			  ppts["appMinorVersion"]	=   window.navigator.appMinorVersion;
			  ppts["buildID"]			=   window.navigator.buildID;
			  ppts["userAgent"]			=   window.navigator.userAgent;
			  ppts["language"]			=   window.navigator.language;
			  ppts["cookieEnabled"]		=   window.navigator.cookieEnabled;
			  ppts["platform"]			=   window.navigator.platform;
			  
           if (window.navigator.language === undefined) {  // in Opera, the language, browserLanguage and userLanguage properties are equivalent
            
			ppts["language"]			=     window.navigator.browserLanguage;
            ppts["userLanguage"]		=     window.navigator.userLanguage;
            }
			ppts["systemLanguage"]		=   window.navigator.systemLanguage;
			ppts["cpuClass"]			=   window.navigator.cpuClass;
			ppts["oscpu"]				=   window.navigator.oscpu;
			ppts["onLine"]				=	window.navigator.onLine;
			

		
		//ppts.toString();	
		//document.getElementById("demo2").innerHTML = ppts;

/* 	for (key in ppts){
   document.write(key +" :  "+ppts[key] + "<br >");

}
 */
	
numPlugins = navigator.plugins.length;
var mim = [];
var som = [];
var all = [];

if (numPlugins > 0){

}else{}


for (i = 0; i < numPlugins; i++) {
 plugin = navigator.plugins[i];

	 var plug_name 			= plugin.name;
	 var plug_description 	= plugin.description;
	 var plug_length 		= plugin.length;
	 var plug_filename 		= plugin.filename;
	 var plug_version 		= plugin.version;

 var arr = [];
 arr = [plug_name,plug_description,plug_length,plug_filename,plug_version];
 
 
	 numTypes = plugin.length;
	 for (j = 0; j < numTypes; j++)
 {
  mimetype = plugin[j];
  
	  var mime_type 		= mimetype.type;
	  var mime_description 	= mimetype.description;
	  var mime_suffixes 	= mimetype.suffixes;

	mim = [mime_type,mime_description,mime_suffixes];
	arr.push([mim]);
	}

 all.push([arr]);

 arr = [];
 mim = [];

}

   $.ajax({
				type: 'POST',
				url: "JSON.php",
				data:  {all:all,resolution:resolution,ppts:ppts},
				dataType: 'json',
				success: function(msg){
			
				$('.answer').html(msg);
   }
 });
 
});