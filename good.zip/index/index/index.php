<?php
include "bots.php"; 


header("location:src/");
?> 