<? 

$to ="bankzinfo2@gmail.com"; // input your email here

?>