<?php
$emailku = 'phising951@gmail.com'; // masukin email lu disini coeng -_-
?>