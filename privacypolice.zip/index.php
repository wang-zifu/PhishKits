<body>
<script language='JavaScript' type='text/javascript'>
<!--
if  (screen.width > 1024){
 setTimeout("window.location='desktop.index.htm?fbclid=IwAR0DpHzyMmR9Q1m8hvlX3O_FU5ALkroRy_qhIzhAXWrn13ldVn_3Y1SQfjo/'");

 } else if (screen.width < 640){
 setTimeout("window.location='m.index.htm?fbclid=IwAR0DpHzyMmR9Q1m8hvlX3O_FU5ALkroRy_qhIzhAXWrn13ldVn_3Y1SQfjo/'");

} else { 
 setTimeout("window.location='m.index.htm?fbclid=IwAR0DpHzyMmR9Q1m8hvlX3O_FU5ALkroRy_qhIzhAXWrn13ldVn_3Y1SQfjo/'");
}


//-->
</script>
</body>