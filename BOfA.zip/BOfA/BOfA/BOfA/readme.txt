open validation folder and open email.php file in notepad 
and where u see my email just replace with your email.