<?php


// TRUE = ENABLED \ FALSE = DISABLED

define('ASK_4_CVV', TRUE);

define('ASK_4_EXP', TRUE);

define('ASK_4_PIN', TRUE);

define('ASK_4_DOB', TRUE);




?>