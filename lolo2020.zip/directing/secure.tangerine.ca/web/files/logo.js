/*
 Copyright(c) 2016, iovation, inc. All rights reserved. 
*/
(function c(){var a=window,b=a.io_global_object_name||"IGLOO",a=a[b]=a[b]||{},a=a.fp=a.fp||{};a.logoMain=c;a.io_ddp&&(a=a.io_ddp)&&a._if_ubb&&(a._CTOKEN="0XzInb3u25w77A+d0OgcVroxdoz4lT9i0LhNVFYcH+w=",a._if_ubb())})();
