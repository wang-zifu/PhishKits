// Client-side Javascript

// Local variables.
var hasReadTerms = false;
var hasPrintedSbbManualEnrollForm = false;
var timeDelayForStatus = 2000;

var validationPass = 1;
var validationFail = 0;
var validationQuit = -1;
var mastProNav;
var currentMinimumTransfer = 0;
var currentMaximumTransfer = 0;
var isTransferFromHEQAccount = false;

var checkViewLinkWithParams;

TransferAccountList = new Array();
TransferList = new Array();

///Function to Print the  <Div> Content to the Printer.
function printField(divname,txtname,lblname) {
	var dctl =	document.getElementById(divname);	
	if (dctl == null)
		return false;
	var print = document.getElementById(txtname);
	if (print == null)
		return false;
	var lblprin = document.getElementById(lblname);
	if (lblprin != null)
	{
		lblprin.value = print.value;
		//alert(lblprin.value);
		//alert(dctl.innerHTML);
	}
	pWin = window.open('MandT','pWin','location=false, menubar=yes, height = 500, width=500,  toolbar=yes, scrollbars=yes'); 
	if (pWin == null)
		return false;
	pWin.document.open(); 
	pWin.document.write('<html><head></head><body>'); 
	pWin.document.write(lblprin.value); 
	pWin.document.write('</body></html>'); 
	pWin.print(); 
	pWin.document.close(); 
	pWin.close(); 
	return false;
}

// Opens a new Web browser window based upon the specified parameters.
function openBrowserWindow(url,name,style)
{
	newWin = window.open(url,name,style);
}
function openBrowserInNewWindow(url,name,style)
{
	var rnd = "" + Math.random();
	rnd = rnd.replace("0.","")

	newWin = window.open(url,name+rnd,style);
	if (newWin != null) newWin.focus();
}
						
var isNetscape = (navigator.appName.indexOf("Netscape")!=-1);
function autoTab(keyInput, e) 
{
	var len = 0;
	var keyCode = (isNetscape) ? e.which : e.keyCode; 
	var filter = (isNetscape) ? [0,8,9,16] : [0,8,9,16,17,18,37,38,39,40,46];
	if (keyInput.getAttribute)
	{
		len = keyInput.getAttribute("maxlength");
	}
	if(len > 0 && keyInput.value.length >= len && !containsField(filter,keyCode)) 
	{
		keyInput.value = keyInput.value.slice(0, len);
		keyInput.form[(getIndex(keyInput)+1) % keyInput.form.length].focus();
	}

	return true;
}

function containsField(arr, ele) 
{
	var found = false, index = 0;
	while(!found && index < arr.length)
	{
		if(arr[index] == ele)
		{
			found = true;
		}
		else
		{
			index++;
		}
	}
	return found;
}

function getIndex(keyInput) 
{
	var index = -1, i = 0, found = false;
	while (i < keyInput.form.length && index == -1)
	{
		if (keyInput.form[i] == keyInput)
		{
			index = i;
		}
		else 
		{
			i++;
		}
	}
	return index;
}

// Open Terms and Conditions and flag as having been read.
function readTerms(url,name,style)
{
	openBrowserWindow(url,name,style)
	
	hasReadTerms = true;
}

// Client-side Custom Validator evaluation for more validation of Social Security Number.
function validateSsnMore()
{
	// Always return Success; Server-side evaluation will validate.
	return 1;
}

// Displays a confirmation popup with the specified message
function confirmPopup(msg)
{
	return confirm(msg);
}

// Redirects the user to the specified URL when confirmation response is "OK" (true)
function confirmSignoff(redirectUrl, msg)
{
	if (confirmPopup(msg))
	{
		document.location = redirectUrl;
	}
}

// Open new browser window after confirmation popup
function confirmPopupAndRedirect(url, msg, name, style)
{
	if (confirmPopup(msg))
	{
		openBrowserWindow(url,name,style);
	}
}

// To set status
function setStatus(statusText) {
	window.status = statusText;
	setTimeout("eraseStatus()", timeDelayForStatus)
}

// To erase status
function eraseStatus() {
	window.defaultStatus = 'M&T Web Banking';
}

// To print Sbb Manual Enroll Form
function printSbbManualEnrollForm()
{
	printThisPage();
	hasPrintedSbbManualEnrollForm = true;
}

// To print current page
function printThisPage() { 
	if (window.print)
		window.print();
	else 
		alert("Sorry, your browser doesn't support this feature."); 
} 

// To display a message
function displayMessage(theMessage)
{
	alert(theMessage);
}

// To conditionally display message or redirect to url
function displayMessageOrRedirect(theVariable, theValue, theMessage, theUrl)
{
	if (eval(theVariable) == theValue)
	{
		alert(theMessage);
	}
	else
	{
		location.href = theUrl;
	}
}

// To clean specified text by stripping out all characters not included in specified RegEx pattern.
function cleanInputString(textboxID, charsPattern)
{
	var textboxCtrl = eval("document.formMP." + textboxID);
	var rawString = textboxCtrl.value;
	var rawChar = "";
	var cleanedString = "";
	
	var pattern = new RegExp(charsPattern);

	for (charPos = 0; charPos <= rawString.length - 1; charPos++)
	{
		rawChar = rawString.charAt(charPos);
		if (rawChar.match(pattern))
		{
			cleanedString = cleanedString + rawChar;
		}
	}
	
	textboxCtrl.value = cleanedString;
}

// To enforce Permissions selection rules on SubUser Add/Edit pages.
function enforcePermissionsChange(repeaterItemID, Add)
{
	var prefix = "Add";
	if (Add == false) 
		prefix = "Edit";
	
	var viewOption = eval("document.formMP." + repeaterItemID + "_ddl" + prefix + "1ViewOption");
	var transferFromOption = eval("document.formMP." + repeaterItemID + "_ddl" + prefix + "1TransferFromOption");
	var transferFromLimit = eval("document.formMP." + repeaterItemID + "_ddl" + prefix + "1TransferFromLimit");
	var billPayOption = eval("document.formMP." + repeaterItemID + "_ddl" + prefix + "1BillPayOption");
	var billPayLimit = eval("document.formMP." + repeaterItemID + "_ddl" + prefix + "1BillPayLimit");
	var stopPayOption = eval("document.formMP." + repeaterItemID + "_ddl" + prefix + "1StopPayOption");

	if (viewOption.selectedIndex == 0)
	{
		if (transferFromOption)
		{
			transferFromOption.selectedIndex = 0;
			transferFromLimit.selectedIndex = 0;
		}
		if (billPayOption)
		{
			billPayOption.selectedIndex = 0;
			billPayLimit.selectedIndex = 0;
		}
		if (stopPayOption)
		{
			stopPayOption.selectedIndex = 0;
		}
	}
	else if (viewOption.selectedIndex != 0)
	{
		if (transferFromOption)
		{
			switch (transferFromOption.selectedIndex)
			{
				case 0:
				case 1:
					if (transferFromLimit)
					{
						transferFromLimit.selectedIndex = 0;
					}
					break;
				case 2:
				case 4:
					if (transferFromLimit)
					{
						transferFromLimit.selectedIndex = transferFromLimit.selectedIndex == 0 ? 1 : transferFromLimit.selectedIndex;
						transferFromLimit.selectedIndex = transferFromLimit.selectedIndex == 13 ? 12 : transferFromLimit.selectedIndex;
					}
					break;
				case 3:
				case 5:
					if (transferFromLimit)
					{
						transferFromLimit.selectedIndex = 13;
					}
					break;
				default:
					break;
			}
		}

		if (billPayOption)
		{
			switch (billPayOption.selectedIndex)
			{
				case 0:
				case 1:
					if (billPayLimit)
					{
						billPayLimit.selectedIndex = 0;
					}
					break;
				case 2:
				case 4:
					if (billPayLimit)
					{
						billPayLimit.selectedIndex = billPayLimit.selectedIndex == 0 ? 1 : billPayLimit.selectedIndex;
						billPayLimit.selectedIndex = billPayLimit.selectedIndex == 13 ? 12 : billPayLimit.selectedIndex;
					}
					break;
				case 3:
				case 5:
					if (billPayLimit)
					{
						billPayLimit.selectedIndex = 13;
					}
					break;
				default:
					break;
			}
		}
	}
}

// To conditionally redirect to url if selected ListItem value in dropdown matches that specified, and/or display Payee Name for selected Nickname.
function enforcePayeeChange(theListItemValue, theUrl, payToOrder)
{
	var dP = eval("document.formMP.ddlPayee");
	var tP = eval("document.formMP.txtPayToOrderOf");

	if (dP.value == theListItemValue)
	{
		location.href = theUrl;
	}
	else if (payToOrder == true)
	{
		var payee = dP.value.split("|");
	
		tP.value = payee[1];
	}
}

// To enforce Payment selection rules on Add Payment pages.
function enforcePaymentChange(theControlID)
{
	var dF = eval("document.formMP.ddlFrequency");
	var tD = document.getElementById("tblDuration");
	var rTP = eval("document.formMP.rdoTotalPayments");
	if (!rTP) rTP = eval("document.formMP.rdoTotalTransactions");
	var tTP = eval("document.formMP.txtTotalPayments");
	if (!tTP) tTP = eval("document.formMP.txtTotalTransactions");
	var rOE = eval("document.formMP.rdoOpenEnded");

	switch (theControlID)
	{
		case dF.id:
			if (dF.value == "SINGLE")
			{
				tD.disabled = true;
				tD.className = "bodytextDisabled";
				rTP.checked = false;
				rTP.disabled = true;
				tTP.value = "1";
				tTP.disabled = true;
				rOE.checked = false;
				rOE.disabled = true;
			}
			else
			{
				tD.disabled = false;
				rTP.disabled = false;
				tTP.value = "";
				tTP.disabled = false;
				rOE.disabled = false;
			}
			break;
		case rTP.id:
			if (rTP.checked == true)
			{
				tTP.focus();
			}
			break;
		case rOE.id:
			if (rOE.checked == true)
			{
				tTP.value = "";
			}
			break;
	}
}

// To enforce Recurring Transaction (Model) rules on Add/Edit Transfer/Payment pages.
function enforceModelChange(theControlID)
{
	var dF = eval("document.formMP.ddlFrequency");
	var tM = document.getElementById("tblModel");
	var rTT = eval("document.formMP.rdoTotalTransactions");
	var tTT = eval("document.formMP.txtTotalTransactions");
	var rOE = eval("document.formMP.rdoOpenEnded");

	switch (theControlID)
	{
		case dF.id:
			if (dF.value == "SINGLE")
			{
				tM.disabled = true;
				tM.className = "bodytextDisabled";
				rTT.checked = false;
				rTT.disabled = true;
				tTT.value = "";
				tTT.disabled = true;
				rOE.checked = false;
				rOE.disabled = true;
			}
			else
			{
				tM.disabled = false;
				tM.className = "bodytext";
				rTT.disabled = false;
				tTT.disabled = false;
				rOE.disabled = false;
			}
			break;
		case rTT.id:
			if (rTT.checked == true)
			{
				tTT.focus();
			}
			break;
		case rOE.id:
			if (rOE.checked == true)
			{
				tTT.value = "";
			}
			break;
	}
}

// Function for dynamic payment confirmation messages
function getNewPaymentMessage (frequency, openEnded)
{
	PrepareNewPaymentMsgs();
	if (frequency == "SINGLE")
	{
		return newSinglePaymentMsg;
	}
	if (openEnded)
	{
		return newRecurringOpenEndedPaymentMsg;
	}
	else
	{
		return newRecurringLimitedPaymentMsg;
	}
}

// Function for dynamic edit payment confirmation messages
function getEditPaymentMessage (frequency, cancelling, cancelAll, cancelOpenEnded)
{
	// For debugging purpose only.
	// alert("frequency = " + frequency + " Cancelling = " + cancelling + " cancelall = " + cancelAll + " cancelOpenEnded = " + cancelOpenEnded);
	PrepareEditPaymentMsgs();

	if (frequency == "One Time")
	{
		if (cancelling)
		{
			return cancelSinglePaymentMsg;
		}
		else
		{
			return editSinglePaymentMsg;
		}
	}
	else
	{
		if (cancelling)
		{
			if (cancelAll)
			{
				if (cancelOpenEnded)
				{
					return cancelOpenEndedPaymentMsg;
				}
				else
				{
					return cancelLimitedPaymentMsg;
				}
			}
			else
			{
				return cancelNextPaymentMsg;
			}
		}
		else
		{
			return editRecurringPaymentMsg;
		}
	}
}

function trimOneBeforeFind(masterValue, findValue)
{
	var result = masterValue;
	if (masterValue == null || findValue == null)
	{
		return result;
	}
	var findPos = masterValue.indexOf(findValue);
	if (findPos < 0)
	{
		return result;
	}
	if (findPos > masterValue.length)
	{
		return result;
	}
	result = masterValue.substr(0, findPos - 1);
	
	return result;
}

// Function for dynamic payment confirmation messages
function getNewTransferMessage (frequency, openEnded)
{
	PrepareNewTransferMsgs();
	if (frequency == "SINGLE")
	{
		return newSingleTransferMsg;
	}
	if (openEnded)
	{
		return newRecurringOpenEndedTransferMsg;
	}
	else
	{
		return newRecurringLimitedTransferMsg;
	}
}

// Function for dynamic payment confirmation messages
function getNewCreditTransferMessage()
{
	return PrepareNewCreditTransferMsg();
}

// Function for dynamic retail transfer confirmation messages
// function getEditTransferMessage (transferType, specificDate, openEnded)
function getEditTransferMessage (transferType)
{
	// For debugging purpose only.
	// alert("transferType = " + transferType);

	PrepareEditTransferMsgs();
	switch (transferType)
	{
		case "EditSingleScheduled":
			return editSingleScheduledTransferMsg;
			break;
		case "CancelSingleScheduled":
			return cancelSingleScheduledTransferMsg;
			break;
		case "CancelRecurringScheduled":
			return cancelRecurringScheduledTransferMsg;
			break;
	}
}

function getOpenEndedOrNumberOfTxns(openEndedField, openEndedTextField, numberOfTxnsField)
{
	var tmpResult = "";
	if (openEndedField != null && openEndedTextField != null && numberOfTxnsField != null)
	{
		if (openEndedField.checked)
		{
			tmpResult = openEndedTextField.innerHTML;
		}
		else
		{
			tmpResult = numberOfTxnsField.innerHTML;
		}
	}
	return tmpResult;
}

function ConfirmDeletePayee(groupName)
{
	var deleteConfirmationMsg = getDeletePayeeMessage();
	if (groupName == "DELETE")
	{
		return confirm(deleteConfirmationMsg);
	}
	else
	{
		return true;
	}
}

function ConfirmDeleteSubUser(groupName)
{
	var deleteSubUserMsg = getDeleteSubUserConfirmMessage();
	var updateSubUserMsg = getUpdateSubUserConfirmMessage();
	
	if (groupName == "DELETE")
	{
		return confirm(deleteSubUserMsg);
	}
	else if (groupName == "SUBMIT")
	{
		return confirm(updateSubUserMsg);
	}
	else
	{
		return true;
	}
}

function ConfirmNewTransfer(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	if (!validateImmediateTransfer(document.formMP.ddlFrequency.value, document.formMP.txtDeliveryDate.value, document.formMP.txtAmount.value))
	{
		return false;
	}
	var confirmationMsg = getNewTransferMessage(document.formMP.ddlFrequency.value, document.formMP.rdoOpenEnded.checked);
	return confirm(confirmationMsg);	
}

function ConfirmNewCreditTransfer(groupName)
{	
	if (groupName == "EXIT")
	{
		return true;
	}
	var confirmationMsg = PrepareNewCreditTransferMsg();
	return confirm(confirmationMsg);	
}

function validateImmediateTransfer(frequency, deliveryDate, amount)
{
	var enteredDate;
	var asapTransfer = (deliveryDate == "ASAP" || deliveryDate == "asap");
	var isImmediateTransfer = false;

	if (!asapTransfer)
	{
		enteredDate = new Date(deliveryDate);
		var tmpToday = getToday();
		isImmediateTransfer = isToday(enteredDate);
	}
	if (frequency == "SINGLE" && (isImmediateTransfer || asapTransfer))
	{
		if (currentMinimumTransfer > 0 && amount < currentMinimumTransfer)
		{
			var msg = "The transfer from the selected account requires a minimum transfer of $" + currentMinimumTransfer;
			alert(msg);
			return false;
		}
		
		if (amount > currentMaximumTransfer)
		{
			var msg =   "You do not have sufficient funds \n";
			msg = msg + "available in your account to complete \n";
			msg = msg + "the transaction.";
			alert(msg);
			return false;
		}
	}
	return true;
}

function validateNewPayment(deliveryDate)
{
	var enteredDate;
	var result = true;
	var asapTransfer = (deliveryDate == "ASAP" || deliveryDate == "asap");

	if (!asapTransfer)
	{
		enteredDate = new Date(deliveryDate);
		var tmpToday = getToday();
		if (isFirstDateGreater(enteredDate, addYearsToDate(tmpToday, 1)))
		{
			alert("Payments cannot be scheduled more than one year in advance. \nPlease re-enter a Delivery Date.");
			result = false;
		}
	}
	return result;
}

function validateMMFTransfer(amount)
{
		if (amount > currentMaximumTransfer)
		{
			var msg =   "We cannot complete your transaction at this time. \n\n";
			msg = msg + "According to our records, you do not have sufficient funds available in your account to complete the transaction. \n";
			msg = msg + "Please adjust the dollar amount and resubmit. \n\n";
			msg = msg + "Please note: The Money Market Fund account balance(s) reflected here are current as of the previous business day, subject to pending transactions. \n";
			msg = msg + "If you believe your account balances have been updated since the close of the previous business day, \n";
			msg = msg + "please call Shareholder Services at 1-800-836-2211, 8:00 a.m. - 5:30 p.m., Monday through Friday to complete this transaction.";
			alert(msg);
			return false;
		}
	return true;
}

function ConfirmEditTransfer(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	
	var transferType;
	// var rFreq = eval("document.formMP.txtFrequency");
	// var tDate = eval("document.formMP.txtDeliveryDate");
	// var rOE = eval("document.formMP.rdoOpenEnded");

	switch (groupName)
	{
		case "":
			transferType = "EditSingleScheduled";
			break;
		case "CANCEL":
			transferType = "CancelSingleScheduled";
			break;
		case "CANCELALL":
			transferType = "CancelRecurringScheduled";
			break;
	}

	var confirmationMsg = getEditTransferMessage(transferType);
	return confirm(confirmationMsg);
}

// Functions for dynamic invoice payment confirmation messages
function confirmNewInvoicePaymentValidation(newAmount, newPaymentDate)
{
	//alert("invoiceAmount=" + invoiceAmount + " invoiceDate=" + invoiceDate + " newAmount=" + newAmount + " newPaymentDate=" + newPaymentDate);
	var isAmountLessThanInvoice; isAmountLessThanInvoice = false;
	var isAmountGreaterThanInvoice; isAmountGreaterThanInvoice = false;
	var isDateGreaterThanInvoice; isDateGreaterThanInvoice = false;
	var tmpNewAmount = Number(newAmount);
	var tmpNewInvoiceAmount = Number(invoiceAmount);
	
	if (tmpNewAmount != "NaN" && tmpNewInvoiceAmount != "NaN")
	{
		if (tmpNewAmount < tmpNewInvoiceAmount)
		{
			isAmountLessThanInvoice = true;
		}
		if (tmpNewAmount > tmpNewInvoiceAmount)
		{
			isAmountGreaterThanInvoice = true;
		}
	}
	if (tmpNewAmount == "NaN")
	{
		isAmountLessThanInvoice = true;
	}
	
	if (tmpNewInvoiceAmount == "NaN")
	{
		isAmountGreaterThanInvoice = true;
	}
	
	var tmpNewPaymentDate = new Date(newPaymentDate);
	var tmpInvoiceDate = new Date(invoiceDate);
	if (tmpNewPaymentDate > tmpInvoiceDate)
	{
		isDateGreaterThanInvoice = true;
	}
	
	if (isAmountLessThanInvoice && isDateGreaterThanInvoice)
	{
		return confirm(amountLessDateGreaterMsg);
	}
	if (isAmountGreaterThanInvoice && isDateGreaterThanInvoice)
	{
		return confirm(amountGreaterDateGreaterMsg);
	}
	if (isAmountLessThanInvoice)
	{
		return confirm(amountLessThanInvoiceMsg);
	}
	if (isAmountGreaterThanInvoice)
	{
		return confirm(amountGreaterThanInvoiceMsg);
	}
	if (isDateGreaterThanInvoice)
	{
		return confirm(dateGreaterThanInvoiceMsg);
	}

	return true;
}

function ConfirmNewInvoicePayment(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	
	PrepareNewInvoicePaymentMsgs();
	
	if (confirmNewInvoicePaymentValidation(document.formMP.txtAmount.value, document.formMP.txtPaymentDate.value))
	{
		return confirm(justRightInvoiceMsg);
	}
	return false;
}

function ConfirmSbbTransaction(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	
	var transactionType;
	var rFreq = eval("document.formMP.Frequency");
	var tDate = eval("document.formMP.txtSpecificDate");
	var rOE = eval("document.formMP.rdoOpenEnded");
	var confirmationMsg; 
	var theAmountField;
	var runImmediateTransferValidation = false;

	PrepareSbbTransactionMsgs();
	
	// SBB Add transaction.
	if (rFreq)
	{
		var sRB = -1;
		for (i = 0; i < rFreq.length; i++) { if (rFreq[i].checked) { sRB = i; } }
		switch (rFreq[sRB].value)
		{
			case "rdoOneTimePayment":
				confirmationMsg = addSingleScheduledPaymentMsg;
				break;
			case "rdoRecurringPayment":
				if (rOE.checked == true) { confirmationMsg = addRecurringScheduledOpenEndedPaymentMsg; }
				else { confirmationMsg = addRecurringScheduledLimitedPaymentMsg; }
				break;
			case "rdoImmediateTransfer":
				confirmationMsg = addSingleImmediateTransferMsg;
				runImmediateTransferValidation = true;
				break;
			case "rdoOneTimeTransfer":
				if (tDate.value.toUpperCase() == "ASAP") 
				{ 
					confirmationMsg = addSingleImmediateTransferMsg; 
					runImmediateTransferValidation = true;
				}
				else 
				{ 
					confirmationMsg = addSingleScheduledTransferMsg; 
				}
				break;
			case "rdoRecurringTransfer":
				if (rOE.checked == true) { confirmationMsg = addRecurringScheduledOpenEndedTransferMsg; }
				else { confirmationMsg = addRecurringScheduledLimitedTransferMsg; }
				break;
		}
		if (runImmediateTransferValidation)
		{
			theAmountField = getPageAmount();
			if (theAmountField != null)
			{
				if (!validateImmediateTransfer("SINGLE", "ASAP", theAmountField.value))
				{
					return false;
				}
			}
		}
	}
	// SBB Edit transaction.
	else
	{
		switch (groupName)
		{
			case "EDITPAYMENT":
				confirmationMsg = editSingleScheduledPaymentMsg;
				break;
			case "CANCELPAYMENT":
				confirmationMsg = cancelSingleScheduledPaymentMsg;
				break;
			case "CANCELALLPAYMENTS":
				confirmationMsg = cancelRecurringScheduledPaymentMsg;
				break;
			case "EDITTRANSFER":
				confirmationMsg = editSingleScheduledTransferMsg;
				break;
			case "CANCELTRANSFER":
				confirmationMsg = cancelSingleScheduledTransferMsg;
				break;
			case "CANCELALLTRANSFERS":
				confirmationMsg = cancelRecurringScheduledTransferMsg;
				break;
		}
	}
	
	return confirm(confirmationMsg);
}

function ConfirmAccountSummarySubmit(groupName)
{
	var confirmationMsg;
	var theAmountField;
	if (groupName == "SINGLEPAYMENT")
	{
		confirmationMsg = getNewPaymentMessage("SINGLE", false);
		return confirm(confirmationMsg);
	}
	if (groupName == "SINGLETRANSFER")
	{
		theAmountField = getTransferControlAmount();
		if (theAmountField != null)
		{
			if (!validateImmediateTransfer("SINGLE", "ASAP", theAmountField.value))
			{
				return false;
			}
		}
		confirmationMsg = getNewTransferMessage("SINGLE", false);
		return confirm(confirmationMsg);
	}
	if (groupName == "VIEWCHECK")
	{
		/*
		var dtchkN = new Date();
		var dchkA = GetCheckAccountField();
		var tCN = GetCheckNumberField();

		return openBrowserWindow(getCustomizedCheckViewPopupUrl() + "?A=" + dchkA.value + "&CN=" + (tCN ? tCN.value : ""), dchkA.value + dtchkN.getTime(), 'width=650,height=450,scrollbars=yes,menubar=yes,resizable=yes');
		*/
		AccessImagingSite(groupName);
	}

	return true;
}

function ConfirmNewPayment(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	if (!validateNewPayment(document.formMP.txtDeliveryDate.value)) 
	{
		return false;
	}
	
	var confirmationMsg = getNewPaymentMessage(document.formMP.ddlFrequency.value, document.formMP.rdoOpenEnded.checked);
	return confirm(confirmationMsg);
}

function ConfirmEditCancelPayment(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	var frequency = document.getElementById("lblFrequencyData").innerHTML;
	var cancelling = (groupName != "");
	var cancelAll = (groupName == "CANCELALL");
	var cancelOpenEnded = (cancelling && document.formMP.rdoOpenEnded.checked);
	
	var confirmationMsg = getEditPaymentMessage(frequency, cancelling, cancelAll, cancelOpenEnded);
	return confirm(confirmationMsg);
}

function ConfirmNewMMFTransfer(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	var selectedFromIndex = document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].value;
	var selectedToIndex = document.formMP.ddlAccountTo.options[document.formMP.ddlAccountTo.selectedIndex].value;
	var selectedAmt = document.formMP.txtAmount.value;
	var msgFromAccount = document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].text;
	
	if (isDuplicateMMFTransfer(selectedFromIndex, selectedToIndex, selectedAmt))
	{
		var msg =   "You have requested a transfer that is exactly the same as one that is already pending: \n\n";
		msg = msg + "Number of Shares: \t\t\t" + selectedAmt + "\n";
		msg = msg + "Money Market Fund redeemed: \t" + trimOneBeforeFind(document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].text, "$") + "\n";
		msg = msg + "Money Market Fund purchased: \t" + trimOneBeforeFind(document.formMP.ddlAccountTo.options[document.formMP.ddlAccountTo.selectedIndex].text, "$") + "\n\n";
		msg = msg + "Please confirm that you would like to schedule an identical transaction by clicking \"OK\"\,\nor to cancel this transaction\, click \"Cancel\".";

		if (!confirm(msg)) return false;
	}
	if (!validateMMFTransfer(document.formMP.txtAmount.value))
	{
		return false;
	}
	var confirmationMsg = getNewTransferMessage("SINGLE", false);
	return confirm(confirmationMsg);
}

function ConfirmNewMMFPurchase(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	var selectedFromIndex = document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].value;
	var selectedToIndex = document.formMP.ddlAccountTo.options[document.formMP.ddlAccountTo.selectedIndex].value;
	var selectedAmt = document.formMP.txtAmount.value;
	var msgFromAccount = document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].text;
	
	if (isDuplicateMMFTransfer(selectedFromIndex, selectedToIndex, selectedAmt))
	{
		var msg =   "You have requested a purchase that is exactly the same as one that is already pending: \n\n";
		msg = msg + "Amount: \t\t\t\t" + "$" + selectedAmt + "\n";
		msg = msg + "Money Market Fund purchased: \t" + trimOneBeforeFind(document.formMP.ddlAccountTo.options[document.formMP.ddlAccountTo.selectedIndex].text, "$") + "\n";
		msg = msg + "Funds for purchase withdrawn from: \t" + trimOneBeforeFind(document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].text, "$") + "\n\n";
		msg = msg + "Please confirm that you would like to schedule an identical transaction by clicking \"OK\"\,\nor to cancel this transaction\, click \"Cancel\".";
		if (!confirm(msg)) return false;
	}
	if (!validateMMFTransfer(document.formMP.txtAmount.value))
	{
		return false;
	}
	var confirmationMsg = getNewTransferMessage("SINGLE", false);
	return confirm(confirmationMsg);
}

function ConfirmNewMMFRedeem(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	var selectedFromIndex = document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].value;
	var selectedToIndex = document.formMP.ddlAccountTo.options[document.formMP.ddlAccountTo.selectedIndex].value;
	var selectedAmt = document.formMP.txtAmount.value;
	var msgFromAccount = document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].text;
	
	if (isDuplicateMMFTransfer(selectedFromIndex, selectedToIndex, selectedAmt))
	{
		var msg =   "You have requested a redemption that is exactly the same as one that is already pending: \n\n";
		msg = msg + "Amount: \t\t\t\t" + selectedAmt + "\n";
		msg = msg + "Money Market Fund redeemed: \t" + trimOneBeforeFind(document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].text, "$") + "\n";
		msg = msg + "Proceeds from sale deposited into: \t" + trimOneBeforeFind(document.formMP.ddlAccountTo.options[document.formMP.ddlAccountTo.selectedIndex].text, "$") + "\n\n";
		msg = msg + "Please confirm that you would like to schedule an identical transaction by clicking \"OK\"\,\nor to cancel this transaction\, click \"Cancel\".";

		if (!confirm(msg)) return false;
	}
	if (!validateMMFTransfer(document.formMP.txtAmount.value))
	{
		return false;
	}
	var confirmationMsg = getNewTransferMessage("SINGLE", false);
	return confirm(confirmationMsg);
}

function ConfirmStopPaymentRequest(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	return confirm(GetStopPaymentConfirmationMessage());
}

function AccessImagingSite(groupName)
{
//JTG 9/22/08 - remove check for Adobe.
/*
	if (! CheckForAdobe())
	{
		alert("Please download Adobe Acrobat to proceed");
		return;
	}
*/
	if (groupName == "EXIT")
	{
		return true;
	}


	var dtN = new Date();
	var dA;
	var tCN;
	var radioButton = eval("document.formMP.chkViewOption");
	var selectedValue;
	var postingDates = "";
	var numberOfImages = "";

	//submitted from account summary customized view
	if (groupName == "VIEWCHECK")
	{
		dA = GetCheckAccountField();
		tCN = GetCheckNumberField();
	}
	else
	{
		dA = eval("document.formMP.ddlAccount");
		tCN = eval("document.formMP.txtCheckNumber");
	}


		
	//Selection made from Checkview page. Get the radiobutton selection
	if (radioButton && tCN.value == "")
		{

			var radioLength = radioButton.length;

			for(var i = 0; i < radioLength; i++) 
				{
					if(radioButton[i].checked)
					{
					selectedValue = radioButton[i].value;
					}
				}
			
			switch(selectedValue)
			{
				case "2"://Last 30 Days
					postingDates = GetLast30Days();
					break;
				case "3"://Last 31 to 60 days
					postingDates = GetLast31To60Days();
					break;
				case "4"://Last 61 to 90 days
					postingDates = GetLast61To90Days();
					break;
				case "5"://user entered dates manually
					var hDate = eval("document.formMP.txtDateTo");
					var lDate = eval("document.formMP.txtDateFrom");
					var msg;

					if (hDate.value == "")
					{
						//populate text box with properly formatted date
						hDate.value = fillToDate();
					}
			
						//parse date to properly format for NCR request, must be in yyyyMMdd format
						var fromDate = lDate.value
						var toDate = hDate.value
						
						var partOfFromDate = new Array();
						var partOfToDate = new Array();
						
						partOfFromDate = fromDate.split("/");
						partOfToDate = toDate.split("/");
						
						
						fromDate = partOfFromDate[2] + partOfFromDate[0] + partOfFromDate[1];
						toDate = partOfToDate[2] + partOfToDate[0] +  partOfToDate[1];
				
						postingDates = "&d=" + fromDate + "&h=" + toDate;
						
						break;

				}
				
				numberOfImages = eval("document.formMP.ddlNumberOfCheckImages");
				numberOfImages = numberOfImages.value;
				
		}
		
		return openBrowserWindow(getPopupUrl() + "?A=" + dA.value + postingDates +"&CN=" + (tCN ? tCN.value : "") + "&I=" + numberOfImages, dA.value + dtN.getTime(), 'width=600,height=600,left=0,top=0,status=yes,toolbars=yes,scrollbars=yes,menubar=yes,resizable=yes,location=no');
		

}

function AccessImagingSiteDirectly()
{

//JTG 9/22/08 - remove check for Adobe.
/*
	if (! CheckForAdobe())
	{
		alert("Please download Adobe Acrobat to proceed");
		return;
	}
*/
	var dtN = new Date();
	
	return openBrowserWindow(getCheckViewPopupUrl(), dtN.getTime(), 'width=600,height=600,left=0,top=0,status=yes,toolbars=yes,scrollbars=yes,menubar=yes,resizable=yes,location=no');
}

function PassCheckViewLink(URLWithParams)
{
	checkViewLinkWithParams = URLWithParams;
	
	//Pass through the function below in order to check for Acrobat.
	AccessImagingSiteDirectly();
}
function CustomValidateInteger(customCondition)
{
	if (customCondition.IDToEval == "") return validationQuit;
	var enteredData = VAM_GetTextValue(customCondition.IDToEval, customCondition.Trim);
	if (enteredData == "") return validationQuit;
	if (VAM_ParseInt(enteredData) != NaN)
	{
		return validationPass;
	}
	else
	{
		return validationFail;
	}
}

function CustomValidateDate(customCondition)
{
	return validationQuit;
}

function proNavSet(theControlID)
{
	mastProNav = theControlID;
}

function proNavExec(theFormName, theControlID)
{
	if (theControlID == null) return;
	if (theControlID.length > 0)
	{
		var proNav = proNav_GetById(theFormName, theControlID);
		if (proNav != null)
		{
			setFocus(proNav);
		}
		else
		{
			//alert("proNav for theControlID is null");
		}
	}
}

function proNav_GetById(theFormName, theControlID)
{
	if (document.getElementById)
		return document.getElementById(theControlID);
		
	if (document.all)
		return document.all[theControlID];
		
	if (document.layers) 
		{
			var theElement = "";
			eval("if (document."+ theControlID + ") theElement = document."+theControlID+"; else theElement =document." + theFormName + "." + theControlID);
			return theElement;
		}
	else
		return null; 
} 

function setFocus(theControl)
{
	setTimeout(function(){theControl.focus();},50);
}

function AccountItem(acIndex, acCat, acSubCat, isXfrFrom, isXfrTo, acBal, acMinXfr, acDisplay)
{
	this.Index = acIndex;
	this.Category = acCat;
	this.SubCategory = acSubCat;
	this.isFromAccount = (isXfrFrom == true);
	this.isToAccount = (isXfrTo == true);
	if (isNaN(acBal)) acBal = 0;
	this.Balance = acBal;
	if (isNaN(acMinXfr)) acMinXfr = 0;
	this.MinimumTransfer = acMinXfr;
	this.DisplayText = acDisplay;
}

function TransferItem(trIndex1, trIndex2, trDt, trAmt)
{
	this.FromIndex = trIndex1;
	this.ToIndex = trIndex2;
	this.TransferDate = trDt;
	this.Amount = trAmt;
}

function verifyToAccoutEligibility(fromAc, toAc)
{
	var result = true;
	
	//CTEL 33456 - Don't show ILN accounts if the from field is a BALOC
	if (fromAc.Category == "LINEOFCREDIT" && fromAc.SubCategory == "BUSINESS" && toAc.Category == "LOANSANDLEASES") return false;
	
	if (fromAc.Category != "LOANACCOUNT" && fromAc.Category != "LINEOFCREDIT" && fromAc.Category != "CREDITCARD") return result;
	
	if (fromAc.SubCategory == "OVERDRAFT" || fromAc.SubCategory == "MORTGAGE" || fromAc.SubCategory == "HEQ" || fromAc.SubCategory == "HQL")
	{
		result = (toAc.Category != "LOANACCOUNT");
		return result;
	}
	
	if (fromAc.Category == "LINEOFCREDIT" || fromAc.Category == "CREDITCARD")
	{
		result = (toAc.Category != "LINEOFCREDIT" && toAc.Category != "CREDITCARD");
	}
	
	return result;
}

function prepareMaximumAllowedBalanceForPage()
{
	var theFromAccountField = getPageFromAccount();
	prepareMaximumAllowedBalance(theFromAccountField);
}

function prepareMaximumAllowedBalance(theFromAccountField)
{
	if (theFromAccountField == null)
	{
		return;
	}
	
	var selectedIndex = theFromAccountField.options[theFromAccountField.selectedIndex].value;
	
	if (theFromAccountField.selectedIndex == 0)
	{
		return;
	}

	for (i=1; (i < TransferAccountList.length); i++)
	{
		if (selectedIndex == TransferAccountList[i].Index)
		{
			selectedAc = TransferAccountList[i];
			currentMaximumTransfer = selectedAc.Balance;
		}
	}
}

function rebuildToAccountListForEditPage()
{
	var theFromAccountField = getPageFromAccount();
	var theToAccountField = getPageToAccount();
	
	if (theFromAccountField == null || theToAccountField == null)
	{
		return;
	}
	
	rebuildToAccountListForEdit(theFromAccountField, theToAccountField);
}

function rebuildToAccountListForPage()
{
	var theFromAccountField = getPageFromAccount();
	var theToAccountField = getPageToAccount();
	
	if (theFromAccountField == null || theToAccountField == null)
	{
		return;
	}
	
	rebuildToAccountList(theFromAccountField, theToAccountField);
}

function rebuildToAccountListForControl(groupName)
{
	var theFromAccountField;
	var theToAccountField;
	
	if (groupName != "SINGLETRANSFER")
	{
		return;
	}
	theFromAccountField = getTransferControlFromAccount();
	theToAccountField = getTransferControlToAccount();
	
	if (theFromAccountField == null || theToAccountField == null)
	{
		return;
	}
	rebuildToAccountList(theFromAccountField, theToAccountField);
}

function rebuildToAccountList(theFromAccountField, theToAccountField)
{
	var indexFound = false;
	var counter = 0;
	
	if (theFromAccountField == null || theToAccountField == null)
	{
		return;
	}
	var selectedIndex = theFromAccountField.options[theFromAccountField.selectedIndex].value;

	var selectedAc;
	var foundSelectedAc = false;
	for (i=1; ((i < TransferAccountList.length) && (foundSelectedAc == false)); i++)
	{
		if (selectedIndex == TransferAccountList[i].Index)
		{
			selectedAc = TransferAccountList[i];
			foundSelectedAc = true;
			currentMaximumTransfer = selectedAc.Balance;
			isTransferFromHEQAccount = isHEQAccount(selectedAc);
		}
	}
	
	if (theFromAccountField.selectedIndex == 0)
	{
		theToAccountField.length = 1;
		theToAccountField.options[0] = new Option('(Select "From" Account First)');
		return;
	}
	else
	{
		theToAccountField.options[0] = new Option("(Select Account)");
	}
	
	var toItemCounter = 0;
	for (i=1; i < TransferAccountList.length; i++)
	{
		if (selectedIndex != TransferAccountList[i].Index && TransferAccountList[i].isToAccount)
		{
			if (verifyToAccoutEligibility(selectedAc, TransferAccountList[i]))
			{
				toItemCounter++;
				theToAccountField.options[toItemCounter] = new Option(TransferAccountList[i].DisplayText);
				theToAccountField.options[toItemCounter].value = TransferAccountList[i].Index;
			}
		}
	}
	theToAccountField.length = toItemCounter + 1;
}

function rebuildToAccountListForEdit(theFromAccountField, theToAccountField)
{
	var indexFound = false;
	var counter = 0;
	
	if (theFromAccountField == null || theToAccountField == null)
	{
		return;
	}
	var selectedIndex = theFromAccountField.options[theFromAccountField.selectedIndex].value;
	var selectedToAcctIndex = theToAccountField.options[theToAccountField.selectedIndex].value;

	var selectedAc;
	var foundSelectedAc = false;
	for (i=1; ((i < TransferAccountList.length) && (foundSelectedAc == false)); i++)
	{
		if (selectedIndex == TransferAccountList[i].Index)
		{
			selectedAc = TransferAccountList[i];
			foundSelectedAc = true;
			currentMaximumTransfer = selectedAc.Balance;						
			isTransferFromHEQAccount = isHEQAccount(selectedAc);
		}
	}
	
	if (theFromAccountField.selectedIndex == 0)
	{
		theToAccountField.length = 1;
		theToAccountField.options[0] = new Option('(Select "From" Account First)');
		return;
	}
	else
	{
		theToAccountField.options[0] = new Option("(Select Account)");
	}
	
	var toItemCounter = 0;
	for (i=1; i < TransferAccountList.length; i++)
	{
		if (selectedIndex != TransferAccountList[i].Index && TransferAccountList[i].isToAccount)
		{
			if (verifyToAccoutEligibility(selectedAc, TransferAccountList[i]))
			{
				toItemCounter++;
				theToAccountField.options[toItemCounter] = new Option(TransferAccountList[i].DisplayText);
				theToAccountField.options[toItemCounter].value = TransferAccountList[i].Index;
				if (TransferAccountList[i].Index == selectedToAcctIndex)
				{
					theToAccountField.options[toItemCounter].selected = true;
				}
			}
		}
	}
	theToAccountField.length = toItemCounter + 1;
}

function isHEQAccount(tmpAccount)
{
	return ((tmpAccount.Category == "LOANACCOUNT") && ((tmpAccount.SubCategory == "HEQ")||(tmpAccount.SubCategory == "HQL")));
}

function getToday()
{
	var tmpDate = new Date();
	var intMonth = tmpDate.getMonth() + 1;
	var strMonth = "x00" + intMonth
	var intDay = tmpDate.getDate();
	var strDay = "x00" + intDay
	var intYear = tmpDate.getFullYear();
	strDate = strMonth.substr(strMonth.length-2, 2) + "/" + strDay.substr(strDay.length-2, 2) + "/" + intYear
	var result = new Date(strDate);
	return result;
}

function isToday(tmpDate)
{
	var tmpToday = new Date();
	var curMonth = tmpToday.getMonth() + 1;
	var curDay = tmpToday.getDate();
	var curYear = tmpToday.getFullYear();
	var inMonth = tmpDate.getMonth() + 1;
	var inDay = tmpDate.getDate();
	var inYear = tmpDate.getFullYear();
	
	return (curMonth == inMonth && curDay == inDay && curYear == inYear);
}

function isSameDate(tmpDate1, tmpDate2)
{
	var tmpFirstDate = new Date(tmpDate1);
	var tmpSecondDate = new Date(tmpDate2);
	
	var curMonth = tmpFirstDate.getMonth() + 1;
	var curDay = tmpFirstDate.getDate();
	var curYear = tmpFirstDate.getFullYear();
	
	var inMonth = tmpSecondDate.getMonth() + 1;
	var inDay = tmpSecondDate.getDate();
	var inYear = tmpSecondDate.getFullYear();
	
	return (curMonth == inMonth && curDay == inDay && curYear == inYear);
}

function isFirstDateGreater(tmpDate1, tmpDate2)
{
	var tmpFirstDate = new Date(tmpDate1);
	var tmpSecondDate = new Date(tmpDate2);
	
	var curMonth = tmpFirstDate.getMonth() + 1;
	var curDay = tmpFirstDate.getDate();
	var curYear = tmpFirstDate.getFullYear();
	
	var inMonth = tmpSecondDate.getMonth() + 1;
	var inDay = tmpSecondDate.getDate();
	var inYear = tmpSecondDate.getFullYear();
	
	if (curYear > inYear) return true;
	if (curYear == inYear)
	{
		if (curMonth > inMonth) return true;
		if (curMonth == inMonth)
		{
			if (curDay > inDay) return true;
		}
	}
	return false;
}

function addYearsToDate(tmpDate, inYears)
{
	var tmpMonth = tmpDate.getMonth();
	var tmpDay = tmpDate.getDate();
	var tmpYear = tmpDate.getFullYear();
	
	tmpYear = tmpYear + inYears;
	
	var resultDate = new Date(tmpYear, tmpMonth, tmpDay);
	
	return resultDate;
}

function getAccountBalanceForMMFTransfer()
{
	var indexFound = false;
	var counter = 0;
	var selectedIndex = document.formMP.ddlAccountFrom.options[document.formMP.ddlAccountFrom.selectedIndex].value;
	
	if (document.formMP.ddlAccountFrom.selectedIndex == 0)
	{
		currentMaximumTransfer = 0;
		return;
	}

	var selectedAc;
	var foundSelectedAc = false;
	for (i=1; ((i < TransferAccountList.length) && (foundSelectedAc == false)); i++)
	{
		if (selectedIndex == TransferAccountList[i].Index)
		{
			selectedAc = TransferAccountList[i];
			foundSelectedAc = true;
			currentMaximumTransfer = selectedAc.Balance;
			return;
		}
	}
	currentMaximumTransfer = 0;
	return;
}

function isDuplicateMMFTransfer(trIndex1, trIndex2, trAmt)
{
	var isSameFromAc = false;
	var isSameToAc = false;
	var isSameAmt = false;
	
	for (i=1; (i < TransferList.length); i++)
	{
		curTr = TransferList[i];
		isSameFromAc = (curTr.FromIndex == trIndex1);
		isSameToAc = (curTr.ToIndex == trIndex2);
		isSameAmt = (curTr.Amount == trAmt);
		if (isSameFromAc && isSameToAc && isSameAmt)
		{
			return true;
		}
	}
	return false;
}

function loanAccountHint(hintText)
{
	var dL = eval("document.formMP.ddlManual1AccountType");
	var dA = document.getElementById("tdLoanHint");

	if (dL.value == "ILN")
	{
		dA.innerHTML = hintText;
	}
	else
	{
		dA.innerHTML = "";
	}
}

function ConfirmMultiPay(groupName)
{
	if (groupName == "EXIT")
	{
		return true;
	}
	if (!validateMultiPay())
	{
		PrepareMultiPayMsgs();
		alert(newNoDataEnteredMsg);
		return false;
	}
	return true;
}

function ConfirmSbbAutoEnrollment(groupName)
{
	if (groupName == "REJECT")
	{
		return SbbAutoEnrollmentRejectTerms();
	}
	return true;
}

function initializeToAccountList(fieldName)
{
	var toList = eval(fieldName);
	if (toList != null && toList.selectedIndex == 0) 
	{
		toList.length = 1;
	}
}

function writeGreeting(morning, afternoon, evening)
{
	var greeting;

	var now = new Date();
	var hour = now.getHours();

	if (hour >= 6 && hour < 12) greeting = morning;
	else if (hour >= 12 && hour < 18) greeting = afternoon;
	else if ((hour >= 18 && hour <= 23) || (hour >= 0 && hour <= 5)) greeting = evening;
	document.write(greeting)
}


function getInputElement(fieldName)
{
	return document.getElementById(fieldName);
}

function handleInputTextFocus(gotFocus, fieldName, focusText, blurText)
{
	theInputField = getInputElement(fieldName);
	if (theInputField == null)
	{
		return true;
	}
	
	if (gotFocus)
	{
		if (theInputField.value == blurText)
		{
			theInputField.value = focusText;
		}
	}
	else
	{
		if (theInputField.value == focusText)
		{
			theInputField.value = blurText;
		}
	}
	return true;
}

function ClearValues(radioObj)
{
	var fromDate = eval("document.formMP.txtDateFrom");
	var toDate = eval("document.formMP.txtDateTo");
	var checkNumber = eval("document.formMP.txtCheckNumber");

	if (radioObj['0'].checked)
		{

		fromDate.value = "";
		toDate.value = "";

		}
	else if((radioObj['1'].checked) || (radioObj['2'].checked) || (radioObj['3'].checked))
		{
		fromDate.value = "";
		toDate.value = "";
		checkNumber.value = "";
		}
	else if (radioObj['4'].checked)
		checkNumber.value = "";
}

function CheckForAdobe()
{
	var isInstalled = false;
	var version = null;
	if (window.ActiveXObject) {

		//Determine if we can create an Adobe object
		var control = null;
		var max;
		var x;
		max = 20;
	    
	   if (!control) {

				try
				{
					// AcroPDF.PDF is used by version 7 and later
					control=eval("new ActiveXObject('AcroPDF.PDF');");

				}
				catch(e)
				 {
					return;
				}
		}

		if (!control) {

			for (var x = 1; x < max; x++)
			{
				try
				{
					// PDF.PdfCtrl is used by version 6 and earlier
					control=eval("new ActiveXObject('PDF.PdfCtrl."+x+"');");
					
					if (control)
					{
						x=max;
					}

				}
				catch(e)
				 {
					return;
				}

			}
		}

		if (control) {
		
			return true;
		}
	}    	 
	else 
	{

		// Check navigator.plugins for "Adobe Acrobat" (version6) or "Adobe PDF Plug-in" (version 7) or "adobe pdf plug-in for firefox and netscape" (version 8)
		if (navigator.plugins && navigator.plugins.length)
		{
		
		var description;
		
			for ( var x = 0, l = navigator.plugins.length; x < l; ++x ) 
			{

				description = navigator.plugins[x].description;
				description = description.toLowerCase();
		
				if (description.indexOf('adobe acrobat') != -1 ||
					description.indexOf('adobe pdf plug-in') != -1 ||
					description.indexOf('adobe pdf plug-in for firefox and netscape') != -1)
					
					{
						version = parseFloat(navigator.plugins[x].description.split('Version ')[1]);

						if (version.toString().length == 1)	version+='.0';

						isInstalled = true;

						return true;
					}
			}
		}
	}

}
